for (i = 0; i < (1 << 20); i++)
{
  test();
}
