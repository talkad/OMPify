for (i = 0; i < (1 << 10); i++)
{
  comp(i);
}
