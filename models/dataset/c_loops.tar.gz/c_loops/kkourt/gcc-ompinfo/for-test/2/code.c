for (i = 0; i < (1 << 20); i++)
{
  foo();
  #pragma omp parallel for
  for (j = 0; j < (1 << 20); j++)
  {
    test();
  }

}
