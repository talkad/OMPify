for (j = 0; j < (1 << 20); j++)
{
  test();
}
