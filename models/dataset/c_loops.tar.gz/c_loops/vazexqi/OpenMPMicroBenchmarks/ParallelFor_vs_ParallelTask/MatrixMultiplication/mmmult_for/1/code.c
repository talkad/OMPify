for (i = 0; i < Ndim; i++)
  for (j = 0; j < Pdim; j++)
  *(A + ((i * Ndim) + j)) = 3.0;

