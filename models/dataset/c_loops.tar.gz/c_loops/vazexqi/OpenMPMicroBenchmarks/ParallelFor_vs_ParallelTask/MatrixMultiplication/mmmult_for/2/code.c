for (i = 0; i < Pdim; i++)
  for (j = 0; j < Mdim; j++)
  *(B + ((i * Pdim) + j)) = 5.0;

