for (i = 0; i < Ndim; i++)
{
  for (j = 0; j < Mdim; j++)
  {
    tmp = 0.0;
    for (k = 0; k < Pdim; k++)
    {
      tmp += (*(A + ((i * Ndim) + k))) * (*(B + ((k * Pdim) + j)));
    }

    *(C + ((i * Ndim) + j)) = tmp;
  }

}
