for (i = 0; i < Ndim; i++)
  for (j = 0; j < Mdim; j++)
  *(C + ((i * Ndim) + j)) = 0.0;

