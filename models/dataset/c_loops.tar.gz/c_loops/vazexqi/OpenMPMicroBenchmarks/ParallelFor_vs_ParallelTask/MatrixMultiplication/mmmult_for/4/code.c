for (i = 0; i < Ndim; i++)
{
  for (j = 0; j < Mdim; j++)
  {
    err = (*((C + (i * Ndim)) + j)) - cval;
    errsq += err * err;
  }

}
