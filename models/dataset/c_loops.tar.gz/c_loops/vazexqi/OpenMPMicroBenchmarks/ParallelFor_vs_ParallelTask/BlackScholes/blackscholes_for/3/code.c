for (i = 0; i < numOptions; i++)
{
  rv = fprintf(file, "%.18f\n", prices[i]);
  if (rv < 0)
  {
    printf("ERROR: Unable to write to file `%s'.\n", outputFile);
    fclose(file);
    exit(1);
  }

}
