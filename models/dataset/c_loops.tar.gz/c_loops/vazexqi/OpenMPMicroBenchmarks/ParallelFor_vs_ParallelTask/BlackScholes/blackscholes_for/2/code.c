for (i = 0; i < numOptions; i++)
{
  otype[i] = (data[i].OptionType == 'P') ? (1) : (0);
  sptprice[i] = data[i].s;
  strike[i] = data[i].strike;
  rate[i] = data[i].r;
  volatility[i] = data[i].v;
  otime[i] = data[i].t;
}
