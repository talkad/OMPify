for (i = 0; i < numOptions; i++)
{
  price = BlkSchlsEqEuroNoDiv(sptprice[i], strike[i], rate[i], volatility[i], otime[i], otype[i], 0);
  prices[i] = price;
}
