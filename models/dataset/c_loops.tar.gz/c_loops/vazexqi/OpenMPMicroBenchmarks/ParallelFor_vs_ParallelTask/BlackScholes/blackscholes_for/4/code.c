for (i = 0; i < numOptions; i++)
{
  price = BlkSchlsEqEuroNoDiv(sptprice[i], strike[i], rate[i], volatility[i], otime[i], otype[i], 0);
  prices[i] = price;
  priceDelta = data[i].DGrefval - price;
  if (fabs(priceDelta) >= 1e-4)
  {
    printf("Error on %d. Computed=%.5f, Ref=%.5f, Delta=%.5f\n", i, price, data[i].DGrefval, priceDelta);
    numError++;
  }

}
