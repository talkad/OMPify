for (tj = 0; tj < varNumF1; tj++)
  f1_layer[o][tj].Q = f1_layer[o][tj].P;
