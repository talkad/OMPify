for (i = 0; i < numf1s; i++)
  for (j = start; j < numf2s; j++)
  bus[i][j] = (1 / (1.0 - d)) / sqrt((double) numf1s);

