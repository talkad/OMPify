for (ti = 0; ti < varNumF1; ti++)
{
  f1_layer[o][ti].X = f1_layer[o][ti].W / oldTnorm;
  if (f1_layer[o][ti].X < varNumTheta)
    xr = 0;
  else
    xr = f1_layer[o][ti].X;

  if (f1_layer[o][ti].Q < varNumTheta)
    qr = 0;
  else
    qr = f1_layer[o][ti].Q;

  f1_layer[o][ti].V = xr + (varNumB * qr);
  tnorm += f1_layer[o][ti].V * f1_layer[o][ti].V;
}
