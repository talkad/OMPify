for (j = 0; j < numf2s; j += 10)
  printf(" j = %i  Y= %9.7f\n", j, Y[o][j].y);
