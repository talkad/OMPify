for (i = numpatterns; i < numf2s; i++)
  Y[o][i].reset = 1;
