for (i = 0; i < numthreads; i++)
{
  f1_layer[i] = (f1_neuron *) malloc(numf1s * (sizeof(f1_neuron)));
  if (f1_layer[i] == 0)
  {
    fprintf(stderr, "malloc error in init_net\n");
    exit(1);
  }

}
