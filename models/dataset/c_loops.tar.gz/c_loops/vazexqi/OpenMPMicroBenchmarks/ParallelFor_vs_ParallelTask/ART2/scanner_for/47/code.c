for (i = 1; i < numf1s; i++)
{
  busp[i] = busp[i - 1] + numf2s;
}
