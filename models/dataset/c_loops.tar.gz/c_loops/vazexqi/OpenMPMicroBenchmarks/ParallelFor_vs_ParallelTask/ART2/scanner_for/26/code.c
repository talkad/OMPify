for (tj = *spot; tj < varNumF2; tj++)
{
  Y[o][tj].y = 0;
}
