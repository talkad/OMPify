for (j = 0; j < numthreads; j++)
{
  for (i = 0; i < numf1s; i++)
  {
    f1_layer[j][i].I = (double *) malloc(2 * (sizeof(double)));
    if (f1_layer[j][i].I == 0)
    {
      fprintf(stderr, "malloc error in init_net\n");
      exit(1);
    }

    f1_layer[j][i].W = 0.0;
    f1_layer[j][i].X = 0.0;
    f1_layer[j][i].V = 0.0;
    f1_layer[j][i].U = 0.0;
    f1_layer[j][i].P = 0.0;
    f1_layer[j][i].Q = 0.0;
    f1_layer[j][i].R = 0.0;
  }

}
