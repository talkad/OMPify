for (i = 0; i < numf1s; i++)
{
  fscanf(inp, "%le", &a);
  bus[i][j] = (tds[i][j] = a);
}
