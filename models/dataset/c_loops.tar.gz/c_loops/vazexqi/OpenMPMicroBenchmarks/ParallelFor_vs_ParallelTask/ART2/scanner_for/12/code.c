for (i = 0; i < varNumF1; i++)
{
  f1_layer[o][i].W = 0.0;
  f1_layer[o][i].X = 0.0;
  f1_layer[o][i].V = 0.0;
  f1_layer[o][i].U = 0.0;
  f1_layer[o][i].P = 0.0;
  f1_layer[o][i].Q = 0.0;
  f1_layer[o][i].R = 0.0;
}
