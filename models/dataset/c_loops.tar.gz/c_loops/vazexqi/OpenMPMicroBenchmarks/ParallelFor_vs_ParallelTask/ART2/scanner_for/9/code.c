for (j = 0; j < numf1s; j++)
{
  su += f1_layer[o][j].U;
  sp += f1_layer[o][j].P;
  su2 += f1_layer[o][j].U * f1_layer[o][j].U;
  sp2 += f1_layer[o][j].P * f1_layer[o][j].P;
  sup += f1_layer[o][j].U * f1_layer[o][j].P;
}
