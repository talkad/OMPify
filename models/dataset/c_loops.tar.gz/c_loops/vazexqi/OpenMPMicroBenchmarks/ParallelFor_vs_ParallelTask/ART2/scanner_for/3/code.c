for (i = 0; i < numthreads; i++)
{
  Y[i] = (xyz *) malloc(numf2s * (sizeof(xyz)));
  if (Y[i] == 0)
  {
    fprintf(stderr, "malloc error in init_net\n");
  }

  Y[i][0].y = 0.0;
}
