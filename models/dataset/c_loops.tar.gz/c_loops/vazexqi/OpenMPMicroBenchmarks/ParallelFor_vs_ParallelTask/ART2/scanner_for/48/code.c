for (i = 0; i < numf1s; i++)
{
  for (j = 0; j < numf2s; j++)
  {
    busp[i][j] = bus[i][j];
  }

}
