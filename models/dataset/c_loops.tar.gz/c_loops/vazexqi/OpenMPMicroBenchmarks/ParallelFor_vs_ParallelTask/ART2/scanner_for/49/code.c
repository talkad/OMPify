for (ij = 0; ij < ijmx; ij++)
{
  j = ((ij / inum) * gStride) + gStartY;
  i = ((ij % inum) * gStride) + gStartX;
  printf("x = %i, y = %i, match confidence = %9.7f \n", i, j, mat_con[ij]);
}
