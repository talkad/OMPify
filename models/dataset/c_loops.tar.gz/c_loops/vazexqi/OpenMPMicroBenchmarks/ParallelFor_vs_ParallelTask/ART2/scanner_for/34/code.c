for (i = 0; i < 4; i++)
  if (buffer[i] != ' ')
  height = ((height * 10) + buffer[i]) - '0';

