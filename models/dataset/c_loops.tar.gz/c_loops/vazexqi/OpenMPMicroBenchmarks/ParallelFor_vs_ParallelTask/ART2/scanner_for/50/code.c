for (i = 0; i < numthreads; i++)
{
  highest_confidence[i][0] = 0.0;
  highest_confidence[i][1] = 0.0;
  highx[i][0] = 0;
  highx[i][1] = 0;
  highy[i][0] = 0;
  highy[i][1] = 0;
  set_high[i][0] = 0;
  set_high[i][1] = 0;
}
