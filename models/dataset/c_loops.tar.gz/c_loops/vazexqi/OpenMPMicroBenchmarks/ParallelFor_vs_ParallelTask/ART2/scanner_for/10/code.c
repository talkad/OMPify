for (k = 0; k < 1; k++)
{
  resonant = 0;
  for (j = 0; j < numf1s; j++)
  {
    temp = tds[j][i];
    tds[j][i] += (g(i) * (f1_layer[o][j].P - tds[j][i])) * delta_t;
    if (fabs(temp - tds[j][i]) <= er)
      resonant = 1;

  }

  for (j = 0; j < numf1s; j++)
  {
    temp = bus[j][i];
    bus[j][i] += (g(i) * (f1_layer[o][j].P - bus[j][i])) * delta_t;
    if ((fabs(temp - bus[j][i]) <= er) && resonant)
    {
      resonant = 1;
    }
    else
    {
      resonant = 0;
    }

  }

}
