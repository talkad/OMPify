for (i = 0; i < numf1s; i++)
{
  bus[i] = (double *) malloc(numf2s * (sizeof(double)));
  tds[i] = (double *) malloc(numf2s * (sizeof(double)));
  if ((bus[i] == 0) || (tds[i] == 0))
  {
    fprintf(stderr, "Malloc problem in load_weights, i=%d\n", i);
    exit(1);
  }

}
