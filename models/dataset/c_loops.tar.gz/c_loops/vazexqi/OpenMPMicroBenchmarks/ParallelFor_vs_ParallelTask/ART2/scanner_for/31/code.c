for (j = 0; (j < 9) && (!f1res); j++)
{
  compute_values_match(o, &f1res, &spot, busp);
}
