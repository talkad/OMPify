for (ti = 0; ti < varNumF1; ti++)
{
  f1_layer[o][ti].W = f1_layer[o][ti].I[varNumCp] + (varNumA * f1_layer[o][ti].U);
  tnorm += f1_layer[o][ti].W * f1_layer[o][ti].W;
}
