for (i = 0; i < cimgheight; i += height)
{
  for (j = 0; j < cimgwidth; j += width)
  {
    for (r = 0; r < height; r++)
    {
      for (c = 0; c < width; c++)
      {
        cimage[i + r][j + c] = superbuffer[(r * width) + c];
      }

    }

  }

}
