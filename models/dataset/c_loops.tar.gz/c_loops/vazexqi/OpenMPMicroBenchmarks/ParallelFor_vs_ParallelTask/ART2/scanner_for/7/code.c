for (j = 0; j < varNumF1; j++)
{
  temp_sum = f1_layer[o][j].U * f1_layer[o][j].U;
  norm += temp_sum;
}
