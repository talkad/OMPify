for (ij = 0; ij < ijmx; ij++)
{
  j = ((ij / inum) * gStride) + gStartY;
  i = ((ij % inum) * gStride) + gStartX;
  k = 0;
  for (m = j; m < (gLheight + j); m++)
    for (n = i; n < (gLwidth + i); n++)
    f1_layer[o][k++].I[0] = cimage[m][n];


  gPassFlag = 0;
  gPassFlag = match(o, i, j, &mat_con[ij], busp);
  if (gPassFlag == 1)
  {
    if (set_high[o][0] == 1)
    {
      highx[o][0] = i;
      highy[o][0] = j;
      set_high[o][0] = 0;
    }

    if (set_high[o][1] == 1)
    {
      highx[o][1] = i;
      highy[o][1] = j;
      set_high[o][1] = 0;
    }

  }

}
