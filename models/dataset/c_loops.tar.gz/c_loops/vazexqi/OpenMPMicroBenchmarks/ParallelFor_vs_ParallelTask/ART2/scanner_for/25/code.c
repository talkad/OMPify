for (ti = 0; ti < varNumF1; ti++)
{
  f1_layer[o][ti].U = f1_layer[o][ti].V / oldTnorm;
  tsum = 0;
  ttemp = f1_layer[o][ti].P;
  for (tj = *spot; tj < varNumF2; tj++)
  {
    if ((tj == winner[o][0]) && (Y[o][tj].y > 0))
      tsum += tds[ti][tj] * varNumD;

  }

  f1_layer[o][ti].P = f1_layer[o][ti].U + tsum;
  tnorm += f1_layer[o][ti].P * f1_layer[o][ti].P;
  if (fabs(ttemp - f1_layer[o][ti].P) < 0.000001)
    tresult = 0;

}
