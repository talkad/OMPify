for (j = 0; j < varNumF1; j++)
{
  f1_layer[o][j].R = (f1_layer[o][j].U + (cc * f1_layer[o][j].P)) / sum;
  norm += f1_layer[o][j].R * f1_layer[o][j].R;
}
