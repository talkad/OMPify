for (ti = 0; ti < varNumF1; ti++)
{
  for (tj = *spot; tj < varNumF2; tj++)
    if (!Y[o][tj].reset)
    Y[o][tj].y += f1_layer[o][ti].P * busp[ti][tj];


}
