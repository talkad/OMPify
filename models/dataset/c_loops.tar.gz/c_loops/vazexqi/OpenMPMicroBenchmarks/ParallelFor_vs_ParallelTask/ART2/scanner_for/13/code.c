for (i = 0; i < numf2s; i++)
{
  Y[o][i].y = 0.0;
  Y[o][i].reset = 0;
}
