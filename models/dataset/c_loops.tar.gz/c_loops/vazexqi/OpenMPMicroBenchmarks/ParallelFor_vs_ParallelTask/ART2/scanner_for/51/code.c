for (i = 0; i < numthreads; i++)
{
  winner[i] = (int *) malloc(4 * (sizeof(int)));
  if (winner[i] == 0)
  {
    printf("malloc error\n");
    exit(1);
  }

  winner[i][0] = 0;
  cp[i] = (int *) malloc(4 * (sizeof(int)));
  if (cp[i] == 0)
  {
    printf("malloc error\n");
    exit(1);
  }

  cp[i][0] = 0;
  highx[i] = (int *) malloc(4 * (sizeof(int)));
  if (highx[i] == 0)
  {
    printf("malloc error\n");
    exit(1);
  }

  highx[i][0] = 0;
  highy[i] = (int *) malloc(4 * (sizeof(int)));
  if (highy[i] == 0)
  {
    printf("malloc error\n");
    exit(1);
  }

  highy[i][0] = 0;
  highest_confidence[i] = (double *) malloc(DBLS_PER_CACHELINE * (sizeof(double)));
  if (highest_confidence == 0)
  {
    printf("malloc error\n");
    exit(1);
  }

  highest_confidence[i][0] = 0.0;
  set_high[i] = (int *) malloc(4 * (sizeof(int)));
  if (set_high == 0)
  {
    printf("malloc error\n");
    exit(1);
  }

  set_high[i][0] = 0;
}
