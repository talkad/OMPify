for (i = 0; i < (lheight * lwidth); i++)
{
  t = superbuffer[i];
  f1_layer[o][i].I[spot] = (double) t;
}
