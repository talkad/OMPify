for (i = low; i < varHigh; i++)
{
  for (j = 0; j < varNumF1; j++)
  {
    noise1 = rand() & 0xffff;
    noise2 = ((double) noise1) / ((double) 0xffff);
    tds[j][i] -= noise2;
    bus[j][i] -= noise2;
  }

}
