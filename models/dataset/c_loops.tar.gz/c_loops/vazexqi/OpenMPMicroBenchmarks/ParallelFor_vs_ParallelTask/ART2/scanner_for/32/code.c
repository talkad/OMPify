for (mt = 0; mt < numf2s; mt++)
  if (Y[o][mt].reset == 0)
  matchtest = 1;

