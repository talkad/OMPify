for (i = 0; i < 4; i++)
  if (buffer[i] != ' ')
  lwidth = ((lwidth * 10) + buffer[i]) - '0';

