for (i = low; i < varHigh; i++)
{
  for (j = 0; j < varNumF1; j++)
  {
    if (i % low)
    {
      tds[j][i] = tds[j][0];
      tds[j][i] = bus[j][0];
    }
    else
    {
      tds[j][i] = tds[j][1];
      tds[j][i] = bus[j][1];
    }

  }

}
