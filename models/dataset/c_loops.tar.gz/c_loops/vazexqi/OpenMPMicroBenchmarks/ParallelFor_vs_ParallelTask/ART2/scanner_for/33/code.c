for (i = 0; i < 4; i++)
  if (buffer[i] != ' ')
  width = ((width * 10) + buffer[i]) - '0';

