for (j = 0; (j < 9) && (!f1res); j++)
{
  compute_train_match(o, &f1res, &spot);
}
