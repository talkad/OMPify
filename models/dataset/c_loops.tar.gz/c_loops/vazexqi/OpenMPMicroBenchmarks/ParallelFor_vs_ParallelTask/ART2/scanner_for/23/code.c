for (tj = *spot; tj < numpatterns; tj++)
{
  Y[o][tj].y = 0;
  if (!Y[o][tj].reset)
    for (ti = 0; ti < varNumF1; ti++)
    Y[o][tj].y += f1_layer[o][ti].P * bus[ti][tj];


}
