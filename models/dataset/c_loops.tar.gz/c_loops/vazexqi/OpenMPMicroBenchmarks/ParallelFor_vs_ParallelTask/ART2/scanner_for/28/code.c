for (ti = *spot; ti < varNumF2; ti++)
{
  if (Y[o][ti].y > Y[o][winner[o][0]].y)
    winner[o][0] = ti;

}
