for (i = 0; i < cimgheight; i++)
{
  cimage[i] = (unsigned char *) malloc(cimgwidth * (sizeof(unsigned char)));
  if (cimage[i] == 0)
  {
    fprintf(stderr, "Problems with malloc in loadimage()\n");
    exit(1);
  }

}
