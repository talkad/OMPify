for (i = 0; i < numf1s; i++)
  for (j = 0; j < numf2s; j++)
  if (j == (numf2s - 1))
  printf(" %8.16f\n", tds[i][j]);
else
  printf(" %8.16f ", tds[i][j]);


