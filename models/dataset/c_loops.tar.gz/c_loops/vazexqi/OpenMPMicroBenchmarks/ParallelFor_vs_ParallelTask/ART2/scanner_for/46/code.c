for (i = 0; i < numf1s; i++)
{
  for (j = spot; j < numf2s; j++)
  {
    tds[i][j] = (bus[i][j] = (1.0 / sqrt((double) numf1s)) / (1 - d));
  }

}
