for (i = 0; i < numf1s; i++)
  for (j = start; j < numf2s; j++)
  tds[i][j] = 0.0;

