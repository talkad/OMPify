for (i = 0; i < numf1s; i++)
{
  if ((i % 5) == 0)
    printf("\n");

  printf(" %8.5f ", f1_layer[o][i].I[cp[o][0]]);
}
