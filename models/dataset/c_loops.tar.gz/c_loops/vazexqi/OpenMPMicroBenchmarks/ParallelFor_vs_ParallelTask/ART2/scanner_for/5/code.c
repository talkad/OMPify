for (i = 0; i < numf2s; i++)
  if (Y[o][i].y > Y[o][winner[o][0]].y)
  winner[o][0] = i;

