for (j = 0; j < varNumF1; j++)
{
  norm += f1_layer[o][j].P * f1_layer[o][j].P;
}
