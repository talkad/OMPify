for (i = 0; i < w; i++)
{
  for (j = 0; j < h; j++)
  {
    int state;
    neighbours = 0;
    for (s = 0; s < 8; s++)
    {
      int x;
      int y;
      x = ((i + mask[s][0]) + w) % w;
      y = ((j + mask[s][1]) + h) % h;
      neighbours += (M[nk][x + (w * y)]) ? (1) : (0);
    }

    state = do_life(neighbours);
    if (state == 0)
    {
      M[k][i + (w * j)] = M[nk][i + (w * j)];
    }
    else
      if (state > 0)
    {
      M[k][i + (w * j)] = 1;
    }
    else
      if (state < 0)
    {
      M[k][i + (w * j)] = 0;
    }



  }

}
