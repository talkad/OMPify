for (i = 0; i < w; i++)
{
  for (j = 0; j < h; j++)
  {
    glBegin(0x0007);
    if (M[k][i + (w * j)])
    {
      float r = 0.5f;
      float g = 0.5f;
      float b = 0.5f;
      if (i & 1)
        r = 1.0f;

      if (j & 1)
        g = 1.0f;

      glColor3f(r, g, b);
      glVertex3i(i, j, 0);
      glVertex3i(i + 1, j, 0);
      glVertex3i(i + 1, j + 1, 0);
      glVertex3i(i, j + 1, 0);
    }

    glEnd();
  }

}
