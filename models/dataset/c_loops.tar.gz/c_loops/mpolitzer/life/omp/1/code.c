for (i = 0; i < w; i++)
{
  for (j = 0; j < h; j++)
  {
    int init = (rand() % cmd_opts.mod_val) ? (1) : (0);
    M[1][i + (w * j)] = init;
    M[0][i + (w * j)] = init;
  }

}
