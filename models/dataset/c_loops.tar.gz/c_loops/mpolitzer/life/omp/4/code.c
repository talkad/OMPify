for (i = 1; i < argc; i++)
{
  if (strcmp("--fs", argv[i]) == 0)
  {
    cmd_opts.fs = 1;
  }
  else
    if (strcmp("--no_render", argv[i]) == 0)
  {
    cmd_opts.render = 0;
  }
  else
    if (strcmp("--width", argv[i]) == 0)
  {
    sscanf(argv[i + 1], " %d", &cmd_opts.width);
  }
  else
    if (strcmp("--height", argv[i]) == 0)
  {
    sscanf(argv[i + 1], " %d", &cmd_opts.height);
  }
  else
    if (strcmp("--mod_val", argv[i]) == 0)
  {
    sscanf(argv[i + 1], " %d", &cmd_opts.mod_val);
  }
  else
    if (strcmp("--help", argv[i]) == 0)
  {
    print_usage(argv[0]);
    exit(0);
  }






}
