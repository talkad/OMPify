for (i = 0; i < w; i++)
{
  for (j = 0; j < h; j++)
  {
    printf("%d", (M[k][i + (w * j)]) ? (1) : (0));
  }

  printf("\n");
}
