for (j = 0; j < THEME_COUNT; j++)
{
  if (strcmp(theme[j].name, optarg) == 0)
  {
    t = j;
    break;
  }

}
