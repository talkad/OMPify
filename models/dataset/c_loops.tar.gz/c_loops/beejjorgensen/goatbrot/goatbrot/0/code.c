for (i = 0; i < THEME_COUNT; i++)
{
  fprintf(stderr, "                               %s\n", theme[i].name);
}
