for (y = 0; y < minfo->height_px; y++)
{
  int x;
  unsigned char rgb[3];
  long double cx1;
  long double cy1;
  long double cx2;
  long double cy2 = 0;
  int r[4];
  int g[4];
  int b[4];
  long double t[4];
  cy1 = minfo->top_im - ((minfo->height_im * y) / minfo->height_px);
  if (minfo->antialias)
  {
    cy2 = minfo->top_im - ((minfo->height_im * (y + 0.5)) / minfo->height_px);
  }

  for (x = 0; x < minfo->width_px; x++)
  {
    int max_iterations = app_context.mandelbrot_info.max_iterations;
    int continuous = app_context.mandelbrot_info.continuous;
    cx1 = ((minfo->width_re * x) / minfo->width_px) + minfo->left_re;
    if (minfo->antialias)
    {
      cx2 = ((minfo->width_re * (x + 0.5)) / minfo->width_px) + minfo->left_re;
      t[0] = get_escape_time(cx1, cy1, max_iterations, continuous);
      t[1] = get_escape_time(cx2, cy1, max_iterations, continuous);
      t[2] = get_escape_time(cx1, cy2, max_iterations, continuous);
      t[3] = get_escape_time(cx2, cy2, max_iterations, continuous);
      time_to_color(t[0], r + 0, g + 0, b + 0);
      time_to_color(t[1], r + 1, g + 1, b + 1);
      time_to_color(t[2], r + 2, g + 2, b + 2);
      time_to_color(t[3], r + 3, g + 3, b + 3);
      rgb[0] = (((r[0] + r[1]) + r[2]) + r[3]) / 4;
      rgb[1] = (((g[0] + g[1]) + g[2]) + g[3]) / 4;
      rgb[2] = (((b[0] + b[1]) + b[2]) + b[3]) / 4;
    }
    else
    {
      t[0] = get_escape_time(cx1, cy1, max_iterations, continuous);
      time_to_color(t[0], r + 0, g + 0, b + 0);
      rgb[0] = r[0];
      rgb[1] = g[0];
      rgb[2] = b[0];
    }

    fwrite(rgb, sizeof(rgb[0]), (sizeof(rgb)) / (sizeof(rgb[0])), fp);
  }

  if (show_progress)
  {
    {
      total_pixels += minfo->width_px;
      fprintf(stderr, "   \rCompleted: %.1f%%", (100.0 * total_pixels) / image_pixels);
      fflush(stderr);
    }
  }

}
