for (i = ((-3LL) * 0x7fffffff) - 20000LL; i <= (0x7fffffff + 10000LL); i += 0x7fffffff + 200LL)
{
  if (i == (((-3LL) * 0x7fffffff) - 20000LL))
    set(5, 0);
  else
    if (i == ((((-2LL) * 0x7fffffff) - 20000LL) + 200LL))
    set(5, 1);
  else
    if (i == (((-0x7fffffff) - 20000LL) + 400LL))
    set(5, 2);
  else
    if (i == ((-20000LL) + 600LL))
    set(5, 3);
  else
    if (i == ((0x7fffffff - 20000LL) + 800LL))
    set(5, 4);
  else
    e = 1;





}
