for (i = 0; i < 50; i++)
  foo(a);
