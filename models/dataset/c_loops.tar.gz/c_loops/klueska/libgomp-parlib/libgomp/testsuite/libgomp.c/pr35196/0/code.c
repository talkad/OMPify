for (i = 0; i < 5; i++)
  j = i;
