for (i = 0; i < 64; i++)
  if (buf[i] != (6 * ((i & 1) && (i <= 61))))
  abort();

