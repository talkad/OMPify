for (p = &buf[63]; p >= (&buf[3]); p -= 2)
  p[-2] = 6;
