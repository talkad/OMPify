for (i = 0; i < 16; i++)
{
  if (n != 6)
    ++x;

  n = i;
}
