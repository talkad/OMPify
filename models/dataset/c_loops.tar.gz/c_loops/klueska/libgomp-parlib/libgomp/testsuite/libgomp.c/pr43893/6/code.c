for (j = 0x7fffffff; j > (0x7fffffff - 1); j--)
  c++;
