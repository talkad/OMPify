for (i = 0; i < 10; ++i)
{
  if (test())
    continue;

  abort();
}
