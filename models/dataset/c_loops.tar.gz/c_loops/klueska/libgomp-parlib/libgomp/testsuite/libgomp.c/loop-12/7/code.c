for (idx = 0; idx < 5; idx++)
  if (arr[(1 * 5) + idx] != (idx < 3))
  abort();
else
  arr[(1 * 5) + idx] = 0;

