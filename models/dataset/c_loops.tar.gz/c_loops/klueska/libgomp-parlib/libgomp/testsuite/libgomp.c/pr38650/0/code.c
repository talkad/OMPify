for (i = 0; i < j; i += 1)
  e++;
