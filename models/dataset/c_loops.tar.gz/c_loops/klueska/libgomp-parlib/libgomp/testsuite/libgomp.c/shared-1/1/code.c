for (i = 0; i < 10; i++)
  for (j = 0; j < 5; j++)
  A[i][j].y.l[3][3] = -10;

