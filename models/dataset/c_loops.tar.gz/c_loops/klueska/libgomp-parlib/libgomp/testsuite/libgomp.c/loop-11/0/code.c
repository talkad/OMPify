for (p = &buf[10]; (&buf[54]) > p; p++)
  *p = 5;
