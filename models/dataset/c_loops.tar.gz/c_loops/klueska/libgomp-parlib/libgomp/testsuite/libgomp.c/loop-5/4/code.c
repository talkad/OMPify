for (p = &buf[53]; p > (&buf[9]); --p)
  *p = 5;
