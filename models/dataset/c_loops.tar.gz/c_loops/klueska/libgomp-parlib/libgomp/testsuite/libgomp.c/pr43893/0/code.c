for (i = 0; i < 1; i++)
  c++;
