for (i = 0; i < 10; i++)
  printf("x[%d] = %f, y[%d] = %f\n", i, x[i], i, y[i]);
