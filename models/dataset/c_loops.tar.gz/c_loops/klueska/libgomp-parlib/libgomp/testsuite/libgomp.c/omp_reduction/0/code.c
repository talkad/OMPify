for (i = 0; i < n; i++)
  sum = sum + (a[i] * b[i]);
