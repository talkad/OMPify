for (p = &buf[16]; (&buf[51]) > p; p = 4 + p)
  p[2] = 7;
