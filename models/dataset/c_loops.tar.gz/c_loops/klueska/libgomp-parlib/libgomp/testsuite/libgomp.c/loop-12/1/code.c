for (i = (-0x7fffffffffffffffLL) + 30000; ((-0x7fffffffffffffffLL) + 10000) <= i; i -= 10000)
{
  if (i == ((-0x7fffffffffffffffLL) + 30000))
    set(1, 0);
  else
    if (i == ((-0x7fffffffffffffffLL) + 20000))
    set(1, 1);
  else
    if (i == ((-0x7fffffffffffffffLL) + 10000))
    set(1, 2);
  else
    e = 1;



}
