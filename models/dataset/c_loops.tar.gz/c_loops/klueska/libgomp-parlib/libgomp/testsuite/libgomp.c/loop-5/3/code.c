for (p = &buf[16]; p <= (&buf[40]); p = p + 4ULL)
  p[2] = -7;
