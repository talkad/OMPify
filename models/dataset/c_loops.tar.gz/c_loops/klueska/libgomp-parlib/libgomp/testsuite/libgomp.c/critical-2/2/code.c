for (i = 0; i < 2000; i++)
  if (A[i] != nthreads)
  abort();

