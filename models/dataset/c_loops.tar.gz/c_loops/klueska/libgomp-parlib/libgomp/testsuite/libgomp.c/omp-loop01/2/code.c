for (i = N2; i > N1; i -= step)
  b[i] = a[i];
