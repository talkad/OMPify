for (p = &buf[3]; (&buf[63]) >= p; p += 2)
  p[-2] = 6;
