for (i = N2; i >= N1; i -= step)
  if (a[i] != b[i])
  abort();

