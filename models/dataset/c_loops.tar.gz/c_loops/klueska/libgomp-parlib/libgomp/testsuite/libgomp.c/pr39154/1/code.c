for (int j = 0; j < n; j++)
  b[i][j] = a[i];
