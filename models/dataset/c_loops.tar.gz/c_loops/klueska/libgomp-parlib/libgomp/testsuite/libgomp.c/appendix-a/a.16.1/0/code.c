for (i = 0; i < 10000; i++)
{
  index[i] = i % 1000;
  y[i] = 0.0;
}
