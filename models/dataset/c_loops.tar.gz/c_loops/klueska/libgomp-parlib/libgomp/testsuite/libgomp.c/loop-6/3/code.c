for (j = ((0x7fffffffffffffffLL * 2ULL) + 1) - 3; j >= (0x7fffffffffffffffLL + 70ULL); j -= 0x7fffffffffffffffLL + 50ULL)
{
  if (j == (((0x7fffffffffffffffLL * 2ULL) + 1) - 3))
    set(3, 0);
  else
    e = 1;

}
