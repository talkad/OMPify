for (i = 0; i < 50; i++)
  a[i] = (b[i] = i * 1.0);
