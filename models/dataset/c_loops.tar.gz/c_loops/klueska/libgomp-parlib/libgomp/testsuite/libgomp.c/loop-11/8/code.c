for (i = 0; i < 64; i++)
  if (buf[i] != (5 * ((i >= 10) && (i < 54))))
  abort();

