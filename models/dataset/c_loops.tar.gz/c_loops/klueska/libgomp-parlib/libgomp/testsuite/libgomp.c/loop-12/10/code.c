for (idx = 0; idx < 5; idx++)
  if (arr[(4 * 5) + idx] != (idx < 4))
  abort();
else
  arr[(4 * 5) + idx] = 0;

