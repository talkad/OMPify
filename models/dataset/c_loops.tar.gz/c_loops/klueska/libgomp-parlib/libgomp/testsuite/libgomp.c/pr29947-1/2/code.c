for (i = j1; i <= k1; ++i)
{
  if ((i < j2) || (i > k2))
    ++e;

  #pragma omp ordered
  ++c;
}
