for (p = &buf[16]; p < (&buf[51]); p = 4 + p)
  p[2] = 7;
