for (i = 0; i < 2; i++)
  for (j = 0; j < 2; j++)
  for (k = 0; k < 2; k++)
  if (a[i][j][k] != ((i + (j * 4)) + (k * 16)))
  l = 1;



