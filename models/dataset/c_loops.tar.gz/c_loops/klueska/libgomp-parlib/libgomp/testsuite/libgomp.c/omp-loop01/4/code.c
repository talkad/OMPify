for (i = N1; i <= N2; i += step)
  a[i] = 42 + i;
