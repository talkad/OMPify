for (i = 0; i < 50; i++)
{
  c[i] = a[i] + b[i];
  printf("tid= %d i= %d c[i]= %f\n", tid, i, c[i]);
}
