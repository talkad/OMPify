for (int i = 0; i < n; i++)
{
  for (int j = 0; j < n; j++)
    if (b[i][j] != (i + 1))
    abort();


  if (a[i] != (i + 1))
    abort();

}
