for (j = (-0x7fffffff) - 1; j < (-0x7fffffff); j++)
  c++;
