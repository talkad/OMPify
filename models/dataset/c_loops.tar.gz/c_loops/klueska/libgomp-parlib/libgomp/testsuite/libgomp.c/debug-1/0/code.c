for (v6n = 0; v6n < 3; v6n++)
{
  int v6m = v6j + v6k;
  v6i = 8;
  v6l++;
}
