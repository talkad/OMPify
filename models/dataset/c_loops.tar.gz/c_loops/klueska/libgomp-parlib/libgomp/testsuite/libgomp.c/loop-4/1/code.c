for (i = (-0x7fffffffffffffffL) + 30000; i >= ((-0x7fffffffffffffffL) + 10000); i -= 10000)
  if (((i != ((-0x7fffffffffffffffL) + 30000)) && (i != ((-0x7fffffffffffffffL) + 20000))) && (i != ((-0x7fffffffffffffffL) + 10000)))
  e = 1;

