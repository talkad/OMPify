for (i = 0; i < 1024; i++)
{
  a = i;
}
