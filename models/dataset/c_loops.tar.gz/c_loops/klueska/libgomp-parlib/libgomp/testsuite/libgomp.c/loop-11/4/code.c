for (p = &buf[53]; (&buf[9]) < p; --p)
  *p = 5;
