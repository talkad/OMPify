for (i = 0; i < 6; i++)
{
  int v[n];
  int w[(n * 3) + i];
  int j;
  for (j = 0; j < n; j++)
    v[j] = j + omp_get_thread_num();

  for (j = 0; j < ((n * 3) + i); j++)
    w[j] = (j + 10) + omp_get_thread_num();

  check(m, i, v, w);
}
