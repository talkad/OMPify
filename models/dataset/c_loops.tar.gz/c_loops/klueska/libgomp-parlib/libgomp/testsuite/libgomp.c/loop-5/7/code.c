for (p = &buf[40]; p >= (&buf[16]); p = p - 4ULL)
  p[2] = -7;
