for (i = 0; i < 10; i++)
  if (a[i] != (i + 3))
  abort();

