for (i = 0; i < 100; i++)
{
  sum = sum + (a[i] * b[i]);
  printf("  tid= %d i=%d\n", tid, i);
}
