for (j = 20; (0x7fffffffffffffffLL - 70) >= j; j += 0x7fffffffffffffffLL + 50ULL)
{
  if (j == 20)
    set(2, 0);
  else
    e = 1;

}
