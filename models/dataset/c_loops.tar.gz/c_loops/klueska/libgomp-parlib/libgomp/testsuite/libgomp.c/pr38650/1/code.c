for (i = 0; i < j; ++i)
  e++;
