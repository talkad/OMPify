for (i = 0; i < 256; i++)
  if (buf[i] != (2 * i))
  abort();

