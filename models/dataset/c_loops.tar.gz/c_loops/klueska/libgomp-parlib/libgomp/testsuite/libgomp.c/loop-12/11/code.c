for (idx = 0; idx < 5; idx++)
  if (arr[(5 * 5) + idx] != (idx < 5))
  abort();
else
  arr[(5 * 5) + idx] = 0;

