for (i = 0; i < 10; i++)
{
  printf("  A[%d]= ", i);
  for (j = 0; j < 10; j++)
    printf("%.1f ", A[i][j]);

  printf("  b[%d]= %.1f\n", i, b[i]);
}
