for (p = &buf[48]; p > (&buf[15]); p = (-4) + p)
  p[2] = 7;
