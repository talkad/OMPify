for (i = 0; i <= 0; i++)
  c++;
