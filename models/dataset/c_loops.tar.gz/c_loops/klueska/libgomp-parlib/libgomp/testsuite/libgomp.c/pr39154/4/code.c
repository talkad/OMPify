for (int i = 0; i < n; i++)
{
  a[i] = i + 7;
  #pragma omp parallel for shared (n, a, b)
  for (int j = 0; j < n; j++)
    b[i][j] = a[i];

}
