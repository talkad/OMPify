for (p = &buf[40]; (&buf[16]) <= p; p = p - 4ULL)
  p[2] = -7;
