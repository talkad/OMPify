for (k = 0; k < ((sizeof(a)) / (sizeof(a[0]))); k++)
  a[k] = 0x55555555;
