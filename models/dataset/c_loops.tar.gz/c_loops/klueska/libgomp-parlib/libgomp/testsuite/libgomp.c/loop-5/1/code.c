for (p = &buf[3]; p <= (&buf[63]); p += 2)
  p[-2] = 6;
