for (i = 0; i < 100; i++)
{
  c[i] = a[i] + b[i];
  printf("Thread %d: c[%d]= %f\n", tid, i, c[i]);
}
