for (i = 0; i < ((sizeof(array)) / (sizeof(array[0]))); i++)
  array[i] = 0x55555555;
