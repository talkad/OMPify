for (i = -12; i < 21; i += 3)
  j = i;
