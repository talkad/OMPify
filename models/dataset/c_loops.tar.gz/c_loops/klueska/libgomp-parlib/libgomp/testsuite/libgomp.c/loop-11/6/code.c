for (p = &buf[48]; (&buf[15]) < p; p = (-4) + p)
  p[2] = 7;
