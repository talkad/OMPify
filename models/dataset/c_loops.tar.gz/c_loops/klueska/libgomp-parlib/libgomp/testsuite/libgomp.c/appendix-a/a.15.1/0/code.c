for (i = 0; i < n; i++)
  sub2(i);
