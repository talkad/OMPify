for (i = 0; i < 256; i++)
  buf[i] += i;
