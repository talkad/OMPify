for (int i = 0; i > (-1826); i -= 10)
  ;
