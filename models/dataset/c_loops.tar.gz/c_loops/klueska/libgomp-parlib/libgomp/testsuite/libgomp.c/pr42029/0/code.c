for (i = 0; i < 8; ++i)
  c += 1;
