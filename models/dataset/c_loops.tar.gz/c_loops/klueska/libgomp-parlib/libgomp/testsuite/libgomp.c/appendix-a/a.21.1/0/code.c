for (i = lb; i < ub; i += stride)
  work(i);
