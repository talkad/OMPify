for (p = buf; p < (&buf[8]); p++)
  for (q = &buf2[0]; q <= (buf2 + 7); q++)
  sum += ((*p) - '0') + ((*q) - '0');

