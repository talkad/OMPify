for (int i = 0; i < n; i++)
{
  a[i] = i + 1;
  #pragma omp parallel for private (b)
  for (int j = 0; j < n; j++)
    b[i][j] = a[i];

}
