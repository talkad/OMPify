for (i = 0x7fffffffffffffffL - 30001; i <= (0x7fffffffffffffffL - 10001); i += 10000)
  if (((i != (0x7fffffffffffffffL - 30001)) && (i != (0x7fffffffffffffffL - 20001))) && (i != (0x7fffffffffffffffL - 10001)))
  e = 1;

