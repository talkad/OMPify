for (j = 0; j < 1000; j++)
{
  #pragma omp ordered
  check(j);
}
