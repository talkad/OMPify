for (i = 0; i < 50; i++)
{
  if (first_time == 'y')
  {
    tid = omp_get_thread_num();
    first_time = 'n';
  }

  c[i] = a[i] + b[i];
  printf("tid= %d i= %d c[i]= %f\n", tid, i, c[i]);
}
