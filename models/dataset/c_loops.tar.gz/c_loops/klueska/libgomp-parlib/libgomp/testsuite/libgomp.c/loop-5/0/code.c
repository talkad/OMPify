for (p = &buf[10]; p < (&buf[54]); p++)
  *p = 5;
