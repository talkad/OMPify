for (p = &buf[63]; (&buf[3]) <= p; p -= 2)
  p[-2] = 6;
