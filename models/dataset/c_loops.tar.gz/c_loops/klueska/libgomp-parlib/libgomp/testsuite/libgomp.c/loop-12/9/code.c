for (idx = 0; idx < 5; idx++)
  if (arr[(3 * 5) + idx] != (idx < 1))
  abort();
else
  arr[(3 * 5) + idx] = 0;

