for (j = 0x7fffffffffffffffLL - 20000ULL; j <= (0x7fffffffffffffffLL + 10000ULL); j += 10000ULL)
{
  if (j == (0x7fffffffffffffffLL - 20000ULL))
    set(4, 0);
  else
    if (j == (0x7fffffffffffffffLL - 10000ULL))
    set(4, 1);
  else
    if (j == 0x7fffffffffffffffLL)
    set(4, 2);
  else
    if (j == (0x7fffffffffffffffLL + 10000ULL))
    set(4, 3);
  else
    e = 1;




}
