for (j = 0x7fffffff; j >= 0x7fffffff; j--)
  c++;
