for (i = (2U * 0x7fffffff) + 1; i >= ((2U * 0x7fffffff) + 1); i--)
  c++;
