for (i = N1; i <= N2; i += step)
  if (a[i] != b[i])
  abort();

