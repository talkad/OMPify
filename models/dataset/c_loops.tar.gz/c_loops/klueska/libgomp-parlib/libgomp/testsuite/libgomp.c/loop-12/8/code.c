for (idx = 0; idx < 5; idx++)
  if (arr[(2 * 5) + idx] != (idx < 1))
  abort();
else
  arr[(2 * 5) + idx] = 0;

