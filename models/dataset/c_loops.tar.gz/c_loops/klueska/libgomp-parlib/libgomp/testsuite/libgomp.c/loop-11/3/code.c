for (p = &buf[16]; (&buf[40]) >= p; p = p + 4ULL)
  p[2] = -7;
