for (i = N1; i <= N2; i += step)
  b[i] = a[i];
