for (i2 = 0; i2 < 2; i2++)
  for (int j = 0; j < 2; j++)
  for (int k = 0; k < 2; k++)
  if (a[i2][j][k] != ((i2 + (j * 4)) + (k * 16)))
  l = 1;



