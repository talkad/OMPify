for (i = -2; i < m1; i++)
  for (j = m2; j < (-2); j++)
{
  for (k = 13; k < m3; k++)
  {
    if ((omp_get_num_threads() == 8) && (((((i + 2) * 12) + ((j + 5) * 4)) + (k - 13)) != ((omp_get_thread_num() * 9) + (f++))))
      l++;

  }

}

