for (i = 0x7fffffffffffffffLL - 30001; i <= (0x7fffffffffffffffLL - 10001); i += 10000)
{
  if (i == (0x7fffffffffffffffLL - 30001))
    set(0, 0);
  else
    if (i == (0x7fffffffffffffffLL - 20001))
    set(0, 1);
  else
    if (i == (0x7fffffffffffffffLL - 10001))
    set(0, 2);
  else
    e = 1;



}
