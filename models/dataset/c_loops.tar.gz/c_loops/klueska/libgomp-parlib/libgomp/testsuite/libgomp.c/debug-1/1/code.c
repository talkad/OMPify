for (v7n = 0; v7n < 3; v7n++)
{
  int v7m = v7j + v7k;
  v7i = 8;
  v7l++;
}
