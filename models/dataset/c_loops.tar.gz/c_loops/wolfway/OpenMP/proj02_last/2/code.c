for (m = 0; m < omp_get_num_procs(); m++)
{
  if ((*(p_max_Diff + m)) > maxDiff)
    maxDiff = *(p_max_Diff + m);

}
