for (m = 0; m < omp_get_num_procs(); m++)
  *(p_max_Diff + m) = maxDiff;
