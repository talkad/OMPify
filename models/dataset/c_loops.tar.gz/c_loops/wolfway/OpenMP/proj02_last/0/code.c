for (i = 1; i < (MATRIX_SIZE - 1); i++)
  for (j = 1; j < (MATRIX_SIZE - 1); j++)
{
  if ((*even_matrix)[j][i] != 100.0)
  {
    temp_temp = 0.0;
    if (j > 3)
    {
      xx1 = j - 3;
    }
    else
    {
      xx1 = 0;
    }

    if ((MATRIX_SIZE - j) < 3)
    {
      xx2 = MATRIX_SIZE - 1;
    }
    else
    {
      xx2 = j + 3;
    }

    if (i > 3)
    {
      yy1 = i - 3;
    }
    else
    {
      yy1 = 0;
    }

    if ((MATRIX_SIZE - i) < 3)
    {
      yy2 = MATRIX_SIZE - 1;
    }
    else
    {
      yy2 = i + 3;
    }

    for (yy = yy1; yy <= yy2; yy++)
      for (xx = xx1; xx <= xx2; xx++)
    {
      distance = sqrt(pow(xx - j, 2) + pow(yy - i, 2));
      if ((distance != 0) && (distance < 3))
        temp_temp = temp_temp + (((double) ((*even_matrix)[xx][yy] - (*even_matrix)[j][i])) / distance);

    }


    temp_diff = temp_temp / 1000;
    (*odd_matrix)[j][i] = temp_diff + (*even_matrix)[j][i];
    if (fabs(temp_diff) > (*(p_max_Diff + omp_get_thread_num())))
      *(p_max_Diff + omp_get_thread_num()) = fabs(temp_diff);

  }

}

