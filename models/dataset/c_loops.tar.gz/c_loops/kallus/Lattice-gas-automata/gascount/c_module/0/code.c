for (iRow = 0; iRow < H; ++iRow)
{
  long *data = PyArray_GETPTR2(array, iRow, 0);
  long *node_type = PyArray_GETPTR2(node_types, iRow, 0);
  uint32_t *cell_color = PyArray_GETPTR2(cell_colors, iRow, 0);
  for (iCol = 0; iCol < W; ++iCol, ++data, ++cell_color, ++node_type)
  {
    if (iCol < 220)
    {
      nParticles1 += nSetBits[*data];
    }
    else
      if ((iCol >= 220) && (iCol < 485))
    {
      nParticles2 += nSetBits[*data];
    }
    else
    {
      nParticles3 += nSetBits[*data];
    }


  }

}
