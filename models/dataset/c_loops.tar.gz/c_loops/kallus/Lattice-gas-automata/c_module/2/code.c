for (iRow = 0; iRow < H; ++iRow)
{
  long *data = PyArray_GETPTR2(array, iRow, 0);
  long *data_temp = PyArray_GETPTR2(array_temp, iRow, 0);
  long *node_type = PyArray_GETPTR2(node_types, iRow, 0);
  for (iCol = 0; iCol < W; ++iCol, ++data, ++data_temp, ++node_type)
  {
    if (collide[*data] == 0)
    {
      *data_temp = *data;
    }
    else
    {
      *data_temp = collide[*data];
    }

    if ((-1) == (*node_type))
    {
      *data_temp = reverse6(*data_temp);
    }

    if ((-2) == (*node_type))
    {
      double r = ((double) rand()) / ((double) 32767);
      if (r < 0.8)
      {
        int n = rand() % 64;
        *data_temp |= n;
      }

    }

    if ((-3) == (*node_type))
    {
      *data_temp = 0;
    }

  }

}
