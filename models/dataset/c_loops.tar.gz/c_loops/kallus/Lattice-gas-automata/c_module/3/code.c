for (iRow = 0; iRow < H; ++iRow)
{
  double temp_r = rand() / ((double) 32767);
  long *data = PyArray_GETPTR2(array, iRow, 0);
  long *node_type = PyArray_GETPTR2(node_types, iRow, 0);
  long mod_iRowM1 = mod(iRow - 1, H);
  long mod_iRowP1 = mod(iRow + 1, H);
  uint32_t *cell_color = PyArray_GETPTR2(cell_colors, iRow, 0);
  for (iCol = 0; iCol < W; ++iCol, ++data, ++cell_color, ++node_type)
  {
    if ((iCol == 0) || (iCol == (W - 1)))
    {
      if ((iRow % 2) == 0)
      {
        long *nw = PyArray_GETPTR2(array_temp, mod_iRowM1, mod(iCol - 1, W));
        long *ne = PyArray_GETPTR2(array_temp, mod_iRowM1, iCol);
        long *e = PyArray_GETPTR2(array_temp, iRow, mod(iCol + 1, W));
        long *se = PyArray_GETPTR2(array_temp, mod_iRowP1, iCol);
        long *sw = PyArray_GETPTR2(array_temp, mod_iRowP1, mod(iCol - 1, W));
        long *w = PyArray_GETPTR2(array_temp, iRow, mod(iCol - 1, W));
        *data = move6(*nw, *ne, *e, *se, *sw, *w);
      }
      else
      {
        long *nw = PyArray_GETPTR2(array_temp, mod_iRowM1, iCol);
        long *ne = PyArray_GETPTR2(array_temp, mod_iRowM1, mod(iCol + 1, W));
        long *e = PyArray_GETPTR2(array_temp, iRow, mod(iCol + 1, W));
        long *se = PyArray_GETPTR2(array_temp, mod_iRowP1, mod(iCol + 1, W));
        long *sw = PyArray_GETPTR2(array_temp, mod_iRowP1, iCol);
        long *w = PyArray_GETPTR2(array_temp, iRow, mod(iCol - 1, W));
        *data = move6(*nw, *ne, *e, *se, *sw, *w);
      }

    }
    else
    {
      if ((iRow % 2) == 0)
      {
        long *nw = PyArray_GETPTR2(array_temp, mod_iRowM1, iCol - 1);
        long *ne = PyArray_GETPTR2(array_temp, mod_iRowM1, iCol);
        long *e = PyArray_GETPTR2(array_temp, iRow, iCol + 1);
        long *se = PyArray_GETPTR2(array_temp, mod_iRowP1, iCol);
        long *sw = PyArray_GETPTR2(array_temp, mod_iRowP1, iCol - 1);
        long *w = PyArray_GETPTR2(array_temp, iRow, iCol - 1);
        *data = move6(*nw, *ne, *e, *se, *sw, *w);
      }
      else
      {
        long *nw = PyArray_GETPTR2(array_temp, mod_iRowM1, iCol);
        long *ne = PyArray_GETPTR2(array_temp, mod_iRowM1, iCol + 1);
        long *e = PyArray_GETPTR2(array_temp, iRow, iCol + 1);
        long *se = PyArray_GETPTR2(array_temp, mod_iRowP1, iCol + 1);
        long *sw = PyArray_GETPTR2(array_temp, mod_iRowP1, iCol);
        long *w = PyArray_GETPTR2(array_temp, iRow, iCol - 1);
        *data = move6(*nw, *ne, *e, *se, *sw, *w);
      }

    }

    if ((*node_type) != (-1))
    {
      *cell_color = 255 - (nSetBits[*data] * 42);
      if (((temperature != 0) && ((*cell_color) != (255 - (6 * 42)))) && ((*cell_color) != 255))
      {
        long this_temp_r = (((((iCol * iRow) * temp_r) * (*cell_color)) + iCol) + iRow) + temp_r;
        if ((this_temp_r % 100000) < temperature)
        {
          switch (*cell_color)
          {
            case 255 - (1 * 42):
              *data = 255 - random_table1[this_temp_r % size_random1];
              break;

            case 255 - (2 * 42):
              *data = 255 - random_table2[this_temp_r % size_random2];
              break;

            case 255 - (3 * 42):
              *data = 255 - random_table3[this_temp_r % size_random3];
              break;

            case 255 - (4 * 42):
              *data = 255 - random_table4[this_temp_r % size_random4];
              break;

            case 255 - (5 * 42):
              *data = 255 - random_table5[this_temp_r % size_random5];
              break;

            default:
              fprintf(stderr, "Bad magic %ui :(\n", *cell_color);
              break;

          }

        }

      }

      *cell_color = ((((*cell_color) << 24) | ((*cell_color) << 16)) | ((*cell_color) << 8)) | ((*cell_color) << 0);
    }

  }

}
