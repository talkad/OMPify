for (iRow = 0; iRow < H; ++iRow)
{
  long *cell = PyArray_GETPTR2(cells, iRow, 0);
  long *node_type = PyArray_GETPTR2(node_types, iRow, 0);
  for (iCol = 0; iCol < W; ++iCol, ++cell, ++node_type)
  {
    if ((*node_type) > 0)
    {
      long r = rand() % 256;
      if ((*node_type) > r)
      {
        *cell = particle_init;
      }

    }

  }

}
