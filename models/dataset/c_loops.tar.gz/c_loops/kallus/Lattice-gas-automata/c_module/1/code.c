for (iRow = 0; iRow < H; ++iRow)
{
  double temp_r = rand() / ((double) 32767);
  long *data = PyArray_GETPTR2(array, iRow, 0);
  long *node_type = PyArray_GETPTR2(node_types, iRow, 0);
  long mod_iRowM1 = mod(iRow - 1, H);
  long mod_iRowP1 = mod(iRow + 1, H);
  uint32_t *cell_color = PyArray_GETPTR2(cell_colors, iRow, 0);
  for (iCol = 0; iCol < W; ++iCol, ++data, ++cell_color, ++node_type)
  {
    if ((iCol == 0) || (iCol == (W - 1)))
    {
      long *n = PyArray_GETPTR2(array_temp, mod_iRowM1, iCol);
      long *e = PyArray_GETPTR2(array_temp, iRow, mod(iCol + 1, W));
      long *s = PyArray_GETPTR2(array_temp, mod_iRowP1, iCol);
      long *w = PyArray_GETPTR2(array_temp, iRow, mod(iCol - 1, W));
      *data = move4(*n, *e, *s, *w);
    }
    else
    {
      long *n = PyArray_GETPTR2(array_temp, mod_iRowM1, iCol);
      long *e = PyArray_GETPTR2(array_temp, iRow, iCol + 1);
      long *s = PyArray_GETPTR2(array_temp, mod_iRowP1, iCol);
      long *w = PyArray_GETPTR2(array_temp, iRow, iCol - 1);
      *data = move4(*n, *e, *s, *w);
    }

    if ((*node_type) != (-1))
    {
      *cell_color = 255 - (nSetBits[*data] * 63);
      if (((temperature != 0) && ((*cell_color) != 3)) && ((*cell_color) != 255))
      {
        long this_temp_r = (((((iCol * iRow) * temp_r) * (*cell_color)) + iCol) + iRow) + temp_r;
        if ((this_temp_r % 100000) < temperature)
        {
          switch (*cell_color)
          {
            case 255 - (1 * 63):
              *data = 255 - random_table1[this_temp_r % size_random1];
              break;

            case 255 - (2 * 63):
              *data = 255 - random_table2[this_temp_r % size_random2];
              break;

            case 255 - (3 * 63):
              *data = 255 - random_table3[this_temp_r % size_random3];
              break;

            default:
              fprintf(stderr, "Bad magic %ui :(\n", *cell_color);
              break;

          }

        }

      }

      *cell_color = ((((*cell_color) << 24) | ((*cell_color) << 16)) | ((*cell_color) << 8)) | ((*cell_color) << 0);
    }

  }

}
