for (int x = 12; x > 0; x--)
{
  timesec = MatMult(x);
  ((((cout << "# of threads: ") << x) << " Time: ") << (timesec / 1000.0)) << " Seconds \n";
}
