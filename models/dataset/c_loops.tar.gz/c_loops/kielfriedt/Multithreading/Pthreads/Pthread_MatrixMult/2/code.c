for (int i = 0; i < n; i++)
  pthread_join(threads[i], 0);
