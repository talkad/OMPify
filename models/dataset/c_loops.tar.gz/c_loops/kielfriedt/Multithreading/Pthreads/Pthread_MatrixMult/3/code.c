for (int i = 0; i < 50; i++)
  for (int j = 0; j < 50; j++)
{
  a[i][j] = i * j;
  b[i][j] = i * j;
}

