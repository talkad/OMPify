for (int i = 0; i < n; i++)
{
  arg[i].id = i;
  arg[i].ProcessNum = n;
  arg[i].dim = 50;
  arg[i].a = &a;
  arg[i].b = &b;
  arg[i].c = &c;
  pthread_create(&threads[i], &pthread_custom_attr, Worker, (void *) (arg + i));
}
