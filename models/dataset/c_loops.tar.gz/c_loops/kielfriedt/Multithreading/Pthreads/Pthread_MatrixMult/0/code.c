for (int j = 0; j < n; j++)
  for (int k = 0; k < n; k++)
  c[i][j] += a[i][k] * b[k][j];

