for (i = 1; i < my_num_rows; i++)
{
  U_Next[i] = U_Next[i - 1] + ((int) floor(WIDTH / 1.0));
}
