for (j = my_start; j <= my_end; j++)
{
  for (i = 0; i < ((int) floor(WIDTH / 1.0)); i++)
  {
    if (((i + j) % 2) != 0)
    {
      next_ptr[j - my_start][i] = get_val_par(U_Curr_Above, current_ptr, U_Curr_Below, my_rank, i, j) + ((W / 4) * (((((get_val_par(U_Curr_Above, current_ptr, U_Curr_Below, my_rank, i - 1, j) + get_val_par(U_Curr_Above, current_ptr, U_Curr_Below, my_rank, i + 1, j)) + get_val_par(U_Curr_Above, current_ptr, U_Curr_Below, my_rank, i, j - 1)) + get_val_par(U_Curr_Above, current_ptr, U_Curr_Below, my_rank, i, j + 1)) - (4 * get_val_par(U_Curr_Above, current_ptr, U_Curr_Below, my_rank, i, j))) - (pow(1.0, 2) * f(i, j))));
      enforce_bc_par(next_ptr, my_rank, i, j);
    }

  }

}
