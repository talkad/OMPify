for (;;)
{
  method(U_Curr, U_Next);
  local_convergence_sqd = get_convergence_sqd(U_Curr, U_Next, my_rank);
  convergence_sqd = local_convergence_sqd;
  if (my_rank == 0)
  {
    convergence = sqrt(convergence_sqd);
    if (verbose == 1)
    {
      printf("L2 = %f\n", convergence);
      fflush(stdout);
    }

  }

  if (convergence <= EPSILON)
  {
    break;
  }

  for (j = my_start_row; j <= my_end_row; j++)
  {
    for (i = 0; i < ((int) floor(WIDTH / 1.0)); i++)
    {
      U_Curr[j - my_start_row][i] = U_Next[j - my_start_row][i];
    }

  }

  k++;
}
