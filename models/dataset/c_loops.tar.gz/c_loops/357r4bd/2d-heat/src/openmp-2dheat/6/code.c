for (j = my_start; j <= my_end; j++)
{
  for (i = 0; i < ((int) floor(WIDTH / 1.0)); i++)
  {
    sum += pow(next_ptr[global_to_local(rank, j)][i] - current_ptr[global_to_local(rank, j)][i], 2);
  }

}
