for (j = my_start; j <= my_end; j++)
{
  for (i = 0; i < ((int) floor(WIDTH / 1.0)); i++)
  {
    next_ptr[j - my_start][i] = .25 * ((((get_val_par(U_Curr_Above, current_ptr, U_Curr_Below, my_rank, i - 1, j) + get_val_par(U_Curr_Above, current_ptr, U_Curr_Below, my_rank, i + 1, j)) + get_val_par(U_Curr_Above, current_ptr, U_Curr_Below, my_rank, i, j - 1)) + get_val_par(U_Curr_Above, current_ptr, U_Curr_Below, my_rank, i, j + 1)) - (pow(1.0, 2) * f(i, j)));
    enforce_bc_par(next_ptr, my_rank, i, j);
  }

}
