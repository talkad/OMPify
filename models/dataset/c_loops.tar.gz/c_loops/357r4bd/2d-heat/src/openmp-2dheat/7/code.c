for (j = start; j < end; j++)
{
  for (i = 0; i < ((int) floor(WIDTH / 1.0)); i++)
  {
    domain_ptr[j - start][i] = 0.0;
  }

}
