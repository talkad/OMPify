for (index = 0; index < count; index++)
{
  if (check_password(index, cur_salt))
  {
    cracked[index] = 1;
    any_cracked |= 1;
  }

}
