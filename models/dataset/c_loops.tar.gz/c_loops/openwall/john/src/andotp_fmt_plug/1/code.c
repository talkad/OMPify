for (i = 0; i < cs.ctlen; i++)
  cs.ciphertext[i] = (atoi16[ARCH_INDEX(p[2 * i])] << 4) | atoi16[ARCH_INDEX(p[(2 * i) + 1])];
