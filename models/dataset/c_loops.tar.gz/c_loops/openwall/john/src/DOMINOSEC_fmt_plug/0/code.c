for (index = 0; index < count; index += 3)
{
  int i;
  int j;
  if (keys_changed)
  {
    char *k0 = saved_key[index];
    char *k1 = saved_key[index + 1];
    char *k2 = saved_key[index + 2];
    unsigned char digest16[3][16];
    domino_big_md_3((unsigned char *) k0, strlen(k0), (unsigned char *) k1, strlen(k1), (unsigned char *) k2, strlen(k2), digest16[0], digest16[1], digest16[2]);
    for (i = 0, j = 6; i < 14; i++, j += 2)
    {
      const char *hex2 = hex_table[ARCH_INDEX(digest16[0][i])];
      digest34[index][j] = hex2[0];
      digest34[index][j + 1] = hex2[1];
      hex2 = hex_table[ARCH_INDEX(digest16[1][i])];
      digest34[index + 1][j] = hex2[0];
      digest34[index + 1][j + 1] = hex2[1];
      hex2 = hex_table[ARCH_INDEX(digest16[2][i])];
      digest34[index + 2][j] = hex2[0];
      digest34[index + 2][j + 1] = hex2[1];
    }

  }

  if (salt_changed)
  {
    digest34[index + 2][0] = (digest34[index + 1][0] = (digest34[index][0] = saved_salt[0]));
    digest34[index + 2][1] = (digest34[index + 1][1] = (digest34[index][1] = saved_salt[1]));
    digest34[index + 2][2] = (digest34[index + 1][2] = (digest34[index][2] = saved_salt[2]));
    digest34[index + 2][3] = (digest34[index + 1][3] = (digest34[index][3] = saved_salt[3]));
    digest34[index + 2][4] = (digest34[index + 1][4] = (digest34[index][4] = saved_salt[4]));
    digest34[index + 2][5] = (digest34[index + 1][5] = (digest34[index][5] = '('));
  }

  domino_big_md_3_34(digest34[index], digest34[index + 1], digest34[index + 2], (unsigned char *) crypt_out[index], (unsigned char *) crypt_out[index + 1], (unsigned char *) crypt_out[index + 2]);
}
