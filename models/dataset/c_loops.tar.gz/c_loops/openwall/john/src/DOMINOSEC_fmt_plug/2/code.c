for (index = 0; index < count; index++)
  if (!memcmp(binary, crypt_out[index], ARCH_SIZE))
  return 1;

