for (index = 0; index < count; index += 1)
{
  UTF16 Buf[125 + 1];
  unsigned char hash[16];
  unsigned char hex[33];
  int len;
  int cnt;
  int i;
  MD4_CTX ctx;
  cnt = 1;
  if (dirty)
    for (i = 0; i < cnt; ++i)
  {
    len = enc_to_utf16(Buf, 125, (UTF8 *) saved_key[index + i], strlen(saved_key[index + i]));
    if (len < 0)
      len = 0;

    MD4_Init(&ctx);
    MD4_Update(&ctx, Buf, len * 2);
    MD4_Final(hash, &ctx);
    base64_convert(hash, e_b64_raw, 16, hex, e_b64_hex, sizeof(hex), flg_Base64_HEX_UPCASE, 0);
    for (len = 0; len < 32; ++len)
      saved_nt[index + i][len << 1] = hex[len];

  }


  pbkdf2_sha256((unsigned char *) saved_nt[index], 64, AzureAD_cur_salt->salt, AzureAD_cur_salt->salt_len, AzureAD_cur_salt->iterations, (unsigned char *) crypt_out[index], 32, 0);
}
