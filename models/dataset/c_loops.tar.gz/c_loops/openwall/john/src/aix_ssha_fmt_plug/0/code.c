for (index = 0; index < count; index += inc)
{
  int j = index;
  while (j < (index + inc))
  {
    if (cur_salt->type == 1)
    {
      pbkdf2_sha1((const unsigned char *) saved_key[j], strlen(saved_key[j]), cur_salt->salt, strlen((char *) cur_salt->salt), cur_salt->iterations, (unsigned char *) crypt_out[j], 20, 0);
      ++j;
    }
    else
      if (cur_salt->type == 256)
    {
      pbkdf2_sha256((const unsigned char *) saved_key[j], strlen(saved_key[j]), cur_salt->salt, strlen((char *) cur_salt->salt), cur_salt->iterations, (unsigned char *) crypt_out[j], 20, 0);
      ++j;
    }
    else
    {
      pbkdf2_sha512((const unsigned char *) saved_key[j], strlen(saved_key[j]), cur_salt->salt, strlen((char *) cur_salt->salt), cur_salt->iterations, (unsigned char *) crypt_out[j], 20, 0);
      ++j;
    }


  }

}
