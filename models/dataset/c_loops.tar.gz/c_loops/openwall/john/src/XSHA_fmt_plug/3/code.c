for (i = 0; i < count; i++)
{
  if (b0 != crypt_out[i][0])
    continue;

  if (!memcmp(binary, crypt_out[i], 20))
    return 1;

}
