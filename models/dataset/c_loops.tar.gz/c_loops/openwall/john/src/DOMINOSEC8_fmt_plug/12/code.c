for (i = 0; i < 16; i++)
{
  t0 = (checksum[0][i] ^= lotus_magic_table[block0[i] ^ t0]);
  t1 = (checksum[1][i] ^= lotus_magic_table[block1[i] ^ t1]);
  t2 = (checksum[2][i] ^= lotus_magic_table[block2[i] ^ t2]);
}
