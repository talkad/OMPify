for (; j > 0; j--)
{
  t0 = (state[0][(p0 - x[0].c) - 32] ^ block0[(p0 - x[0].c) - 32]) ^ lotus_magic_table[j + t0];
  t1 = (state[1][(p1 - x[1].c) - 32] ^ block1[(p1 - x[1].c) - 32]) ^ lotus_magic_table[j + t1];
  t2 = (state[2][(p2 - x[2].c) - 32] ^ block2[(p2 - x[2].c) - 32]) ^ lotus_magic_table[j + t2];
  *(p0++) = t0;
  *(p1++) = t1;
  *(p2++) = t2;
}
