for (i = 0; i < 16; i++)
{
  uint32_t *q = x.u32;
  p = x.c;
  for (j = 48; j > 0; j--)
  {
    uint32_t u = *(q++);
    t = (*(p++) = u ^ lotus_magic_table[(j--) + t]);
    t = (*(p++) = (u >> 8) ^ lotus_magic_table[(j--) + t]);
    u >>= 16;
    t = (*(p++) = u ^ lotus_magic_table[(j--) + t]);
    t = (*(p++) = (u >> 8) ^ lotus_magic_table[j + t]);
  }

}
