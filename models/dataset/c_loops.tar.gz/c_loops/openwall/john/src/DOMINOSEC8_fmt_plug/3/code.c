for (; j > 0; j--)
{
  t = (state[(p - x.c) - 32] ^ block[(p - x.c) - 32]) ^ lotus_magic_table[j + t];
  *(p++) = t;
}
