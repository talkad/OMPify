for (j = 48; j > 32; j--)
{
  t = state[p - x.c] ^ lotus_magic_table[j + t];
  *(p++) = t;
}
