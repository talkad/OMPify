for (j = 48; j > 32; j--)
{
  t0 = state[0][p0 - x[0].c] ^ lotus_magic_table[j + t0];
  t1 = state[1][p1 - x[1].c] ^ lotus_magic_table[j + t1];
  t2 = state[2][p2 - x[2].c] ^ lotus_magic_table[j + t2];
  *(p0++) = t0;
  *(p1++) = t1;
  *(p2++) = t2;
}
