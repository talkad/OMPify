for (i = 0; i < 16; i++)
{
  c = lotus_magic_table[block[i] ^ t];
  t = (checksum[i] ^= c);
}
