for (index = 0; index < count; index += 1)
{
  SHA256_CTX ctx;
  if (dirty)
  {
    SHA256_Init(&prep_ctx[index]);
    SHA256_Update(&prep_ctx[index], prep_key[index], 510);
  }

  memcpy(&ctx, &prep_ctx[index], sizeof(ctx));
  SHA256_Update(&ctx, prep_key[index] + (510 / 2), 8);
  SHA256_Final((unsigned char *) crypt_out[index], &ctx);
}
