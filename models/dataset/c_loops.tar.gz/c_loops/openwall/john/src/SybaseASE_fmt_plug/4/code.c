for (index = 0; index < count; index++)
  if ((*((uint32_t *) binary)) == (*((uint32_t *) crypt_out[index])))
  return 1;

