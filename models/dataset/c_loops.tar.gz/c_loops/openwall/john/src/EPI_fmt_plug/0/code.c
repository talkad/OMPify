for (i = 0; i < count; ++i)
{
  SHA_CTX ctx;
  SHA1_Init(&ctx);
  SHA1_Update(&ctx, (unsigned char *) global_salt, 30 - 1);
  SHA1_Update(&ctx, saved_key[i], key_len[i]);
  SHA1_Final((unsigned char *) crypt_out[i], &ctx);
}
