for (n = 2; (n < 62) && (atoi16u[ARCH_INDEX(ciphertext[n])] != 0x7F); ++n)
  ;
