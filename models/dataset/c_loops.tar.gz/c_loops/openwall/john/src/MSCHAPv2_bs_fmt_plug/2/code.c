for (; (*pos2) != '$'; pos2++)
  if (atoi16[ARCH_INDEX(*pos2)] == 0x7F)
  return 0;

