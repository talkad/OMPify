for (i = 0; i < 6; i = i + 2)
{
  ptr = DES_do_IP(&block[i]);
  out[i] = ptr[1];
  out[i + 1] = ptr[0];
}
