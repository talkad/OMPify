for (i = 0; i < 8; i++)
{
  pos[i << 1] = itoa16[digest[i] >> 4];
  pos[(i << 1) + 1] = itoa16[digest[i] & 0xF];
}
