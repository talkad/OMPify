for (i = (sizeof("$MSCHAPv2$")) - 1; (i < ((((13 + 256) + 64) + 48) + 1)) && (j < 3); i++)
{
  if ((out[i] >= 'A') && (out[i] <= 'Z'))
    out[i] |= 0x20;
  else
    if (out[i] == '$')
    j++;


}
