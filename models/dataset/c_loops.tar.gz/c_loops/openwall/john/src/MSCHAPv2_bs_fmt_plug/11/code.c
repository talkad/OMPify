for (i = 0; i < count; i++)
{
  int len;
  len = E_md4hash((uchar *) saved_plain[i], saved_len[i], saved_key[i]);
  if (len <= 0)
    saved_plain[i][-len] = 0;

  setup_des_key(saved_key[i], i);
}
