for (index = 0; index < count; index++)
  if (!memcmp(output[index], binary, 8))
  return 1;

