for (y = 0; y < (1 * omp_para); y++)
  for (x = 0; x < SIMD_COEF_32; x++)
{
  if (((MD5_word *) binary)[0] == ((MD5_word *) sout)[x + ((y * SIMD_COEF_32) * 4)])
    return 1;

}

