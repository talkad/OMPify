for (t = 0; t < omp_para; t++)
  md5cryptsse((unsigned char *) (&saved_key[t * MD5_N]), cursalt, (char *) (&sout[((t * MD5_N) * 16) / (sizeof(MD5_word))]), CryptType);
