for (index = 0; index < count; index += 1)
{
  hash_plugin_check_hash(index);
}
