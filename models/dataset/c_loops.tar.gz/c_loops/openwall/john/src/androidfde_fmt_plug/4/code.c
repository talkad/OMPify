for (i = 0; i < SSE_GROUP_SZ_SHA1; ++i)
{
  lens[i] = strlen(saved_key[index + i]);
  pin[i] = (unsigned char *) saved_key[index + i];
  x.pout[i] = (uint32_t *) Keycandidate[i];
}
