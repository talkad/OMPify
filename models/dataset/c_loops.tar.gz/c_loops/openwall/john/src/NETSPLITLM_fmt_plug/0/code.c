for (i = 0; i < count; i++)
{
  setup_des_key(saved_pre[i], &ks);
  DES_ecb_encrypt((DES_cblock *) challenge, (DES_cblock *) output[i], &ks, 1);
}
