for (index = 0; index < count; index += SSE_GROUP_SZ_SHA1)
{
  unsigned char master[32];
  pbkdf2_sha1((unsigned char *) saved_key[index], strlen(saved_key[index]), cur_salt->salt[0], cur_salt->saltlen[0], cur_salt->iterations[0], master, 16, 0);
  if (akcdecrypt(master, cur_salt->ct[0]) == 0)
    cracked[index] = 1;
  else
    cracked[index] = 0;

}
