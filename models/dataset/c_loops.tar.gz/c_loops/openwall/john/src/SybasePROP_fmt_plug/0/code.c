for (index = 0; index < count; index++)
{
  generate_hash((unsigned char *) saved_key[index], saved_salt, (unsigned char *) crypt_out[index]);
}
