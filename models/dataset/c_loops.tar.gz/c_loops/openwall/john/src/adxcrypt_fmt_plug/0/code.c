for (index = 0; index < count; index++)
{
  adxcrypt(saved_key[index], (unsigned char *) crypt_out[index], strlen(saved_key[index]));
}
