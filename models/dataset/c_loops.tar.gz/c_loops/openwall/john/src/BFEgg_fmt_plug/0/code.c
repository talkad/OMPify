for (index = 0; index < count; index++)
{
  if (saved_key[index][0] != 0)
    blowfish_encrypt_pass(saved_key[index], (char *) crypt_out[index]);

}
