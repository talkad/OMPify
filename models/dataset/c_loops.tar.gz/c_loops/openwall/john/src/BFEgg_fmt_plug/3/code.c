for (pos = _itoa64; pos <= (&_itoa64[63]); pos++)
  JtR_atoi64[ARCH_INDEX(*pos)] = pos - _itoa64;
