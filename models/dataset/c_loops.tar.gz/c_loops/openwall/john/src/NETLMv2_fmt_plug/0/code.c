for (i = 0; i < count; i++)
{
  unsigned char ntlm_v2_hash[16];
  HMACMD5Context ctx;
  if (!keys_prepared)
  {
    int len;
    unsigned char ntlm[16];
    len = E_md4hash(saved_plain[i], saved_len[i], ntlm);
    hmac_md5_init_K16(ntlm, &saved_ctx[i]);
    if (len <= 0)
      saved_plain[i][-len] = 0;

  }

  memcpy(&ctx, &saved_ctx[i], sizeof(ctx));
  hmac_md5_update(&challenge[17], (int) challenge[16], &ctx);
  hmac_md5_final(ntlm_v2_hash, &ctx);
  hmac_md5(ntlm_v2_hash, challenge, 16, (unsigned char *) output[i]);
}
