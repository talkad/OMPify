for (pos = ciphertext + ((sizeof("$NETLMv2$")) - 1); (*pos) != '$'; pos++)
  ;
