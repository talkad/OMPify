for (index = 0; index < count; index++)
  if (!memcmp(output[index], binary, 16))
  return 1;

