for (pos2 = pos; (*pos2) != '$'; pos2++)
  if (((unsigned char) (*pos2)) < 0x20)
  return 0;

