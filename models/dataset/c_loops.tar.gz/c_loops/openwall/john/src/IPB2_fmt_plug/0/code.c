for (index = 0; index < count; index++)
{
  MD5_CTX ctx;
  MD5_Init(&ctx);
  MD5_Update(&ctx, saved_key[index], (16 * 2) * 2);
  MD5_Final((unsigned char *) crypt_key[index], &ctx);
}
