for (i = 0; i < 16; ++i)
  binary_cipher[i] = (atoi16[ARCH_INDEX(ciphertext[i * 2])] << 4) + atoi16[ARCH_INDEX(ciphertext[(i * 2) + 1])];
