for (index = 0; index < (threads * (SIMD_COEF_32 * 1)); index++)
  memcpy(saved_key[index], salt, 16 * 2);
