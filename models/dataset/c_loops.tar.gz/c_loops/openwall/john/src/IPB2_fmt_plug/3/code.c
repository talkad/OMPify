for (i = 0; i < 16; ++i)
{
  ((char *) hex_salt)[i * 2] = itoa16[ARCH_INDEX(salt_hash[i] >> 4)];
  ((char *) hex_salt)[(i * 2) + 1] = itoa16[ARCH_INDEX(salt_hash[i] & 0x0f)];
}
