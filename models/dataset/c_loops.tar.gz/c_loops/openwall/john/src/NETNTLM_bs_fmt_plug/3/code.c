for (i = 0; i < 64; i++)
{
  cnt = DES_IP[i ^ 0x20];
  j = (unsigned char) ((binary_salt[cnt >> 3] >> (7 - (cnt & 7))) & 1);
  temp[i / 8] |= j << (7 - (i % 8));
}
