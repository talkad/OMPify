for (pos++; atoi16[ARCH_INDEX(*pos)] != 0x7F; pos++)
  ;
