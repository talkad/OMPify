for (index = 0; index < count; index += SIMD_COEF_64 * SIMD_PARA_SHA512)
{
  SHA512_CTX ctx;
  SHA512_Init(&ctx);
  SHA512_Update(&ctx, &saved_salt, 4);
  SHA512_Update(&ctx, saved_key[index], saved_len[index]);
  SHA512_Final((unsigned char *) crypt_out[index], &ctx);
}
