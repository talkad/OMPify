for (index = 0; index < count; index += SIMD_COEF_64 * SIMD_PARA_SHA512)
{
  SHA512_CTX ctx;
  memcpy(&ctx, &ctx_salt, sizeof(ctx));
  SHA512_Update(&ctx, saved_key[index], saved_len[index]);
  SHA512_Final((unsigned char *) crypt_out[index], &ctx);
}
