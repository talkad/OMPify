for (round = 0; round < rounds; round++)
{
  if (sevenzip_salt->SaltSize)
    SHA256_Update(&sha, sevenzip_salt->salt, sevenzip_salt->SaltSize);

  SHA256_Update(&sha, (char *) saved_key[index], saved_len[index]);
  SHA256_Update(&sha, temp, 8);
  for (i = 0; i < 8; i++)
    if ((++temp[i]) != 0)
    break;


}
