for (index = 0; index < count; index++)
{
  if (new_keys)
    sevenzip_kdf(index, master[index]);

  cracked[index] = sevenzip_decrypt(master[index]);
}
