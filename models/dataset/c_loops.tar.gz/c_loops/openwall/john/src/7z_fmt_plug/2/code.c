for (index = 0; index < count; index++)
  if (cracked[index])
  return 1;

