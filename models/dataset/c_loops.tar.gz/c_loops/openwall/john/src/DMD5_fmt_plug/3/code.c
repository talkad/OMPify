for (index = 0; index < count; index++)
  if (crypt_key[index][0] == b)
  return 1;

