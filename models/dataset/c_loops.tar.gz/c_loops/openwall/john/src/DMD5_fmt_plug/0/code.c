for (index = 0; index < count; index++)
{
  unsigned char hash[16];
  unsigned char hex_hash[2 * 16];
  unsigned char *ptr_src;
  unsigned char *ptr_dst;
  MD5_CTX ctx;
  int i;
  MD5_Init(&ctx);
  MD5_Update(&ctx, cur_salt->login_id, cur_salt->login_id_len);
  MD5_Update(&ctx, saved_key[index], strlen(saved_key[index]));
  MD5_Final(hash, &ctx);
  MD5_Init(&ctx);
  MD5_Update(&ctx, hash, 16);
  MD5_Update(&ctx, cur_salt->nonces, cur_salt->nonces_len);
  MD5_Final(hash, &ctx);
  ptr_src = hash;
  ptr_dst = hex_hash;
  for (i = 0; i < 16; ++i)
  {
    unsigned char v = *(ptr_src++);
    *(ptr_dst++) = itoa16_shr_04[ARCH_INDEX(v)];
    *(ptr_dst++) = itoa16_and_0f[ARCH_INDEX(v)];
  }

  MD5_Init(&ctx);
  MD5_Update(&ctx, hex_hash, 2 * 16);
  MD5_Update(&ctx, cur_salt->prehash_KD, cur_salt->prehash_KD_len);
  MD5_Final((unsigned char *) crypt_key[index], &ctx);
}
