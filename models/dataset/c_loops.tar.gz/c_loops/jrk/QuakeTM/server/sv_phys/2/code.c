for (bumpcount = 0; bumpcount < numbumps; bumpcount++)
{
  for (i = 0; i < 3; i++)
    end[i] = ent->v.origin[i] + (time_left * ent->v.velocity[i]);

  trace = SV_Move(ent->v.origin, ent->v.mins, ent->v.maxs, end, 0, ent);
  if (trace.allsolid)
  {
    VectorCopy(vec3_origin, ent->v.velocity);
    return 3;
  }

  if (trace.fraction > 0)
  {
    VectorCopy(trace.endpos, ent->v.origin);
    VectorCopy(ent->v.velocity, original_velocity);
    numplanes = 0;
  }

  if (trace.fraction == 1)
    break;

  if (!trace.ent)
    SV_Error("SV_FlyMove: !trace.ent");

  if (trace.plane.normal[2] > 0.7)
  {
    blocked |= 1;
    if (trace.ent->v.solid == SOLID_BSP)
    {
      ent->v.flags = ((int) ent->v.flags) | FL_ONGROUND;
      ent->v.groundentity = EDICT_TO_PROG(trace.ent);
    }

  }

  if (!trace.plane.normal[2])
  {
    blocked |= 2;
    if (steptrace)
      *steptrace = trace;

  }

  SV_Impact(ent, trace.ent);
  if (ent->free)
    break;

  time_left -= time_left * trace.fraction;
  if (numplanes >= 5)
  {
    VectorCopy(vec3_origin, ent->v.velocity);
    return 3;
  }

  VectorCopy(trace.plane.normal, planes[numplanes]);
  numplanes++;
  for (i = 0; i < numplanes; i++)
  {
    ClipVelocity(original_velocity, planes[i], new_velocity, 1);
    for (j = 0; j < numplanes; j++)
      if (j != i)
    {
      if (DotProduct(new_velocity, planes[j]) < 0)
        break;

    }


    if (j == numplanes)
      break;

  }

  if (i != numplanes)
  {
    VectorCopy(new_velocity, ent->v.velocity);
  }
  else
  {
    if (numplanes != 2)
    {
      VectorCopy(vec3_origin, ent->v.velocity);
      return 7;
    }

    CrossProduct(planes[0], planes[1], dir);
    d = DotProduct(dir, ent->v.velocity);
    VectorScale(dir, d, ent->v.velocity);
  }

  if (DotProduct(ent->v.velocity, primal_velocity) <= 0)
  {
    VectorCopy(vec3_origin, ent->v.velocity);
    return blocked;
  }

}
