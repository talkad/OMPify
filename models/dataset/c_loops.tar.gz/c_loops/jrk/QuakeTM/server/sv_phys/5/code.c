for (i = 0; i < 3; i++)
  move[i] = pusher->v.velocity[i] * movetime;
