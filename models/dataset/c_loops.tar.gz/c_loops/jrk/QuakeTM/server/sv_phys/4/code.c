for (e = 1; e < sv.num_edicts; e++, check = NEXT_EDICT(check))
{
  if (check->free)
    continue;

  if (((check->v.movetype == MOVETYPE_PUSH) || (check->v.movetype == MOVETYPE_NONE)) || (check->v.movetype == MOVETYPE_NOCLIP))
    continue;

  pusher->v.solid = SOLID_NOT;
  block = SV_TestEntityPosition(check);
  pusher->v.solid = SOLID_BSP;
  if (block)
    continue;

  if (!((((int) check->v.flags) & FL_ONGROUND) && (PROG_TO_EDICT(check->v.groundentity) == pusher)))
  {
    if ((((((check->v.absmin[0] >= maxs[0]) || (check->v.absmin[1] >= maxs[1])) || (check->v.absmin[2] >= maxs[2])) || (check->v.absmax[0] <= mins[0])) || (check->v.absmax[1] <= mins[1])) || (check->v.absmax[2] <= mins[2]))
      continue;

    if (!SV_TestEntityPosition(check))
      continue;

  }

  VectorCopy(check->v.origin, moved_from[num_moved]);
  moved_edict[num_moved] = check;
  num_moved++;
  VectorAdd(check->v.origin, move, check->v.origin);
  block = SV_TestEntityPosition(check);
  if (!block)
  {
    SV_LinkEdict(check, 0);
    continue;
  }

  VectorSubtract(check->v.origin, move, check->v.origin);
  block = SV_TestEntityPosition(check);
  if (!block)
  {
    num_moved--;
    continue;
  }

  if (check->v.mins[0] == check->v.maxs[0])
  {
    SV_LinkEdict(check, 0);
    continue;
  }

  if ((check->v.solid == SOLID_NOT) || (check->v.solid == SOLID_TRIGGER))
  {
    check->v.mins[0] = (check->v.mins[1] = 0);
    VectorCopy(check->v.mins, check->v.maxs);
    SV_LinkEdict(check, 0);
    continue;
  }

  VectorCopy(pushorig, pusher->v.origin);
  SV_LinkEdict(pusher, 0);
  if (pusher->v.blocked)
  {
    pr_global_struct->self = EDICT_TO_PROG(pusher);
    pr_global_struct->other = EDICT_TO_PROG(check);
    PR_ExecuteProgram(pusher->v.blocked);
  }

  for (i = 0; i < num_moved; i++)
  {
    VectorCopy(moved_from[i], moved_edict[i]->v.origin);
    SV_LinkEdict(moved_edict[i], 0);
  }

  return 0;
}
