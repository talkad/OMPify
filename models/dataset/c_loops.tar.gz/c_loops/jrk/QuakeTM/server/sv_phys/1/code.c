for (i = 0; i < 3; i++)
{
  change = normal[i] * backoff;
  out[i] = in[i] - change;
  if ((out[i] > (-0.1)) && (out[i] < 0.1))
    out[i] = 0;

}
