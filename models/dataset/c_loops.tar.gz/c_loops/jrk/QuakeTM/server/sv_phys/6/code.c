for (i = 0; i < sv.num_edicts; i++, ent = NEXT_EDICT(ent))
{
  if (ent->free)
    continue;

  if (pr_global_struct->force_retouch)
    SV_LinkEdict(ent, 1);

  if ((i > 0) && (i <= MAX_CLIENTS))
    continue;

  SV_RunEntity(ent);
  SV_RunNewmis();
}
