for (int y = 0; y < HEI; y++)
  for (int x = 0; x < WID; x++)
{
  float d = 0;
  int i = 0;
  do
    d += F[i] * rsqrt(((X[i] - x) * (X[i] - x)) + ((Y[i] - y) * (Y[i] - y)));
  while ((++i) < ms);
  memcpy(manor + (((((HEI - 1) - y) * WID) + x) * 3), col[(d > 255) ? (255) : ((d < 0) ? (0) : ((unsigned char) d))], 3);
}

