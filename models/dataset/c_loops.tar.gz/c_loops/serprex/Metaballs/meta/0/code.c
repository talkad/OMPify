for (int y = 0; y < HEI; y++)
  for (int x = 0; x < WID; x++)
{
  float d = 0;
  int i = 0;
  int D = _mm_setzero_ps();
  do
  {
    int xx = _mm_sub_ps(_mm_load_ps(X + i), _mm_set1_ps(x));
    int yy = _mm_sub_ps(_mm_load_ps(Y + i), _mm_set1_ps(y));
    D = _mm_add_ps(D, _mm_mul_ps(_mm_load_ps(F + i), _mm_rsqrt_ps(_mm_add_ps(_mm_mul_ps(xx, xx), _mm_mul_ps(yy, yy)))));
  }
  while ((i += 4) < ms);
  const int f = _mm_add_ps(D, _mm_movehl_ps(D, D));
  _mm_store_ss(&d, _mm_add_ss(f, _mm_shuffle_ps(f, f, 1)));
  memcpy(manor + (((((HEI - 1) - y) * WID) + x) * 3), col[(d > 255) ? (255) : ((d < 0) ? (0) : ((unsigned char) d))], 3);
}

