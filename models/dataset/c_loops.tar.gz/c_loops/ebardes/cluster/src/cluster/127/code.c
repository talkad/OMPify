for (i = 0; i < nrows; i++)
{
  cdata[i] = malloc(2 * (sizeof(double)));
  cmask[i] = malloc(2 * (sizeof(int)));
}
