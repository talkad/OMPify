for (i = 0; i < nelements; i++)
{
  double d = 0.0;
  j = clusterid[i];
  for (k = 0; k < nelements; k++)
  {
    if ((i == k) || (clusterid[k] != j))
      continue;

    d += (i < k) ? (distance[k][i]) : (distance[i][k]);
    if (d > errors[j])
      break;

  }

  if (d < errors[j])
  {
    errors[j] = d;
    centroids[j] = i;
  }

}
