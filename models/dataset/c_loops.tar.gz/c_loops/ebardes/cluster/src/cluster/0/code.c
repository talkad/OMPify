for (i = 0; i < nelements; i++)
{
  double distance;
  k = tclusterid[i];
  if (counts[k] == 1)
    continue;

  distance = metric(ndata, data, cdata, mask, cmask, weight, i, k, transpose);
  for (j = 0; j < nclusters; j++)
  {
    double tdistance;
    if (j == k)
      continue;

    tdistance = metric(ndata, data, cdata, mask, cmask, weight, i, j, transpose);
    if (tdistance < distance)
    {
      distance = tdistance;
      counts[tclusterid[i]]--;
      tclusterid[i] = j;
      counts[j]++;
    }

  }

  total += distance;
}
