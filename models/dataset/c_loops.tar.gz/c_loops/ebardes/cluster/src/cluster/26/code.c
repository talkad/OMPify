for (i = 0; i < ncolumns; i++)
  w[i] = temp[i];
