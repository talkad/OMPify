for (i = 0; i < n; i++)
{
  if (mask1[index1][i] && mask2[index2][i])
  {
    double term = data1[index1][i] - data2[index2][i];
    result += (weight[i] * term) * term;
    tweight += weight[i];
  }

}
