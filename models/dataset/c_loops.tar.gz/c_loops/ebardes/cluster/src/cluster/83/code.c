for (i = 0; i < nelements; i++)
  index[i] = i;
