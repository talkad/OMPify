for (i = 0; i < nnodes; i++)
{
  i1 = tree[i].left;
  i2 = tree[i].right;
  if (i1 < 0)
  {
    index = (-i1) - 1;
    order1 = nodeorder[index];
    counts1 = nodecounts[index];
  }
  else
  {
    order1 = order[i1];
    counts1 = 1;
  }

  if (i2 < 0)
  {
    index = (-i2) - 1;
    order2 = nodeorder[index];
    counts2 = nodecounts[index];
  }
  else
  {
    order2 = order[i2];
    counts2 = 1;
  }

  if (order1 > order2)
  {
    tree[i].left = i2;
    tree[i].right = i1;
  }

  nodecounts[i] = counts1 + counts2;
  nodeorder[i] = ((counts1 * order1) + (counts2 * order2)) / (counts1 + counts2);
}
