for (i = 0; i < nrows; i++)
{
  for (j = 0; j < nclusters; j++)
  {
    cdata[i][j] = 0.;
    cmask[i][j] = 0;
  }

}
