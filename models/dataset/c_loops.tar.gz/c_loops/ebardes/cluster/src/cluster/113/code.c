for (i = 0; i < n2; i++)
{
  int index = index2[i];
  if ((index < 0) || (index >= ncolumns))
    return -1.0;

}
