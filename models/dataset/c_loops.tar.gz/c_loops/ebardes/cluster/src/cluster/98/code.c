for (i = 0; i < nelements; i++)
{
  j = (int) (i + ((nelements - i) * uniform()));
  ix = index[j];
  index[j] = index[i];
  index[i] = ix;
}
