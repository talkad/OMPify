for (j = 0; j < ncolumns; j++)
{
  for (i = 0; i < nrows; i++)
    temp[i] = u[index[i]][j];

  for (i = 0; i < nrows; i++)
    u[i][j] = temp[i];

}
