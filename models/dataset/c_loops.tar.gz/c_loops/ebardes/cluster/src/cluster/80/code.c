for (i = 0; i < nnodes; i++)
  vector[i] = i;
