for (i = 0; i < nclusters; i++)
{
  for (j = 0; j < ncolumns; j++)
  {
    if (cmask[i][j] > 0)
    {
      cdata[i][j] /= cmask[i][j];
      cmask[i][j] = 1;
    }

  }

}
