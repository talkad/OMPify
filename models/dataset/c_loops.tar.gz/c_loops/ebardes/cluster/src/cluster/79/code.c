for (inode = 0; inode < nnodes; inode++)
{
  int is = 1;
  int js = 0;
  result[inode].distance = find_closest_pair(nelements - inode, distmatrix, &is, &js);
  result[inode].left = distid[js];
  result[inode].right = distid[is];
  for (i = 0; i < ndata; i++)
  {
    data[js][i] = (data[js][i] * mask[js][i]) + (data[is][i] * mask[is][i]);
    mask[js][i] += mask[is][i];
    if (mask[js][i])
      data[js][i] /= mask[js][i];

  }

  free(data[is]);
  free(mask[is]);
  data[is] = data[nnodes - inode];
  mask[is] = mask[nnodes - inode];
  distid[is] = distid[nnodes - inode];
  for (i = 0; i < is; i++)
    distmatrix[is][i] = distmatrix[nnodes - inode][i];

  for (i = is + 1; i < (nnodes - inode); i++)
    distmatrix[i][is] = distmatrix[nnodes - inode][i];

  distid[js] = (-inode) - 1;
  for (i = 0; i < js; i++)
    distmatrix[js][i] = metric(ndata, data, data, mask, mask, weight, js, i, 0);

  for (i = js + 1; i < (nnodes - inode); i++)
    distmatrix[i][js] = metric(ndata, data, data, mask, mask, weight, js, i, 0);

}
