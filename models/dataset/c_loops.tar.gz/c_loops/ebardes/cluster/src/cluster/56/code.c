for (i = 0; i < nrows; i++)
{
  for (j = 0; j < nclusters; j++)
  {
    if (cmask[i][j] > 0)
    {
      cdata[i][j] /= cmask[i][j];
      cmask[i][j] = 1;
    }

  }

}
