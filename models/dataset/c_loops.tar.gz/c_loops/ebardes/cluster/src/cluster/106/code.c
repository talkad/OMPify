for (i = 0; i < nrows; i++)
  free(dummymask[i]);
