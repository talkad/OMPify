for (j = 0; j < nrows; j++)
{
  const double s = w[j];
  for (i = 0; i < nrows; i++)
    v[i][j] *= s;

}
