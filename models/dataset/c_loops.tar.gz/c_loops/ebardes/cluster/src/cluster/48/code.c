for (i = 0; i < (nclusters - 1); i++)
{
  p = 1.0 / (nclusters - i);
  j = binomial(n, p);
  n -= j;
  j += k + 1;
  for (; k < j; k++)
    clusterid[k] = i;

}
