for (i = 0; i < ncolumns; i++)
  temp[i] = w[index[i]];
