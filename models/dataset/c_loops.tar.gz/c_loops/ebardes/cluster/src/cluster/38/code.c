for (i = 0; i < n; i++)
{
  if (mask1[i][index1] && mask2[i][index2])
  {
    double term1 = data1[i][index1];
    double term2 = data2[i][index2];
    double w = weight[i];
    sum1 += w * term1;
    sum2 += w * term2;
    result += (w * term1) * term2;
    denom1 += (w * term1) * term1;
    denom2 += (w * term2) * term2;
    tweight += w;
  }

}
