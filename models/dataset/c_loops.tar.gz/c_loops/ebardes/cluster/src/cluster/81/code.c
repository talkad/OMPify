for (i = 0; i < nrows; i++)
{
  double *temp;
  temp = malloc(nnodes * (sizeof(double)));
  result[i].distance = DBL_MAX;
  for (j = 0; j < i; j++)
    temp[j] = distmatrix[i][j];

  for (j = 0; j < i; j++)
  {
    k = vector[j];
    if (result[j].distance >= temp[j])
    {
      if (result[j].distance < temp[k])
        temp[k] = result[j].distance;

      result[j].distance = temp[j];
      vector[j] = i;
    }
    else
      if (temp[j] < temp[k])
      temp[k] = temp[j];


  }

  for (j = 0; j < i; j++)
  {
    if (result[j].distance >= result[vector[j]].distance)
      vector[j] = i;

  }

}
