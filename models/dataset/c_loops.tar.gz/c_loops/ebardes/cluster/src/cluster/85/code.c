for (j = 0; j < nelements; j++)
  clusterid[j] = j;
