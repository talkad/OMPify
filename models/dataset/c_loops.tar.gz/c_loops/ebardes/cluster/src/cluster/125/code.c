for (j = 0; j < ncolumns; j++)
{
  int count = 0;
  for (k = 0; k < n2; k++)
  {
    i = index2[k];
    if (mask[i][j])
    {
      temp[count] = data[i][j];
      count++;
    }

  }

  if (count > 0)
  {
    cdata[1][j] = median(count, temp);
    cmask[1][j] = 1;
  }
  else
  {
    cdata[1][j] = 0.;
    cmask[1][j] = 0;
  }

}
