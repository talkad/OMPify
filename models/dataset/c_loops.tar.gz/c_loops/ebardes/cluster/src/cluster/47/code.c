for (i = y; i < m; f /= (aa / (++i)) - s)
  ;
