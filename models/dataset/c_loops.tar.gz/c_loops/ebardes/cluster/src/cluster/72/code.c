for (i = 1; i < n; i++)
{
  matrix[i] = malloc(i * (sizeof(double)));
  if (matrix[i] == 0)
    break;

}
