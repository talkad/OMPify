for (i = 1; i < n; i++)
{
  for (j = 0; j < i; j++)
  {
    matrix[i][j] = metric(ndata, data, data, mask, mask, weights, i, j, transpose);
  }

}
