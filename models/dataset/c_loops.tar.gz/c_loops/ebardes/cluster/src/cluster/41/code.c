for (i = 0; i < n; i++)
{
  if (mask1[index1][i] && mask2[index2][i])
  {
    tdata1[m] = data1[index1][i];
    tdata2[m] = data2[index2][i];
    m++;
  }

}
