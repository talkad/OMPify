for (i = 0; i < n; i++)
{
  if (mask1[i][index1] && mask2[i][index2])
  {
    for (j = 0; j < i; j++)
    {
      if (mask1[j][index1] && mask2[j][index2])
      {
        double x1 = data1[i][index1];
        double x2 = data1[j][index1];
        double y1 = data2[i][index2];
        double y2 = data2[j][index2];
        if ((x1 < x2) && (y1 < y2))
          con++;

        if ((x1 > x2) && (y1 > y2))
          con++;

        if ((x1 < x2) && (y1 > y2))
          dis++;

        if ((x1 > x2) && (y1 < y2))
          dis++;

        if ((x1 == x2) && (y1 != y2))
          exx++;

        if ((x1 != x2) && (y1 == y2))
          exy++;

        flag = 1;
      }

    }

  }

}
