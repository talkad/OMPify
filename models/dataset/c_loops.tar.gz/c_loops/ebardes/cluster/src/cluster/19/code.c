for (i = m - 1; i >= 0; i--)
{
  l = i + 1;
  g = w[i];
  if (i != (m - 1))
    for (j = l; j < m; j++)
    u[j][i] = 0.0;


  if (g != 0.0)
  {
    if (i != (m - 1))
    {
      for (j = l; j < m; j++)
      {
        s = 0.0;
        for (k = l; k < n; k++)
          s += u[i][k] * u[j][k];

        f = (s / u[i][i]) / g;
        for (k = i; k < n; k++)
          u[j][k] += f * u[i][k];

      }

    }

    for (j = i; j < n; j++)
      u[i][j] /= g;

  }
  else
    for (j = i; j < n; j++)
    u[i][j] = 0.0;


  u[i][i] += 1.0;
}
