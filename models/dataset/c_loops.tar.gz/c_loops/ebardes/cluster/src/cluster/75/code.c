for (i = 0; i < nelements; i++)
  result[i] = 1.0 / result[i];
