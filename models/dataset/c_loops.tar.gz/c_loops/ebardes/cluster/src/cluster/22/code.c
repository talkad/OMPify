for (i = 0; i < (ncolumns / 2); i++)
{
  j = index[i];
  index[i] = index[(ncolumns - 1) - i];
  index[(ncolumns - 1) - i] = j;
}
