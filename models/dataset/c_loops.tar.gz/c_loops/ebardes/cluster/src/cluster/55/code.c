for (k = 0; k < ncolumns; k++)
{
  i = clusterid[k];
  for (j = 0; j < nrows; j++)
  {
    if (mask[j][k] != 0)
    {
      cdata[j][i] += data[j][k];
      cmask[j][i]++;
    }

  }

}
