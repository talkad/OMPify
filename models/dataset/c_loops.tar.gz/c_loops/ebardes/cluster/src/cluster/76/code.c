for (i = 0; i < nelements; i++)
  distid[i] = i;
