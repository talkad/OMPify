for (i = 0; i < m; i++)
{
  l = i + 1;
  rv1[i] = scale * g;
  g = 0.0;
  s = 0.0;
  scale = 0.0;
  for (k = i; k < n; k++)
    scale += fabs(u[i][k]);

  if (scale != 0.0)
  {
    for (k = i; k < n; k++)
    {
      u[i][k] /= scale;
      s += u[i][k] * u[i][k];
    }

    f = u[i][i];
    g = (f >= 0) ? (-sqrt(s)) : (sqrt(s));
    h = (f * g) - s;
    u[i][i] = f - g;
    if (i < (m - 1))
    {
      for (j = l; j < m; j++)
      {
        s = 0.0;
        for (k = i; k < n; k++)
          s += u[i][k] * u[j][k];

        f = s / h;
        for (k = i; k < n; k++)
          u[j][k] += f * u[i][k];

      }

    }

    for (k = i; k < n; k++)
      u[i][k] *= scale;

  }

  w[i] = scale * g;
  g = 0.0;
  s = 0.0;
  scale = 0.0;
  if (i < (m - 1))
  {
    for (k = l; k < m; k++)
      scale += fabs(u[k][i]);

    if (scale != 0.0)
    {
      for (k = l; k < m; k++)
      {
        u[k][i] /= scale;
        s += u[k][i] * u[k][i];
      }

      f = u[l][i];
      g = (f >= 0) ? (-sqrt(s)) : (sqrt(s));
      h = (f * g) - s;
      u[l][i] = f - g;
      for (k = l; k < m; k++)
        rv1[k] = u[k][i] / h;

      for (j = l; j < n; j++)
      {
        s = 0.0;
        for (k = l; k < m; k++)
          s += u[k][j] * u[k][i];

        for (k = l; k < m; k++)
          u[k][j] += s * rv1[k];

      }

      for (k = l; k < m; k++)
        u[k][i] *= scale;

    }

  }

  anorm = max(anorm, fabs(w[i]) + fabs(rv1[i]));
}
