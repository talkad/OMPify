for (i = 0; i < n; i++)
{
  if (mask1[i][index1] && mask2[i][index2])
  {
    tdata1[m] = data1[i][index1];
    tdata2[m] = data2[i][index2];
    m++;
  }

}
