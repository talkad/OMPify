for (i = n - 1; i >= 0; i--)
{
  if (i < (n - 1))
  {
    if (g != 0.0)
    {
      for (j = l; j < n; j++)
        vt[i][j] = (u[i][j] / u[i][l]) / g;

      for (j = l; j < n; j++)
      {
        s = 0.0;
        for (k = l; k < n; k++)
          s += u[i][k] * vt[j][k];

        for (k = l; k < n; k++)
          vt[j][k] += s * vt[i][k];

      }

    }

  }

  for (j = l; j < n; j++)
  {
    vt[j][i] = 0.0;
    vt[i][j] = 0.0;
  }

  vt[i][i] = 1.0;
  g = rv1[i];
  l = i;
}
