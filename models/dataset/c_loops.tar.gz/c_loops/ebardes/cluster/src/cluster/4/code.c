for (k = lo; k <= j; k++)
  xmax = max(xmax, x[k]);
