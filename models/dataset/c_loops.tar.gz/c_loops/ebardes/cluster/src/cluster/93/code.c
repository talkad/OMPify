for (i = 0; i < nelements; i++)
{
  int n = 0;
  for (j = 0; j < ndata; j++)
  {
    if (mask[i][j])
    {
      double term = data[i][j];
      term = term * term;
      stddata[i] += term;
      n++;
    }

  }

  if (stddata[i] > 0)
    stddata[i] = sqrt(stddata[i] / n);
  else
    stddata[i] = 1;

}
