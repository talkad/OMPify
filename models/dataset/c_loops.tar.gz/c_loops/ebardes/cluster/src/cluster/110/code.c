for (i = 0; i < n1; i++)
{
  int index = index1[i];
  if ((index < 0) || (index >= nrows))
    return -1.0;

}
