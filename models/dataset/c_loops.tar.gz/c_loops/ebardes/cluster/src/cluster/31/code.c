for (i = 0; i < nrows; i++)
  temp[i] = w[index[i]];
