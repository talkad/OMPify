for (i = m; i < y; f *= (aa / (++i)) - s)
  ;
