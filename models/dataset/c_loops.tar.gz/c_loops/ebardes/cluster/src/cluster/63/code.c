for (i = 0; i < nelements; i++)
  saved[i] = tclusterid[i];
