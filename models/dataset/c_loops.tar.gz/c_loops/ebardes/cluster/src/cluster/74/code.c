for (i = 0; i < nelements; i++)
{
  result[i] += 1.0;
  for (j = 0; j < i; j++)
  {
    const double distance = metric(ndata, data, data, mask, mask, weights, i, j, transpose);
    if (distance < cutoff)
    {
      const double dweight = exp(exponent * log(1 - (distance / cutoff)));
      result[i] += dweight;
      result[j] += dweight;
    }

  }

}
