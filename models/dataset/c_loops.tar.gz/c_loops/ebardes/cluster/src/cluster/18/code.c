for (i = m - 1; i >= 0; i--)
{
  if (i < (m - 1))
  {
    if (g != 0.0)
    {
      for (j = l; j < m; j++)
        vt[j][i] = (u[j][i] / u[l][i]) / g;

      for (j = l; j < m; j++)
      {
        s = 0.0;
        for (k = l; k < m; k++)
          s += u[k][i] * vt[k][j];

        for (k = l; k < m; k++)
          vt[k][j] += s * vt[k][i];

      }

    }

  }

  for (j = l; j < m; j++)
  {
    vt[i][j] = 0.0;
    vt[j][i] = 0.0;
  }

  vt[i][i] = 1.0;
  g = rv1[i];
  l = i;
}
