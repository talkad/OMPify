for (iter = 0; iter < niter; iter++)
{
  int ixbest = 0;
  int iybest = 0;
  int iobject = iter % nelements;
  iobject = index[iobject];
  if (transpose == 0)
  {
    double closest = metric(ndata, data, celldata[ixbest], mask, dummymask, weights, iobject, iybest, transpose);
    double radius = maxradius * (1. - (((double) iter) / ((double) niter)));
    double tau = inittau * (1. - (((double) iter) / ((double) niter)));
    for (ix = 0; ix < nxgrid; ix++)
    {
      for (iy = 0; iy < nygrid; iy++)
      {
        double distance = metric(ndata, data, celldata[ix], mask, dummymask, weights, iobject, iy, transpose);
        if (distance < closest)
        {
          ixbest = ix;
          iybest = iy;
          closest = distance;
        }

      }

    }

    for (ix = 0; ix < nxgrid; ix++)
    {
      for (iy = 0; iy < nygrid; iy++)
      {
        if (sqrt(((ix - ixbest) * (ix - ixbest)) + ((iy - iybest) * (iy - iybest))) < radius)
        {
          double sum = 0.;
          for (i = 0; i < ndata; i++)
          {
            if (mask[iobject][i] == 0)
              continue;

            celldata[ix][iy][i] += tau * ((data[iobject][i] / stddata[iobject]) - celldata[ix][iy][i]);
          }

          for (i = 0; i < ndata; i++)
          {
            double term = celldata[ix][iy][i];
            term = term * term;
            sum += term;
          }

          if (sum > 0)
          {
            sum = sqrt(sum / ndata);
            for (i = 0; i < ndata; i++)
              celldata[ix][iy][i] /= sum;

          }

        }

      }

    }

  }
  else
  {
    double closest;
    double **celldatavector = malloc(ndata * (sizeof(double *)));
    double radius = maxradius * (1. - (((double) iter) / ((double) niter)));
    double tau = inittau * (1. - (((double) iter) / ((double) niter)));
    for (i = 0; i < ndata; i++)
      celldatavector[i] = &celldata[ixbest][iybest][i];

    closest = metric(ndata, data, celldatavector, mask, dummymask, weights, iobject, 0, transpose);
    for (ix = 0; ix < nxgrid; ix++)
    {
      for (iy = 0; iy < nygrid; iy++)
      {
        double distance;
        for (i = 0; i < ndata; i++)
          celldatavector[i] = &celldata[ixbest][iybest][i];

        distance = metric(ndata, data, celldatavector, mask, dummymask, weights, iobject, 0, transpose);
        if (distance < closest)
        {
          ixbest = ix;
          iybest = iy;
          closest = distance;
        }

      }

    }

    free(celldatavector);
    for (ix = 0; ix < nxgrid; ix++)
    {
      for (iy = 0; iy < nygrid; iy++)
      {
        if (sqrt(((ix - ixbest) * (ix - ixbest)) + ((iy - iybest) * (iy - iybest))) < radius)
        {
          double sum = 0.;
          for (i = 0; i < ndata; i++)
          {
            if (mask[i][iobject] == 0)
              continue;

            celldata[ix][iy][i] += tau * ((data[i][iobject] / stddata[iobject]) - celldata[ix][iy][i]);
          }

          for (i = 0; i < ndata; i++)
          {
            double term = celldata[ix][iy][i];
            term = term * term;
            sum += term;
          }

          if (sum > 0)
          {
            sum = sqrt(sum / ndata);
            for (i = 0; i < ndata; i++)
              celldata[ix][iy][i] /= sum;

          }

        }

      }

    }

  }

}
