for (i = 0; i < nrows; i++)
{
  free(count[i]);
  free(cdata[i]);
  free(cmask[i]);
}
