for (ix = 0; ix < nxgrid; ix++)
{
  for (iy = 0; iy < nygrid; iy++)
  {
    double sum = 0.;
    for (i = 0; i < ndata; i++)
    {
      double term = (-1.0) + (2.0 * uniform());
      celldata[ix][iy][i] = term;
      sum += term * term;
    }

    sum = sqrt(sum / ndata);
    for (i = 0; i < ndata; i++)
      celldata[ix][iy][i] /= sum;

  }

}
