for (i = 0; i < n; i++)
  rank[index[i]] = i;
