for (i = 0; i < n; i++)
  index[i] = i;
