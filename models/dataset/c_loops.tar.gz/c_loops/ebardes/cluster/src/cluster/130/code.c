for (i = 0; i < nrows; i++)
{
  free(cdata[i]);
  free(cmask[i]);
}
