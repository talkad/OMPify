for (j = 0; j < ncolumns; j++)
{
  const double s = w[j];
  for (i = 0; i < nrows; i++)
    u[i][j] *= s;

}
