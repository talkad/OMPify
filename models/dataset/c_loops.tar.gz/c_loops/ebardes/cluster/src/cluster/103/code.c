for (i = 0; i < nrows; i++)
{
  int ixbest = 0;
  int iybest = 0;
  double closest = metric(ndata, data, celldata[ixbest], mask, dummymask, weights, i, iybest, transpose);
  int ix;
  int iy;
  for (ix = 0; ix < nxgrid; ix++)
  {
    for (iy = 0; iy < nygrid; iy++)
    {
      double distance = metric(ndata, data, celldata[ix], mask, dummymask, weights, i, iy, transpose);
      if (distance < closest)
      {
        ixbest = ix;
        iybest = iy;
        closest = distance;
      }

    }

  }

  clusterid[i][0] = ixbest;
  clusterid[i][1] = iybest;
}
