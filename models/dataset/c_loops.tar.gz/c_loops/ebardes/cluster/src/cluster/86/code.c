for (n = nelements; n > 1; n--)
{
  int is = 1;
  int js = 0;
  result[nelements - n].distance = find_closest_pair(n, distmatrix, &is, &js);
  for (j = 0; j < js; j++)
    distmatrix[js][j] = max(distmatrix[is][j], distmatrix[js][j]);

  for (j = js + 1; j < is; j++)
    distmatrix[j][js] = max(distmatrix[is][j], distmatrix[j][js]);

  for (j = is + 1; j < n; j++)
    distmatrix[j][js] = max(distmatrix[j][is], distmatrix[j][js]);

  for (j = 0; j < is; j++)
    distmatrix[is][j] = distmatrix[n - 1][j];

  for (j = is + 1; j < (n - 1); j++)
    distmatrix[j][is] = distmatrix[n - 1][j];

  result[nelements - n].left = clusterid[is];
  result[nelements - n].right = clusterid[js];
  clusterid[js] = (n - nelements) - 1;
  clusterid[is] = clusterid[n - 1];
}
