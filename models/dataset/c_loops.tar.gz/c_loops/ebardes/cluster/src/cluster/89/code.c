for (i = 1; i < nelements; i++)
  free(distmatrix[i]);
