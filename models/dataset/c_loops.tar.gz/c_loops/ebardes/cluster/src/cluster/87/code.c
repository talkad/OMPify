for (j = 0; j < nelements; j++)
{
  number[j] = 1;
  clusterid[j] = j;
}
