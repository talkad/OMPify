for (i = 0; i < nrows; i++)
{
  for (j = 0; j < ncolumns; j++)
    temp[j] = u[i][index[j]];

  for (j = 0; j < ncolumns; j++)
    u[i][j] = temp[j];

}
