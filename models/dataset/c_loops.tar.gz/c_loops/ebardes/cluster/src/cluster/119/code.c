for (i = 0; i < n1; i++)
{
  k = index1[i];
  for (j = 0; j < nrows; j++)
  {
    if (mask[j][k] != 0)
    {
      cdata[j][0] = cdata[j][0] + data[j][k];
      count[j][0] = count[j][0] + 1;
    }

  }

}
