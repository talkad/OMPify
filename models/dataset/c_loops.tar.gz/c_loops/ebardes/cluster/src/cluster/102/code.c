for (i = 0; i < nygrid; i++)
{
  dummymask[i] = malloc(ncolumns * (sizeof(int)));
  for (j = 0; j < ncolumns; j++)
    dummymask[i][j] = 1;

}
