for (j = 0; j < nrows; j++)
{
  int count = 0;
  for (k = 0; k < n1; k++)
  {
    i = index1[k];
    if (mask[j][i])
    {
      temp[count] = data[j][i];
      count++;
    }

  }

  if (count > 0)
  {
    cdata[j][0] = median(count, temp);
    cmask[j][0] = 1;
  }
  else
  {
    cdata[j][0] = 0.;
    cmask[j][0] = 0;
  }

}
