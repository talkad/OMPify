for (i = 0; i < n; i++)
{
  free(mask[i]);
  free(data[i]);
}
