for (j = 0; j < nelements; j++)
{
  clusterid[j] = centroids[tclusterid[j]];
}
