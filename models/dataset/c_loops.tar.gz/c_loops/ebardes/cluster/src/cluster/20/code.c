for (k = m - 1; k >= 0; k--)
{
  k1 = k - 1;
  its = 0;
  while (1)
  {
    for (l = k; l >= 0; l--)
    {
      l1 = l - 1;
      if ((fabs(rv1[l]) + anorm) == anorm)
        break;

      if ((fabs(w[l1]) + anorm) == anorm)
      {
        c = 0.0;
        s = 1.0;
        for (i = l; i <= k; i++)
        {
          f = s * rv1[i];
          rv1[i] *= c;
          if ((fabs(f) + anorm) == anorm)
            break;

          g = w[i];
          h = sqrt((f * f) + (g * g));
          w[i] = h;
          c = g / h;
          s = (-f) / h;
          for (j = 0; j < n; j++)
          {
            y = u[l1][j];
            z = u[i][j];
            u[l1][j] = (y * c) + (z * s);
            u[i][j] = ((-y) * s) + (z * c);
          }

        }

        break;
      }

    }

    z = w[k];
    if (l == k)
    {
      if (z < 0.0)
      {
        w[k] = -z;
        for (j = 0; j < m; j++)
          vt[j][k] = -vt[j][k];

      }

      break;
    }
    else
      if (its == 30)
    {
      ierr = k;
      break;
    }
    else
    {
      its++;
      x = w[l];
      y = w[k1];
      g = rv1[k1];
      h = rv1[k];
      f = (((y - z) * (y + z)) + ((g - h) * (g + h))) / ((2.0 * h) * y);
      g = sqrt((f * f) + 1.0);
      f = (((x - z) * (x + z)) + (h * ((y / (f + ((f >= 0) ? (g) : (-g)))) - h))) / x;
      c = 1.0;
      s = 1.0;
      for (i1 = l; i1 <= k1; i1++)
      {
        i = i1 + 1;
        g = rv1[i];
        y = w[i];
        h = s * g;
        g = c * g;
        z = sqrt((f * f) + (h * h));
        rv1[i1] = z;
        c = f / z;
        s = h / z;
        f = (x * c) + (g * s);
        g = ((-x) * s) + (g * c);
        h = y * s;
        y = y * c;
        for (j = 0; j < m; j++)
        {
          x = vt[j][i1];
          z = vt[j][i];
          vt[j][i1] = (x * c) + (z * s);
          vt[j][i] = ((-x) * s) + (z * c);
        }

        z = sqrt((f * f) + (h * h));
        w[i1] = z;
        if (z != 0.0)
        {
          c = f / z;
          s = h / z;
        }

        f = (c * g) + (s * y);
        x = ((-s) * g) + (c * y);
        for (j = 0; j < n; j++)
        {
          y = u[i1][j];
          z = u[i][j];
          u[i1][j] = (y * c) + (z * s);
          u[i][j] = ((-y) * s) + (z * c);
        }

      }

      rv1[l] = 0.0;
      rv1[k] = f;
      w[k] = x;
    }


  }

}
