for (i = 0; i < ncolumns; i++)
{
  for (j = 0; j < ncolumns; j++)
    temp[j] = v[index[j]][i];

  for (j = 0; j < ncolumns; j++)
    v[j][i] = temp[j];

}
