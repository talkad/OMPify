for (n = nelements; n > 1; n--)
{
  int sum;
  int is = 1;
  int js = 0;
  result[nelements - n].distance = find_closest_pair(n, distmatrix, &is, &js);
  result[nelements - n].left = clusterid[is];
  result[nelements - n].right = clusterid[js];
  sum = number[is] + number[js];
  for (j = 0; j < js; j++)
  {
    distmatrix[js][j] = (distmatrix[is][j] * number[is]) + (distmatrix[js][j] * number[js]);
    distmatrix[js][j] /= sum;
  }

  for (j = js + 1; j < is; j++)
  {
    distmatrix[j][js] = (distmatrix[is][j] * number[is]) + (distmatrix[j][js] * number[js]);
    distmatrix[j][js] /= sum;
  }

  for (j = is + 1; j < n; j++)
  {
    distmatrix[j][js] = (distmatrix[j][is] * number[is]) + (distmatrix[j][js] * number[js]);
    distmatrix[j][js] /= sum;
  }

  for (j = 0; j < is; j++)
    distmatrix[is][j] = distmatrix[n - 1][j];

  for (j = is + 1; j < (n - 1); j++)
    distmatrix[j][is] = distmatrix[n - 1][j];

  number[js] = sum;
  number[is] = number[n - 1];
  clusterid[js] = (n - nelements) - 1;
  clusterid[is] = clusterid[n - 1];
}
