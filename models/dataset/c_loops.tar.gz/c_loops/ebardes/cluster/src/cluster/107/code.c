for (i = 0; i < nxgrid; i++)
{
  celldata[i] = malloc((nygrid * ndata) * (sizeof(double *)));
  for (j = 0; j < nygrid; j++)
    celldata[i][j] = malloc(ndata * (sizeof(double)));

}
