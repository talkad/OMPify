for (i = 0; i < 2; i++)
  for (j = 0; j < ncolumns; j++)
{
  if (count[i][j] > 0)
  {
    cdata[i][j] = cdata[i][j] / count[i][j];
    cmask[i][j] = 1;
  }
  else
    cmask[i][j] = 0;

}

