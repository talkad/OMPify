for (i = 0; i < nelements; i++)
{
  j = tclusterid[i];
  k = clusterid[i];
  if (mapping[k] == (-1))
    mapping[k] = j;
  else
    if (mapping[k] != j)
  {
    if (total < (*error))
    {
      ifound = 1;
      *error = total;
      for (j = 0; j < nelements; j++)
        clusterid[j] = tclusterid[j];

    }

    break;
  }


}
