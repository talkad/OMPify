for (i = 0; i < nelements; i++)
{
  if (clusterid[i] != centroids[tclusterid[i]])
  {
    if (total < (*error))
    {
      *ifound = 1;
      *error = total;
      for (j = 0; j < nelements; j++)
      {
        clusterid[j] = centroids[tclusterid[j]];
      }

    }

    break;
  }

}
