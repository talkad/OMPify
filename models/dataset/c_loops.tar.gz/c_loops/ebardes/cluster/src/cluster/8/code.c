for (j = i; j < (i + m); j++)
  rank[index[j]] = value;
