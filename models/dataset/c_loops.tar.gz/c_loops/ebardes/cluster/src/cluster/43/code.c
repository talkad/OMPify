for (i = 0; i < m; i++)
{
  const double value1 = rank1[i];
  const double value2 = rank2[i];
  result += value1 * value2;
  denom1 += value1 * value1;
  denom2 += value2 * value2;
}
