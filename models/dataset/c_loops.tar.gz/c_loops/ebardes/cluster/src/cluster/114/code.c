for (i = 0; i < n1; i++)
{
  k = index1[i];
  for (j = 0; j < ncolumns; j++)
    if (mask[k][j] != 0)
  {
    cdata[0][j] = cdata[0][j] + data[k][j];
    count[0][j] = count[0][j] + 1;
  }


}
