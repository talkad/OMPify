for (i = 0; i < nelements; i++)
  clusterid[i] = 0;
