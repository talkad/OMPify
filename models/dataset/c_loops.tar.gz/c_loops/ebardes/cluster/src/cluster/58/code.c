for (i = 0; i < nclusters; i++)
{
  for (j = 0; j < nrows; j++)
  {
    int count = 0;
    for (k = 0; k < ncolumns; k++)
    {
      if ((i == clusterid[k]) && mask[j][k])
      {
        cache[count] = data[j][k];
        count++;
      }

    }

    if (count > 0)
    {
      cdata[j][i] = median(count, cache);
      cmask[j][i] = 1;
    }
    else
    {
      cdata[j][i] = 0.;
      cmask[j][i] = 0;
    }

  }

}
