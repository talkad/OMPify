for (i = 0; i < nelements; i++)
  if (saved[i] != tclusterid[i])
  break;

