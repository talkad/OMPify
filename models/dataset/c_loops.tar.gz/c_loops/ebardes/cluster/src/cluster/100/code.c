for (i = 0; i < nygrid; i++)
  free(dummymask[i]);
