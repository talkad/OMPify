for (i = 0; i < n2; i++)
{
  k = index2[i];
  for (j = 0; j < nrows; j++)
  {
    if (mask[j][k] != 0)
    {
      cdata[j][1] = cdata[j][1] + data[j][k];
      count[j][1] = count[j][1] + 1;
    }

  }

}
