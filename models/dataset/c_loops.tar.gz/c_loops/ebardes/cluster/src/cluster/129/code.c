for (j = 0; j < nrows; j++)
{
  int count = 0;
  for (k = 0; k < n2; k++)
  {
    i = index2[k];
    if (mask[j][i])
    {
      temp[count] = data[j][i];
      count++;
    }

  }

  if (count > 0)
  {
    cdata[j][1] = median(count, temp);
    cmask[j][1] = 1;
  }
  else
  {
    cdata[j][1] = 0.;
    cmask[j][1] = 0;
  }

}
