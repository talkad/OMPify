for (j = 0; j < nrows; j++)
{
  for (i = 0; i < nrows; i++)
    temp[i] = v[j][index[i]];

  for (i = 0; i < nrows; i++)
    v[j][i] = temp[i];

}
