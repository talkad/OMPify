for (i = 0; i < nclusters; i++)
{
  for (j = 0; j < ncolumns; j++)
  {
    int count = 0;
    for (k = 0; k < nrows; k++)
    {
      if ((i == clusterid[k]) && mask[k][j])
      {
        cache[count] = data[k][j];
        count++;
      }

    }

    if (count > 0)
    {
      cdata[i][j] = median(count, cache);
      cmask[i][j] = 1;
    }
    else
    {
      cdata[i][j] = 0.;
      cmask[i][j] = 0;
    }

  }

}
