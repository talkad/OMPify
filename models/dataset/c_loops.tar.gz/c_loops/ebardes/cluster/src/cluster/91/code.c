for (i = 0; i < nnodes; i++)
{
  i1 = tree[i].left;
  i2 = tree[i].right;
  counts1 = (i1 < 0) ? (nodecounts[(-i1) - 1]) : (1);
  counts2 = (i2 < 0) ? (nodecounts[(-i2) - 1]) : (1);
  nodecounts[i] = counts1 + counts2;
}
