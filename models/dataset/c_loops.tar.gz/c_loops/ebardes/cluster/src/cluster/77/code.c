for (i = 0; i < nelements; i++)
{
  for (j = 0; j < ndata; j++)
  {
    newdata[i][j] = data[j][i];
    newmask[i][j] = mask[j][i];
  }

}
