for (i = 0; i < n; i++)
{
  l = i + 1;
  rv1[i] = scale * g;
  g = 0.0;
  s = 0.0;
  scale = 0.0;
  for (k = i; k < m; k++)
    scale += fabs(u[k][i]);

  if (scale != 0.0)
  {
    for (k = i; k < m; k++)
    {
      u[k][i] /= scale;
      s += u[k][i] * u[k][i];
    }

    f = u[i][i];
    g = (f >= 0) ? (-sqrt(s)) : (sqrt(s));
    h = (f * g) - s;
    u[i][i] = f - g;
    if (i < (n - 1))
    {
      for (j = l; j < n; j++)
      {
        s = 0.0;
        for (k = i; k < m; k++)
          s += u[k][i] * u[k][j];

        f = s / h;
        for (k = i; k < m; k++)
          u[k][j] += f * u[k][i];

      }

    }

    for (k = i; k < m; k++)
      u[k][i] *= scale;

  }

  w[i] = scale * g;
  g = 0.0;
  s = 0.0;
  scale = 0.0;
  if (i < (n - 1))
  {
    for (k = l; k < n; k++)
      scale += fabs(u[i][k]);

    if (scale != 0.0)
    {
      for (k = l; k < n; k++)
      {
        u[i][k] /= scale;
        s += u[i][k] * u[i][k];
      }

      f = u[i][l];
      g = (f >= 0) ? (-sqrt(s)) : (sqrt(s));
      h = (f * g) - s;
      u[i][l] = f - g;
      for (k = l; k < n; k++)
        rv1[k] = u[i][k] / h;

      for (j = l; j < m; j++)
      {
        s = 0.0;
        for (k = l; k < n; k++)
          s += u[j][k] * u[i][k];

        for (k = l; k < n; k++)
          u[j][k] += s * rv1[k];

      }

      for (k = l; k < n; k++)
        u[i][k] *= scale;

    }

  }

  anorm = max(anorm, fabs(w[i]) + fabs(rv1[i]));
}
