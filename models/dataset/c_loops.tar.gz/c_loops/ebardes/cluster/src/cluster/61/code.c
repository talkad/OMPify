for (i = 0; i < nclusters; i++)
  counts[i] = 0;
