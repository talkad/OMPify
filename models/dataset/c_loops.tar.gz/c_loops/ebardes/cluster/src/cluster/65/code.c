for (i = 0; i < nclusters; i++)
  mapping[i] = -1;
