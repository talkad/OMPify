for (i = 0; i < nelements; i++)
{
  double distance = DBL_MAX;
  for (icluster = 0; icluster < nclusters; icluster++)
  {
    double tdistance;
    j = centroids[icluster];
    if (i == j)
    {
      distance = 0.0;
      tclusterid[i] = icluster;
      break;
    }

    tdistance = (i > j) ? (distmatrix[i][j]) : (distmatrix[j][i]);
    if (tdistance < distance)
    {
      distance = tdistance;
      tclusterid[i] = icluster;
    }

  }

  total += distance;
}
