for (i = 0; i < ncolumns; i++)
{
  double closest;
  int ix;
  int iy;
  for (j = 0; j < ndata; j++)
    celldatavector[j] = &celldata[ixbest][iybest][j];

  closest = metric(ndata, data, celldatavector, mask, dummymask, weights, i, 0, transpose);
  for (ix = 0; ix < nxgrid; ix++)
  {
    for (iy = 0; iy < nygrid; iy++)
    {
      double distance;
      for (j = 0; j < ndata; j++)
        celldatavector[j] = &celldata[ix][iy][j];

      distance = metric(ndata, data, celldatavector, mask, dummymask, weights, i, 0, transpose);
      if (distance < closest)
      {
        ixbest = ix;
        iybest = iy;
        closest = distance;
      }

    }

  }

  clusterid[i][0] = ixbest;
  clusterid[i][1] = iybest;
}
