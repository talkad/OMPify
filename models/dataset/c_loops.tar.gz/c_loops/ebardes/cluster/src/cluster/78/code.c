for (i = 0; i < nelements; i++)
{
  memcpy(newdata[i], data[i], ndata * (sizeof(double)));
  memcpy(newmask[i], mask[i], ndata * (sizeof(int)));
}
