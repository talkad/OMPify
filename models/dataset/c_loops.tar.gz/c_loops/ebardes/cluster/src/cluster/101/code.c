for (i = 0; i < ndata; i++)
  free(dummymask[i]);
