for (i = 0; i < nrows; i++)
  w[i] = temp[i];
