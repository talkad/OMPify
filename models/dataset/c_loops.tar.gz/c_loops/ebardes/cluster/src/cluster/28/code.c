for (i = 0; i < (nrows / 2); i++)
{
  j = index[i];
  index[i] = index[(nrows - 1) - i];
  index[(nrows - 1) - i] = j;
}
