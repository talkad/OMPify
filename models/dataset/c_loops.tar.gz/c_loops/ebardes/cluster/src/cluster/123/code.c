for (i = 0; i < 2; i++)
{
  cdata[i] = malloc(ncolumns * (sizeof(double)));
  cmask[i] = malloc(ncolumns * (sizeof(int)));
}
