for (i1 = 0; i1 < n1; i1++)
  for (i2 = 0; i2 < n2; i2++)
{
  double distance;
  j1 = index1[i1];
  j2 = index2[i2];
  distance = metric(n, data, data, mask, mask, weight, j1, j2, transpose);
  if (distance < mindistance)
    mindistance = distance;

}

