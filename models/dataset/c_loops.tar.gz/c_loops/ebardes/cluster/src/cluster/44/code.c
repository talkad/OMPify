for (i = 0; i < n; i++)
{
  if (mask1[index1][i] && mask2[index2][i])
  {
    for (j = 0; j < i; j++)
    {
      if (mask1[index1][j] && mask2[index2][j])
      {
        double x1 = data1[index1][i];
        double x2 = data1[index1][j];
        double y1 = data2[index2][i];
        double y2 = data2[index2][j];
        if ((x1 < x2) && (y1 < y2))
          con++;

        if ((x1 > x2) && (y1 > y2))
          con++;

        if ((x1 < x2) && (y1 > y2))
          dis++;

        if ((x1 > x2) && (y1 < y2))
          dis++;

        if ((x1 == x2) && (y1 != y2))
          exx++;

        if ((x1 != x2) && (y1 == y2))
          exy++;

        flag = 1;
      }

    }

  }

}
