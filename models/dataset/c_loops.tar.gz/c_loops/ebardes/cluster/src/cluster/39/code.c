for (i = 0; i < n; i++)
{
  if (mask1[index1][i] && mask2[index2][i])
  {
    double term1 = data1[index1][i];
    double term2 = data2[index2][i];
    double w = weight[i];
    result += (w * term1) * term2;
    denom1 += (w * term1) * term1;
    denom2 += (w * term2) * term2;
    flag = 1;
  }

}
