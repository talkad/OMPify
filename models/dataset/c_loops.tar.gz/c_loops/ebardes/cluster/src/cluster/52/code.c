for (k = 0; k < nrows; k++)
{
  i = clusterid[k];
  for (j = 0; j < ncolumns; j++)
  {
    if (mask[k][j] != 0)
    {
      cdata[i][j] += data[k][j];
      cmask[i][j]++;
    }

  }

}
