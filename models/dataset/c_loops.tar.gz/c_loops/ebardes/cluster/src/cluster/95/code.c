for (i = 0; i < nygrid; i++)
{
  dummymask[i] = malloc(ndata * (sizeof(int)));
  for (j = 0; j < ndata; j++)
    dummymask[i][j] = 1;

}
