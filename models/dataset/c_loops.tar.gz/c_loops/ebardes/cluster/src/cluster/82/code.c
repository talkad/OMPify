for (i = 0; i < nnodes; i++)
  result[i].left = i;
