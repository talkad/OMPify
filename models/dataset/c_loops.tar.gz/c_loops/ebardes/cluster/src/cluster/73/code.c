for (i = 1; i < j; i++)
  free(matrix[i]);
