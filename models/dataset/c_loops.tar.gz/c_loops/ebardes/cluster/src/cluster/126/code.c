for (i = 0; i < 2; i++)
{
  free(cdata[i]);
  free(cmask[i]);
}
