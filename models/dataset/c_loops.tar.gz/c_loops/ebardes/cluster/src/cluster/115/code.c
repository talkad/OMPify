for (i = 0; i < n2; i++)
{
  k = index2[i];
  for (j = 0; j < ncolumns; j++)
    if (mask[k][j] != 0)
  {
    cdata[1][j] = cdata[1][j] + data[k][j];
    count[1][j] = count[1][j] + 1;
  }


}
