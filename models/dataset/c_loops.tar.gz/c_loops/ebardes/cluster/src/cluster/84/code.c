for (i = 0; i < nnodes; i++)
{
  j = result[i].left;
  k = vector[j];
  result[i].left = index[j];
  result[i].right = index[k];
  index[k] = (-i) - 1;
}
