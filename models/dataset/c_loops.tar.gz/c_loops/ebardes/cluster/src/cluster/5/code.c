for (k = i; k <= hi; k++)
  xmin = min(xmin, x[k]);
