for (i = 0; i < nrows; i++)
{
  data[i] = malloc(ncols * (sizeof(double)));
  if (!data[i])
    break;

  mask[i] = malloc(ncols * (sizeof(int)));
  if (!mask[i])
  {
    free(data[i]);
    break;
  }

}
