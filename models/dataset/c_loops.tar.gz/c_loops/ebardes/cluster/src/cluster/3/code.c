for (i = 0; i < n; i++)
  result += x[i];
