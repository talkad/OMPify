for (i = 0; i < nxgrid; i++)
  free(celldata[i]);
