for (j = 0; j < nclusters; j++)
  errors[j] = DBL_MAX;
