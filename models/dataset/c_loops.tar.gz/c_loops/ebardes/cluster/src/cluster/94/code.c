for (i = 0; i < nelements; i++)
{
  int n = 0;
  for (j = 0; j < ndata; j++)
  {
    if (mask[j][i])
    {
      double term = data[j][i];
      term = term * term;
      stddata[i] += term;
      n++;
    }

  }

  if (stddata[i] > 0)
    stddata[i] = sqrt(stddata[i] / n);
  else
    stddata[i] = 1;

}
