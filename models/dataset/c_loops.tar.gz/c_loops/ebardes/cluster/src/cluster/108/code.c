for (i = 0; i < nxgrid; i++)
  for (j = 0; j < nygrid; j++)
  free(celldata[i][j]);

