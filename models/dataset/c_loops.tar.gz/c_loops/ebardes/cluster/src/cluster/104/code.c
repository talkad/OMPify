for (i = 0; i < nrows; i++)
{
  dummymask[i] = malloc(sizeof(int));
  dummymask[i][0] = 1;
}
