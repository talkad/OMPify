for (i = 1; i < n; i++)
{
  for (j = 0; j < i; j++)
  {
    temp = distmatrix[i][j];
    if (temp < distance)
    {
      distance = temp;
      *ip = i;
      *jp = j;
    }

  }

}
