for (j = 0; j < ncolumns; j++)
{
  int count = 0;
  for (k = 0; k < n1; k++)
  {
    i = index1[k];
    if (mask[i][j])
    {
      temp[count] = data[i][j];
      count++;
    }

  }

  if (count > 0)
  {
    cdata[0][j] = median(count, temp);
    cmask[0][j] = 1;
  }
  else
  {
    cdata[0][j] = 0.;
    cmask[0][j] = 0;
  }

}
