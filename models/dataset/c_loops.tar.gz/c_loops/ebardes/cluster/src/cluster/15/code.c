for (i = n - 1; i >= 0; i--)
{
  l = i + 1;
  g = w[i];
  if (i != (n - 1))
    for (j = l; j < n; j++)
    u[i][j] = 0.0;


  if (g != 0.0)
  {
    if (i != (n - 1))
    {
      for (j = l; j < n; j++)
      {
        s = 0.0;
        for (k = l; k < m; k++)
          s += u[k][i] * u[k][j];

        f = (s / u[i][i]) / g;
        for (k = i; k < m; k++)
          u[k][j] += f * u[k][i];

      }

    }

    for (j = i; j < m; j++)
      u[j][i] /= g;

  }
  else
    for (j = i; j < m; j++)
    u[j][i] = 0.0;


  u[i][i] += 1.0;
}
