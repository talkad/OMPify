for (; i >= 0; i--)
{
  i1 = tree[i].left;
  i2 = tree[i].right;
  counts1 = (i1 < 0) ? (nodecounts[(-i1) - 1]) : (1);
  index = nodecounts[i];
  if (i1 >= 0)
    indices[index] = i1;
  else
    nodecounts[(-i1) - 1] = index;

  index += counts1;
  if (i2 >= 0)
    indices[index] = i2;
  else
    nodecounts[(-i2) - 1] = index;

}
