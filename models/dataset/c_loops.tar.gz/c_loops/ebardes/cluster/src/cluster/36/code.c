for (i = 0; i < n; i++)
{
  if (mask1[i][index1] && mask2[i][index2])
  {
    double term = data1[i][index1] - data2[i][index2];
    result = result + (weight[i] * fabs(term));
    tweight += weight[i];
  }

}
