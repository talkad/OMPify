for (i = 0; i < nrows; i++)
  for (j = 0; j < 2; j++)
  if (count[i][j] > 0)
{
  cdata[i][j] = cdata[i][j] / count[i][j];
  cmask[i][j] = 1;
}
else
  cmask[i][j] = 0;


