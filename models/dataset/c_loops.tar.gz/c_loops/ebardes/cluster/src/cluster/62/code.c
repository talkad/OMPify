for (i = 0; i < nelements; i++)
  counts[tclusterid[i]]++;
