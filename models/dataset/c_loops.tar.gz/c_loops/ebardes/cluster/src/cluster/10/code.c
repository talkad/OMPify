for (i = 0; i < nrows; i++)
{
  free(data[i]);
  free(mask[i]);
}
