for (i = 0; i < nrows; i++)
{
  count[i] = calloc(2, sizeof(int));
  cdata[i] = calloc(2, sizeof(double));
  cmask[i] = malloc(2 * (sizeof(int)));
}
