for (; k < nelements; k++)
  clusterid[k] = i;
