for (j = 0; j < i; j++)
  temp[j] = metric(ndata, data, data, mask, mask, weight, i, j, transpose);
