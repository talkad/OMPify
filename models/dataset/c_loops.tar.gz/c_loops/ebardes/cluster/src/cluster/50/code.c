for (i = 0; i < nelements; i++)
{
  j = (int) (i + ((nelements - i) * uniform()));
  k = clusterid[j];
  clusterid[j] = clusterid[i];
  clusterid[i] = k;
}
