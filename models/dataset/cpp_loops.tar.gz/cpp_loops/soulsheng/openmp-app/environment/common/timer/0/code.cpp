for (int i = 0; i < dValidTimeVec.size(); i++)
{
  dAverageTime += dValidTimeVec[i];
}
