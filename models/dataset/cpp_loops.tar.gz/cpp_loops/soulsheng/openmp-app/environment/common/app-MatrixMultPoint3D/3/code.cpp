for (j = 0; j < m_nSizePoint; j++)
  m_pIndex[j] = j % m_nSizeMatrix;
