for (int i = 0; i < m_nSizePoint; i++)
{
  float *pInOne = m_pIn + (i * ELEMENT_COUNT_POINT);
  float *pOutOne = m_pOut + (i * ELEMENT_COUNT_POINT);
  float *pMatOne = m_pMat + (m_pIndex[i] * ELEMENT_COUNT_MATIRX);
  pOutOne[0] = (((pMatOne[(0 * 4) + 0] * pInOne[0]) + (pMatOne[(1 * 4) + 0] * pInOne[1])) + (pMatOne[(2 * 4) + 0] * pInOne[2])) + pMatOne[(3 * 4) + 0];
  pOutOne[1] = (((pMatOne[(0 * 4) + 1] * pInOne[0]) + (pMatOne[(1 * 4) + 1] * pInOne[1])) + (pMatOne[(2 * 4) + 1] * pInOne[2])) + pMatOne[(3 * 4) + 1];
  pOutOne[2] = (((pMatOne[(0 * 4) + 2] * pInOne[0]) + (pMatOne[(1 * 4) + 2] * pInOne[1])) + (pMatOne[(2 * 4) + 2] * pInOne[2])) + pMatOne[(3 * 4) + 2];
}
