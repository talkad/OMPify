for (int i = 0; i < m; i++)
{
  if (fabs(a[i] - aRef[i]) > 1.0e-3)
  {
    return false;
  }

}
