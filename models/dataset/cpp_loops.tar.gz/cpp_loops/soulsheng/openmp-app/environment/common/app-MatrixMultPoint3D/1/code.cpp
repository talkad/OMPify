for (j = 0; j < (m_nSizePoint * ELEMENT_COUNT_POINT); j++)
  m_pIn[j] = 2.0;
