for (i = 0; i < m_nSizeMatrix; i++)
  for (j = 0; j < ELEMENT_COUNT_MATIRX; j++)
  m_pMat[(i * ELEMENT_COUNT_MATIRX) + j] = j / ((float) ELEMENT_COUNT_MATIRX);

