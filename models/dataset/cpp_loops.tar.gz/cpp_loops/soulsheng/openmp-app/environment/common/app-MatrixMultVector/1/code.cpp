for (i = 0; i < m; i++)
{
  aRef[i] = 0.0;
  for (j = 0; j < n; j++)
    aRef[i] += b[(i * n) + j] * c[j];

}
