for (int i = 0; i < (m_nSizePoint * ELEMENT_COUNT_POINT); i++)
{
  if (fabs(m_pOut[i] - m_pOutRef[i]) > 1.0e-3)
  {
    return false;
  }

}
