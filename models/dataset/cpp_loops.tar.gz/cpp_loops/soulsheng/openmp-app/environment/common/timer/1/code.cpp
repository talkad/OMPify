for (int i = 0; i < dValidTimeVec.size(); i++)
{
  dMeanSquareError += (dValidTimeVec[i] - dAverageTime) * (dValidTimeVec[i] - dAverageTime);
}
