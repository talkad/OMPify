for (int i = start; i <= end; ++i)
{
  for (int j = i + 1; j <= end; ++j)
  {
    if (objs[i].Distance(objs[j]) <= eps)
    {
      ++resultCount;
    }

  }

}
