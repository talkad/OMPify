for (int i = 0; i < tsize; i++)
{
  char *tptr;
  char *pptr;
  if (text[i] == (*pattern))
  {
    tptr = &text[i + 1];
    pptr = pattern + 1;
    while (true)
    {
      if ((*pptr) == NULL)
      {
        ++n;
        break;
      }

      if ((*tptr) != (*pptr))
      {
        break;
      }

      tptr++;
      pptr++;
    }

  }

}
