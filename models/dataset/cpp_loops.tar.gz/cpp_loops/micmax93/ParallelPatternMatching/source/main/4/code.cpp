for (int i = 0; i < 1; ++i)
{
  rep = algoParaAll(text, pattern, tsize);
  rep = algoParaFastAll(text, pattern, tsize);
  rep = algoParaTab(text, pattern, tsize);
  rep = algoSeq2(text, pattern);
  rep = algoParaThreadDiv(threadDiv, pattern);
  rep = algoParaCacheDiv(cacheDiv, pattern, s);
}
