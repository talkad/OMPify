for (int i = 0; i < s; i++)
{
  int subsum = 0;
  char *tptr;
  char *pptr;
  char *text = ttab[i];
  while ((*text) != NULL)
  {
    if ((*text) == (*pattern))
    {
      tptr = text + 1;
      pptr = pattern + 1;
      while (true)
      {
        if ((*pptr) == NULL)
        {
          subsum++;
          break;
        }

        if ((*tptr) != (*pptr))
        {
          break;
        }

        tptr++;
        pptr++;
      }

    }

    text++;
  }

  n += subsum;
}
