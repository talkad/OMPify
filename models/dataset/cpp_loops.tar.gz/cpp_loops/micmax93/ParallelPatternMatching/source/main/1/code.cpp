for (int i = 0; i < 4; i++)
{
  char *tptr;
  char *pptr;
  int m = (i * tsize) / 4;
  for (int j = 0; j < (tsize / 4); j++)
  {
    if (text[m + j] == (*pattern))
    {
      tptr = &text[(m + j) + 1];
      pptr = pattern + 1;
      while (true)
      {
        if ((*pptr) == NULL)
        {
          ++n;
          break;
        }

        if ((*tptr) != (*pptr))
        {
          break;
        }

        tptr++;
        pptr++;
      }

    }

  }

}
