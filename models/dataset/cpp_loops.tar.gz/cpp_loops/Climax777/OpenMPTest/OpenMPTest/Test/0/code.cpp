for (int i = 0; i < iters; i++)
{
  double appel = sqrt(5664.95599);
  double frik = sqrt(554454.997679);
  double piesang = sqrt(5545554.994549);
  double appel4 = sqrt(5556554.96899);
  double frik3 = sqrt(544554.96699);
  double piesang2 = sqrt(555498.9099);
  double appel5 = sqrt(555478.999);
  double frik78 = sqrt(5554557.999);
  double piesang8787 = sqrt(555334.999);
  double appel44 = sqrt(556554.999);
  double frik2312 = sqrt(5552434.999);
  double piesang45 = sqrt(551154.999);
  double appel656 = sqrt(553354.999);
  double frik76 = sqrt(5523454.999);
  double piesang222 = sqrt(55354.999);
}
