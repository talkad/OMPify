for (int i = 0; i < tasks.size(); i++)
  tasks[i]->update();
