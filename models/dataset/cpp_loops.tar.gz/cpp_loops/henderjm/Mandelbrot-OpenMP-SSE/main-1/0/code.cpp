for (hy = 0; hy < HYRES; hy++)
{
  float cy = (((((float) hy) / ((float) HYRES)) - 0.5) + (PY / (4.0 / m))) * (4.0f / m);
  cy4 = _mm_set1_ps(cy);
  for (hx = 0; hx < (HXRES - (HXRES & 0x3)); hx += 4)
  {
    cx4 = _mm_setr_ps((float) hx, ((float) hx) + 1, ((float) hx) + 2, ((float) hx) + 3);
    cx4 = _mm_mul_ps(cx4, HXRES4);
    cx4 = _mm_add_ps(cx4, vectorpoint5);
    cx4 = _mm_mul_ps(_mm_add_ps(cx4, temp2), vector4divM);
    _mm_store_ps(arr, sse_member(cx4, cy4));
    for (j = 0; j < 4; j++)
    {
      if (arr[j] != MAX_ITS)
      {
        i = (((int) arr[j]) % 40) - 1;
        b = i * 3;
        screen->putpixel(hx + j, hy, pal[b], pal[b + 1], pal[b + 2]);
      }
      else
      {
        screen->putpixel(hx + j, hy, 0, 0, 0);
      }

    }

  }

}
