for (int i = 0; i < 4; i++)
{
  sum += i;
  printf("i=%d, TID=%d\n", i, omp_get_thread_num());
}
