for (iterator I = DGR.begin(), E = DGR.end(); I != E; ++I)
{
  if (*I)
    DSAStack->addDeclareTargetDecl(*I);

}
