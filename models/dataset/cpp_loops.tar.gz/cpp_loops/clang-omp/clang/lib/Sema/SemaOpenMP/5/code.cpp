for (int I = LoopIdBegin + LoopIdStep; I != LoopIdEnd; I += LoopIdStep)
{
  NewIncr = BuildBinOp(DSAStack->getCurScope(), StartLoc, BO_Div, IdxRVal, NewDiv).get();
  if (!NewIncr)
    return false;

  if ((I + LoopIdStep) != LoopIdEnd)
  {
    NewIncr = BuildBinOp(DSAStack->getCurScope(), StartLoc, BO_Rem, NewIncr, Ends[I]).get();
    if (!NewIncr)
      return false;

  }

  NewIncr = BuildBinOp(DSAStack->getCurScope(), StartLoc, BO_Mul, NewIncr, Incrs[I]).get();
  if (!NewIncr)
    return false;

  NewFinal1 = BuildBinOp(DSAStack->getCurScope(), StartLoc, BO_Assign, VarCnts[I], Inits[I]).get();
  if (!NewFinal1)
    return false;

  NewFinal = CreateBuiltinBinOp(StartLoc, BO_Comma, NewFinal, NewFinal1).get();
  if (!NewFinal)
    return false;

  NewFinal1 = IgnoredValueConversions(NewFinal1).get();
  if (!NewFinal1)
    return false;

  NewFinal1 = BuildBinOp(DSAStack->getCurScope(), StartLoc, BO_Mul, Ends[I], Incrs[I]).get();
  if (!NewFinal1)
    return false;

  NewFinal1 = BuildBinOp(DSAStack->getCurScope(), StartLoc, (OpKinds[I] == BO_Add) ? (BO_AddAssign) : (BO_SubAssign), VarCnts[I], NewFinal1).get();
  if (!NewFinal1)
    return false;

  NewFinal1 = IgnoredValueConversions(NewFinal1).get();
  if (!NewFinal1)
    return false;

  NewFinal = CreateBuiltinBinOp(StartLoc, BO_Comma, NewFinal, NewFinal1).get();
  if (!NewFinal)
    return false;

  NewVarCntExpr1 = BuildBinOp(DSAStack->getCurScope(), StartLoc, BO_Assign, VarCnts[I], Inits[I]).get();
  if (!NewVarCntExpr1)
    return false;

  NewVarCntExpr1 = IgnoredValueConversions(NewVarCntExpr1).get();
  if (!NewVarCntExpr1)
    return false;

  NewVarCntExpr = CreateBuiltinBinOp(StartLoc, BO_Comma, NewVarCntExpr, NewVarCntExpr1).get();
  if (!NewVarCntExpr)
    return false;

  NewVarCntExpr1 = BuildBinOp(DSAStack->getCurScope(), StartLoc, (OpKinds[I] == BO_Add) ? (BO_AddAssign) : (BO_SubAssign), VarCnts[I], NewIncr).get();
  if (!NewVarCntExpr1)
    return false;

  NewVarCntExpr1 = IgnoredValueConversions(NewVarCntExpr1).get();
  if (!NewVarCntExpr1)
    return false;

  NewVarCntExpr = CreateBuiltinBinOp(StartLoc, BO_Comma, NewVarCntExpr, NewVarCntExpr1).get();
  if (!NewVarCntExpr)
    return false;

  NewDiv = BuildBinOp(DSAStack->getCurScope(), StartLoc, BO_Mul, NewDiv, Ends[I]).get();
  if (!NewDiv)
    return false;

}
