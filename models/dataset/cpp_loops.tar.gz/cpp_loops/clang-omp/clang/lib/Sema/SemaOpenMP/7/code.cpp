for (unsigned i = OMPC_DEFAULT_unknown + 1; i < NUM_OPENMP_DEFAULT_KINDS; ++i)
{
  Values += "'";
  Values += getOpenMPSimpleClauseTypeName(OMPC_default, i);
  Values += "'";
  switch (i)
  {
    case NUM_OPENMP_DEFAULT_KINDS - 2:
      Values += " or ";
      break;

    case NUM_OPENMP_DEFAULT_KINDS - 1:
      break;

    default:
      Values += Sep;
      break;

  }

}
