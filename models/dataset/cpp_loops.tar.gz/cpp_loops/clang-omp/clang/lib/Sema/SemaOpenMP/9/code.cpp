for (int i = OMPC_SCHEDULE_unknown + 1; i < NUM_OPENMP_SCHEDULE_KINDS; ++i)
{
  Values += "'";
  Values += getOpenMPSimpleClauseTypeName(OMPC_schedule, i);
  Values += "'";
  switch (i)
  {
    case NUM_OPENMP_SCHEDULE_KINDS - 2:
      Values += " or ";
      break;

    case NUM_OPENMP_SCHEDULE_KINDS - 1:
      break;

    default:
      Values += Sep;
      break;

  }

}
