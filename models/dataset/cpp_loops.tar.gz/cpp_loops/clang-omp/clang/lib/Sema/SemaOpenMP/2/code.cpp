for (iterator I = Types.begin(), E = Types.end(); I != E; ++I, ++IR)
{
  if (Context.hasSameType(QTy, *I))
  {
    (Diag(Range.getBegin(), err_omp_reduction_redeclared) << (*I)) << Range;
    Diag(IR->getBegin(), note_previous_declaration) << (*IR);
    IsValid = false;
  }

}
