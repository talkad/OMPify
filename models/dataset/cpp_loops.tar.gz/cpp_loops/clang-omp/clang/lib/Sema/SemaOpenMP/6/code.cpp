for (I = Cap->capture_begin(), J = Cap->capture_init_begin(); (I != Cap->capture_end()) && (J != Cap->capture_init_end()); ++I, ++J)
{
  Captures.push_back(*I);
  CaptureInits.push_back(*J);
}
