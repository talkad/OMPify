for (unsigned Cnt = Stack.size() - 1; Cnt > 0; --Cnt)
{
  if (Stack[Cnt].MappedDecls.count(VD))
  {
    Tmp = Stack[Cnt].MappedDecls[VD];
    break;
  }

}
