for (iterator IT = Types.begin(), ET = Types.end(); IT != ET; ++IT, ++IC, ++II, ++IR)
{
  Data.push_back(ReductionData(*IT, *IR, *IC, *II));
}
