for (unsigned i = OMPC_PROC_BIND_unknown + 1; i < NUM_OPENMP_PROC_BIND_KINDS; ++i)
{
  Values += "'";
  Values += getOpenMPSimpleClauseTypeName(OMPC_proc_bind, i);
  Values += "'";
  switch (i)
  {
    case NUM_OPENMP_PROC_BIND_KINDS - 2:
      Values += " or ";
      break;

    case NUM_OPENMP_PROC_BIND_KINDS - 1:
      break;

    default:
      Values += Sep;
      break;

  }

}
