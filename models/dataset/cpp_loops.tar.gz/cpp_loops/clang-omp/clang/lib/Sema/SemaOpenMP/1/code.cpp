for (iterator ES = SrcRanges.end(); IS != ES; ++IS, ++IB, ++IE)
{
  Data.push_back(SimdVariant(*IS, *IB, *IE));
}
