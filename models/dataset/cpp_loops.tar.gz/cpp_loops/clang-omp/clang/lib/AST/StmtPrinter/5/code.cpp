for (unsigned i = 0, e = Call->getNumArgs(); i != e; ++i)
{
  if ((isa < CXXDefaultArgExpr) > Call->getArg(i))
  {
    break;
  }

  if (i)
    OS << ", ";

  PrintExpr(Call->getArg(i));
}
