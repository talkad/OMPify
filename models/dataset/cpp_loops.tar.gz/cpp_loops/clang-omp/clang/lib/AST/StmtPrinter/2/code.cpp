for (unsigned i = 0, e = Node->getNumInputs(); i != e; ++i)
{
  if (i != 0)
    OS << ", ";

  if (!Node->getInputName(i).empty())
  {
    OS << '[';
    OS << Node->getInputName(i);
    OS << "] ";
  }

  VisitStringLiteral(Node->getInputConstraintLiteral(i));
  OS << " ";
  Visit(Node->getInputExpr(i));
}
