for (unsigned i = 1; i < NumPlace; ++i)
{
  if ((isa < CXXDefaultArgExpr) > E->getPlacementArg(i))
    break;

  OS << ", ";
  PrintExpr(E->getPlacementArg(i));
}
