for (unsigned i = 0, e = E->getNumArgs(); i != e; ++i)
{
  if ((isa < CXXDefaultArgExpr) > E->getArg(i))
  {
    break;
  }

  if (i)
    OS << ", ";

  PrintExpr(E->getArg(i));
}
