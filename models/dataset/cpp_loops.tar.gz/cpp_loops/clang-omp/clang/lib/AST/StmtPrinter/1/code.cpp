for (unsigned i = 0, e = Node->getNumOutputs(); i != e; ++i)
{
  if (i != 0)
    OS << ", ";

  if (!Node->getOutputName(i).empty())
  {
    OS << '[';
    OS << Node->getOutputName(i);
    OS << "] ";
  }

  VisitStringLiteral(Node->getOutputConstraintLiteral(i));
  OS << " ";
  Visit(Node->getOutputExpr(i));
}
