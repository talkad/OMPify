for (unsigned i = 0, e = Node->getNumInits(); i != e; ++i)
{
  if (i)
    OS << ", ";

  if (Node->getInit(i))
    PrintExpr(Node->getInit(i));
  else
    OS << "0";

}
