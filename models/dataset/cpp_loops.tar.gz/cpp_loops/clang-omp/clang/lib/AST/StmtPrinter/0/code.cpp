for (int i = 0, e = IndentLevel + Delta; i < e; ++i)
  OS << "  ";
