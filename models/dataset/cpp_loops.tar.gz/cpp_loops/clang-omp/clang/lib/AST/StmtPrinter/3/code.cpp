for (unsigned i = 0, e = Node->getNumClobbers(); i != e; ++i)
{
  if (i != 0)
    OS << ", ";

  VisitStringLiteral(Node->getClobberStringLiteral(i));
}
