for (unsigned I = 0, N = E->getNumArgs(); I != N; ++I)
{
  if (I > 0)
    OS << ", ";

  E->getArg(I)->getType().print(OS, Policy);
}
