for (unsigned i = 0, e = Node->getNumHandlers(); i < e; ++i)
{
  OS << " ";
  PrintRawCXXCatchStmt(Node->getHandler(i));
}
