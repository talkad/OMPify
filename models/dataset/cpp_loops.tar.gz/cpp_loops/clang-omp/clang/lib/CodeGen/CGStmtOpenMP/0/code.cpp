for (const_iterator I = DKinds.begin(), E = DKinds.end(); I != E; ++I)
{
  if (isAllowedClauseForDirective(*I, CKind))
    return true;

}
