for (unsigned i = 0; i < MappingDecls.size(); ++i)
  CGF.CapturedStmtInfo->addCachedVar(MappingDecls[i], MappingVals[i]);
