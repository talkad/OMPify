for (unsigned i = 0; i < Set.getNumSlots(); ++i)
{
  if (Set.getSlotIndex(i) == FunctionIndex)
  {
    for (iterator I = Set.begin(i), E = Set.end(i); I != E; ++I)
    {
      if (I->isStringAttribute() && I->getKindAsString().startswith("INTEL:"))
        Fn->addFnAttr(I->getKindAsString());

    }

  }

}
