for (unsigned I = 0; I < TI.size(); ++I)
{
  assert(CL[TI[I].Idx] == 0);
  CL[TI[I].Idx] = Actions.ActOnOpenMPDeclarativeVarListClause(TI[I].CKind, TI[I].NameInfos, TI[I].StartLoc, TI[I].EndLoc, TI[I].TailExpr, TI[I].TailLoc, FuncDecl);
}
