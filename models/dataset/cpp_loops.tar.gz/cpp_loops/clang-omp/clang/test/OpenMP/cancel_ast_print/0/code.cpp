for (int i = 0; i < argc; ++i)
{
  #pragma omp cancel for
}
