for (;;)
{
  #pragma omp cancel taskgroup
}
