for (;;)
{
  #pragma omp cancel for
  for (;;)
  {
    #pragma omp cancel taskgroup
  }

}
