for (int i = 0; i < argc; ++i)
{
  #pragma omp cancellation point for
}
