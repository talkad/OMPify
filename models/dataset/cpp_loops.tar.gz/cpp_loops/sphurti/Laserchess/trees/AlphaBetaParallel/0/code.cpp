for (; it != moves_list.end(); ++it)
  mvec.push_back(*it);
