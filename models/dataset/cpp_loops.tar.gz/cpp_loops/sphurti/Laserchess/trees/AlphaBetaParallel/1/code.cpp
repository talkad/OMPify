for (; it != moves_list.end(); ++it)
  if ((*it) != chosen_move)
  delete * it;

