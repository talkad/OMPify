for (int i = 0; i < n; ++i)
{
  c[i] = sqrt((a[i] * a[i]) + (b[i] * b[i]));
}
