for (int ii = 0; ii < N; ii++)
  for (int jj = 0; jj < N; jj++)
  A[(ii * N) + jj] = 0.0;

