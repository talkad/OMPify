for (int ii = 0; ii < N; ++ii)
{
  for (int kk = 0; kk < N; ++kk)
  {
    float r = A[(ii * N) + kk];
    for (int jj = 0; jj < N; ++jj)
    {
      C[(ii * N) + jj] += r * B[(kk * N) + jj];
    }

  }

}
