for (int ii = 0; ii < N; ii++)
  for (int jj = 0; jj < N; jj++)
{
  if (ii == jj)
    printf("!!!%f vs %f \n", A[(ii * N) + jj], B[(ii * N) + jj]);

}

