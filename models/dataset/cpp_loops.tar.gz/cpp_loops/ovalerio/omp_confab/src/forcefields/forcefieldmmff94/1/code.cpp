for (int i = 0; i < _anglecalculations.size(); ++i)
{
  if (gradients)
  {
    AddGradient(_anglecalculations[i].force_a, _anglecalculations[i].idx_a);
    AddGradient(_anglecalculations[i].force_b, _anglecalculations[i].idx_b);
    AddGradient(_anglecalculations[i].force_c, _anglecalculations[i].idx_c);
  }

}
