for (unsigned int idx = 0; idx < parameter.size(); idx++)
  if (((a == parameter[idx].a) && (b == parameter[idx].b)) || ((a == parameter[idx].b) && (b == parameter[idx].a)))
{
  par = &parameter[idx];
  return par;
}

