for (int i = 0; i < _vdwcalculations.size(); ++i)
{
  if (_cutoff)
    if (!_vdwpairs.BitIsSet(i))
    continue;


  if (gradients)
  {
    AddGradient(_vdwcalculations[i].force_a, _vdwcalculations[i].idx_a);
    AddGradient(_vdwcalculations[i].force_b, _vdwcalculations[i].idx_b);
  }

}
