for (unsigned int i = 0; i < _strbndcalculations.size(); ++i)
  _strbndcalculations[i].SetupPointers();
