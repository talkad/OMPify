for (unsigned int i = 0; i < _interGroup.size(); ++i)
{
  if (_interGroup[i].BitIsOn(a->GetIdx()) && _interGroup[i].BitIsOn(b->GetIdx()))
    validEle = true;

}
