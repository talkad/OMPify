for (unsigned int i = 0; i < betaAtoms.size(); i++)
{
  if (betaAtoms[i]->IsSulfur() || betaAtoms[i]->IsOxygen())
  {
    if (atom->IsCarbon())
    {
      return 64;
    }
    else
      if (atom->IsNitrogen())
    {
      return 66;
    }


  }

}
