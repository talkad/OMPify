for (unsigned int i = 0; i < _torsioncalculations.size(); ++i)
  _torsioncalculations[i].SetupPointers();
