for (ri = vr.begin(); ri != vr.end(); ri++)
{
  n_count = 0;
  if (((*ri)->IsAromatic() && (*ri)->IsMember(&(*atom))) && ((*ri)->Size() == 5))
  {
    for (rj = (*ri)->_path.begin(); rj != (*ri)->_path.end(); rj++)
      if (_mol.GetAtom(*rj)->IsNitrogen())
      n_count++;


    if (n_count > 1)
      atom->SetPartialCharge((-1.0) / n_count);

  }

}
