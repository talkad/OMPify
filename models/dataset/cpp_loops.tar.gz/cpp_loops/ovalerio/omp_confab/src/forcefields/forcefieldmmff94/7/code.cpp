for (unsigned int i = 0; i < alphaAtoms.size(); i++)
{
  for (unsigned int j = 0; j < betaAtoms.size(); j++)
  {
    if (!IsInSameRing(alphaAtoms[i], betaAtoms[j]))
    {
      if (atom->IsCarbon())
      {
        return 78;
      }
      else
        if (atom->IsNitrogen())
      {
        return 79;
      }


    }

  }

}
