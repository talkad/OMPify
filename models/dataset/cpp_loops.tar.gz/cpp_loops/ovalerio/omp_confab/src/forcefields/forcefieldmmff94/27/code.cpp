for (ri = vr.begin(); ri != vr.end(); ++ri)
{
  if ((*ri)->IsAromatic())
    continue;

  if ((*ri)->Size() != 5)
    continue;

  if ((((!(*ri)->IsMember(a)) || (!(*ri)->IsMember(b))) || (!(*ri)->IsMember(c))) || (!(*ri)->IsMember(d)))
    continue;

  return 5;
}
