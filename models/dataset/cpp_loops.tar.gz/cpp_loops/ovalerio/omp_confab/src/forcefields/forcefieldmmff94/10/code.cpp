for (unsigned int i = 0; i < _intraGroup.size(); ++i)
{
  if (_intraGroup[i].BitIsOn(a->GetIdx()) && _intraGroup[i].BitIsOn(b->GetIdx()))
    validBond = true;

}
