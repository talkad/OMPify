for (int i = 0; i < _torsioncalculations.size(); ++i)
{
  if (gradients)
  {
    AddGradient(_torsioncalculations[i].force_a, _torsioncalculations[i].idx_a);
    AddGradient(_torsioncalculations[i].force_b, _torsioncalculations[i].idx_b);
    AddGradient(_torsioncalculations[i].force_c, _torsioncalculations[i].idx_c);
    AddGradient(_torsioncalculations[i].force_d, _torsioncalculations[i].idx_d);
  }

}
