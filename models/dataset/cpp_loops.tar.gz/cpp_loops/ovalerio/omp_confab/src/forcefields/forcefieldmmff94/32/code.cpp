for (unsigned int idx = 0; idx < parameter.size(); idx++)
  if (a == parameter[idx].a)
{
  par = &parameter[idx];
  return par;
}

