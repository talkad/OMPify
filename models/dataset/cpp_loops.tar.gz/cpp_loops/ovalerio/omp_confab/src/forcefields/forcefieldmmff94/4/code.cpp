for (int i = 0; i < _oopcalculations.size(); ++i)
{
  if (gradients)
  {
    AddGradient(_oopcalculations[i].force_a, _oopcalculations[i].idx_a);
    AddGradient(_oopcalculations[i].force_b, _oopcalculations[i].idx_b);
    AddGradient(_oopcalculations[i].force_c, _oopcalculations[i].idx_c);
    AddGradient(_oopcalculations[i].force_d, _oopcalculations[i].idx_d);
  }

}
