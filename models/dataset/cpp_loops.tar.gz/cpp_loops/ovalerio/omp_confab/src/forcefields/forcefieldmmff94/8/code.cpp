for (unsigned int i = 0; i < alphaAtoms.size(); i++)
{
  if (alphaAtoms[i]->IsSulfur() || alphaAtoms[i]->IsOxygen())
  {
    if (atom->IsCarbon())
    {
      return 63;
    }
    else
      if (atom->IsNitrogen())
    {
      return 65;
    }


  }

}
