for (unsigned int i = 0; i < _oopcalculations.size(); ++i)
  _oopcalculations[i].SetupPointers();
