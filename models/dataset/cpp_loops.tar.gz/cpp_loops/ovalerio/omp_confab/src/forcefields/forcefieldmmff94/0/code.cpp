for (int i = 0; i < _bondcalculations.size(); ++i)
{
  if (gradients)
  {
    AddGradient(_bondcalculations[i].force_a, _bondcalculations[i].idx_a);
    AddGradient(_bondcalculations[i].force_b, _bondcalculations[i].idx_b);
  }

}
