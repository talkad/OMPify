for (unsigned int i = 0; i < _vdwcalculations.size(); ++i)
  _vdwcalculations[i].SetupPointers();
