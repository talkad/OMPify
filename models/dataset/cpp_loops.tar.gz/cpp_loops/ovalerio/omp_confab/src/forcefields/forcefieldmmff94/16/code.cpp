for (unsigned int i = 0; i < _interGroups.size(); ++i)
{
  if (_interGroups[i].first.BitIsOn(a->GetIdx()) && _interGroups[i].second.BitIsOn(b->GetIdx()))
    validEle = true;

  if (_interGroups[i].first.BitIsOn(b->GetIdx()) && _interGroups[i].second.BitIsOn(a->GetIdx()))
    validEle = true;

}
