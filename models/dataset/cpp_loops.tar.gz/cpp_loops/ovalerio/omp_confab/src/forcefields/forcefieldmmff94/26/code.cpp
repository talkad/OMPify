for (unsigned int idx = 0; idx < _ffpbciparams.size(); idx++)
{
  if (type == _ffpbciparams[idx].a)
    Pa = _ffpbciparams[idx]._dpar[0];

  if (nbr_type == _ffpbciparams[idx].a)
    Pb = _ffpbciparams[idx]._dpar[0];

}
