for (unsigned int idx = 0; idx < _ffdefparams.size(); idx++)
  if (_ffdefparams[idx]._ipar[0] == type)
  return _ffdefparams[idx]._ipar[4];

