for (int i = 0; i < _strbndcalculations.size(); ++i)
{
  if (gradients)
  {
    AddGradient(_strbndcalculations[i].force_a, _strbndcalculations[i].idx_a);
    AddGradient(_strbndcalculations[i].force_b, _strbndcalculations[i].idx_b);
    AddGradient(_strbndcalculations[i].force_c, _strbndcalculations[i].idx_c);
  }

}
