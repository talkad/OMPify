for (unsigned int i = 0; i < _electrostaticcalculations.size(); ++i)
  _electrostaticcalculations[i].SetupPointers();
