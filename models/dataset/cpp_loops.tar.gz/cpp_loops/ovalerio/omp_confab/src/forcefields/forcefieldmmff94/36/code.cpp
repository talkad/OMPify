for (unsigned int idx = 0; idx < parameter.size(); idx++)
  if (((((a == parameter[idx].a) && (b == parameter[idx].b)) && (c == parameter[idx].c)) && (ffclass == parameter[idx]._ipar[0])) || ((((a == parameter[idx].c) && (b == parameter[idx].b)) && (c == parameter[idx].a)) && (ffclass == parameter[idx]._ipar[0])))
{
  par = &parameter[idx];
  return par;
}

