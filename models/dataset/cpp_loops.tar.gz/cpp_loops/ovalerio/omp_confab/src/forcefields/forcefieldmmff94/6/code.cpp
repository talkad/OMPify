for (int i = 0; i < _electrostaticcalculations.size(); ++i)
{
  if (_cutoff)
    if (!_elepairs.BitIsSet(i))
    continue;


  if (gradients)
  {
    AddGradient(_electrostaticcalculations[i].force_a, _electrostaticcalculations[i].idx_a);
    AddGradient(_electrostaticcalculations[i].force_b, _electrostaticcalculations[i].idx_b);
  }

}
