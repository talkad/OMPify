for (unsigned int i = 0; i < _bondcalculations.size(); ++i)
  _bondcalculations[i].SetupPointers();
