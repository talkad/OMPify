for (unsigned int i = 0; i < _anglecalculations.size(); ++i)
  _anglecalculations[i].SetupPointers();
