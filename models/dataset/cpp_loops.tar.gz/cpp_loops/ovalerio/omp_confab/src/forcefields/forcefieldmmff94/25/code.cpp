for (unsigned int idx = 0; idx < _ffchgparams.size(); idx++)
  if (GetBondType(&(*atom), &(*nbr)) == _ffchgparams[idx]._ipar[0])
{
  if ((type == _ffchgparams[idx].a) && (nbr_type == _ffchgparams[idx].b))
  {
    Wab += -_ffchgparams[idx]._dpar[0];
    bci_found = true;
  }
  else
    if ((type == _ffchgparams[idx].b) && (nbr_type == _ffchgparams[idx].a))
  {
    Wab += _ffchgparams[idx]._dpar[0];
    bci_found = true;
  }


}

