for (unsigned int i = 0; i < _intraGroup.size(); ++i)
{
  if (((_intraGroup[i].BitIsOn(a->GetIdx()) && _intraGroup[i].BitIsOn(b->GetIdx())) && _intraGroup[i].BitIsOn(c->GetIdx())) && _intraGroup[i].BitIsOn(d->GetIdx()))
    validTorsion = true;

}
