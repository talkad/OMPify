for (int i = 1; i < arr->size(); i++)
{
  T val = (*arr)[i];
  int j = i;
  while ((j >= 1) && ((*arr)[j - 1] > val))
  {
    (*arr)[j] = (*arr)[j - 1];
    j--;
  }

  (*arr)[j] = val;
}
