for (int i = 0; i < (arr->size() / 2); i++)
{
  T temp = (*arr)[i];
  (*arr)[i] = (*arr)[(arr->size() - 1) - i];
  (*arr)[(arr->size() - 1) - i] = temp;
}
