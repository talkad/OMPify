for (int i = 1; i < ((arr->size() / 2) + 1); i++)
{
  if (((*arr)[i] < (*arr)[i - 1]) || ((*arr)[arr->size() - i] < (*arr)[(arr->size() - i) - 1]))
    return false;

}
