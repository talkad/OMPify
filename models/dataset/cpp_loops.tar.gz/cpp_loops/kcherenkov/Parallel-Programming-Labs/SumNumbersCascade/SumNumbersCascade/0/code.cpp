for (int i = 1; i < numprocs; i *= 2)
{
  if ((myid % (i * 2)) != 0)
  {
    MPI_Send(&total, 1, MPI_INT, myid - i, 0, MPI_COMM_WORLD);
    break;
  }
  else
    if ((myid + i) < numprocs)
  {
    MPI_Recv(&temp, 1, MPI_INT, myid + i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
    total += temp;
  }


}
