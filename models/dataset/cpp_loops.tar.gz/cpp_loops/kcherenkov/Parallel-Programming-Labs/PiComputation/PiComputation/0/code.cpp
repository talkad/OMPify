for (i = rank + 1; i <= n; i += size)
{
  double x = h * (((double) i) - 0.5);
  sum += 4.0 / (1.0 + (x * x));
}
