for (int i = 0; i < myRowsSize; ++i)
{
  resultPart[i] = 0;
  for (int j = 0; j < N; ++j)
  {
    resultPart[i] += matrixPart[(i * N) + j] * vector[j];
  }

}
