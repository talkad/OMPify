for (int i = 0; i < N; ++i)
{
  vector[i] = rand() & 100;
  (cout << vector[i]) << ' ';
}
