for (int i = 0; i < M; ++i)
  (cout << result[i]) << ' ';
