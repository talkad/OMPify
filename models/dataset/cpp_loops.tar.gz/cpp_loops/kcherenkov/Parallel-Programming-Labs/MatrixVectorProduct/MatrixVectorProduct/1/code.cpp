for (int i = 0; i < numprocs; ++i)
{
  recvcounts[i] = (i < remainder) ? (count + 1) : (count);
  sendcounts[i] = recvcounts[i] * N;
  recvdispls[i] = prefixSum;
  senddispls[i] = prefixSum * N;
  prefixSum += recvcounts[i];
}
