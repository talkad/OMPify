for (int i = 0; i < numprocs; ++i)
{
  sendcounts[i] = (i < remainder) ? (count + 1) : (count);
  displs[i] = prefixSum;
  prefixSum += sendcounts[i];
}
