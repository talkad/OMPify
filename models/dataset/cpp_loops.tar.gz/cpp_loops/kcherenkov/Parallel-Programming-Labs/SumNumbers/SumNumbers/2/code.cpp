for (int i = 0; i < myBlockSize; ++i)
  total += res[i];
