for (int i = 0; i < n; ++i)
{
  data[i] = rand() % 100;
  (cout << data[i]) << ' ';
  sum += data[i];
}
