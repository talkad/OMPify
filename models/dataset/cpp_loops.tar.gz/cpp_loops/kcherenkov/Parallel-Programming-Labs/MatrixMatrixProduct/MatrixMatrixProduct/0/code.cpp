for (int i = 0; i < M1; ++i)
{
  for (int j = 0; j < N1; ++j)
  {
    matrix1[(N1 * i) + j] = rand() % 100;
    (cout << matrix1[(N1 * i) + j]) << '\t';
  }

  cout << endl;
}
