for (int i = 0; i < numprocs; ++i)
{
  int t1 = (i < remainder) ? (count + 1) : (count);
  recvcounts[i] = t1 * N2;
  sendcounts[i] = t1 * N1;
  int t2 = prefixSum;
  recvdispls[i] = t2 * N2;
  senddispls[i] = t2 * N1;
  prefixSum += t1;
}
