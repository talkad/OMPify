for (int i = 0; i < M2; ++i)
{
  for (int j = 0; j < N2; ++j)
  {
    matrix2[(N2 * i) + j] = rand() % 100;
    (cout << matrix2[(N2 * i) + j]) << '\t';
  }

  cout << endl;
}
