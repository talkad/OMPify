for (int i = 0; i < myRowsSize; ++i)
{
  for (int j = 0; j < N2; ++j)
  {
    resultPart[(i * N2) + j] = 0;
    for (int k = 0; k < N1; ++k)
    {
      resultPart[(i * N2) + j] += matrixPart[(i * N1) + k] * matrix2[(k * N2) + j];
    }

  }

}
