for (int i = 0; i < M1; ++i)
{
  for (int j = 0; j < N2; ++j)
    (cout << result[(i * N2) + j]) << '\t';

  cout << endl;
}
