for (k = 0; k < (n - 1); k++)
{
  if (fabs(a[k][k]) >= 1.e-6)
  {
    #pragma omp parallel for private(j)
    for (i = k + 1; i < n; i++)
    {
      x = a[i][k] / a[k][k];
      for (j = k + 1; j < n; j++)
        a[i][j] = a[i][j] - (a[k][j] * x);

      b[i] = b[i] - (b[k] * x);
    }

  }
  else
  {
    cout << "zero pivot element found.\n";
    exit(1);
  }

}
