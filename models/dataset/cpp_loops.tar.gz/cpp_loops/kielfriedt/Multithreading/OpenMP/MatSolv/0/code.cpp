for (j = 0; j < n; j++)
{
  b[j] = B[j];
  for (k = 0; k < n; k++)
    a[j][k] = A[(j + k) + counter];

  counter += n - 1;
}
