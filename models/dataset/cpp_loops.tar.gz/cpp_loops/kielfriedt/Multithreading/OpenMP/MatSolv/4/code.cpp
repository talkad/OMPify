for (int i = 0; i < 200; i++)
{
  gettimeofday(&start, NULL);
  s = MatSolve(a, b, NumElements);
  gettimeofday(&end, NULL);
  double finishingtime = (((end.tv_sec - start.tv_sec) * 1000) + ((end.tv_usec - start.tv_usec) / 1000.0)) + 0.5;
  ((cout << "Time: ") << (finishingtime / 1000)) << "\n";
  cout << "S: \n";
  for (int x = 0; x < NumElements; x++)
    (cout << s[x]) << "\n";

}
