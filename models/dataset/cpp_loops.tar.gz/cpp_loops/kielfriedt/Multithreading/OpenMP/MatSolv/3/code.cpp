for (i = n - 2; i >= 0; i--)
{
  sum = b[i];
  for (j = i + 1; j < n; j++)
    sum = sum - (a[i][j] * b[j]);

  b[i] = sum / a[i][i];
}
