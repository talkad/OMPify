for (int i = 0; i < v[0]->n; i++)
{
  for (int j = 0; j < v[0]->n; j++)
  {
    fprintf(f, "(%d,%d,%d) ", v[v.size() - 1]->res[i][j], v[v.size() - 1]->price[i][j], v[v.size() - 1]->boudget[i][j]);
  }

  fprintf(f, "\n");
}
