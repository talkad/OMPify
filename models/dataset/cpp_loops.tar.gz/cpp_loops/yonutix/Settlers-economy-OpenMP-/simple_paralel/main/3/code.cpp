for (int k = 0; k < (n * n); k++)
{
  boudgetInventory[k / n][k % n] = boudget[k / n][k % n] - getCheepestPrice(k / n, k % n);
}
