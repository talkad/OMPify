for (uint i = 1; i < v.size(); i++)
{
  fprintf(f, "%d %d %d %d\n", v[i]->resProducers[RESA], v[i]->resMaxPrice[RESA], v[i]->resProducers[RESB], v[i]->resMaxPrice[RESB]);
}
