for (uint i = 0; i < reports.size(); ++i)
{
  fprintf(f, "%d %d %d %d\n", reports[i].resAProducers, reports[i].resAmaxPrice, reports[i].resBProducers, reports[i].resBmaxPrice);
}
