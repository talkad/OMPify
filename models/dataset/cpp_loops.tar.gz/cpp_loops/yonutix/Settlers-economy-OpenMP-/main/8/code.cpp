for (int i = 0; i < y->n; ++i)
{
  for (int j = 0; j < y->n; ++j)
  {
    fprintf(f, "(%d,%d,%d) ", y->res[i][j], y->price[i][j], y->boudget[i][j]);
  }

  fprintf(f, "\n");
}
