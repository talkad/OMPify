for (int k = 1; k < ((p - resMinPrice[1 - res[x][y]]) + 1); ++k)
{
  to = MIN(k, n - y);
  for (int i = MAX(((abs(x - k) - x) + k) / 2, 0); i < to; ++i)
  {
    tmp_p = getCost(x, y, (x - k) + i, y + i);
    if (tmp_p < p)
    {
      p = (res[x][y] - res[(x - k) + i][y + i]) ? (tmp_p) : (p);
    }

  }

  to = MIN(k, n - x);
  for (int i = MAX(((((abs(((n - y) - k) - 1) - n) + y) + k) + 1) / 2, 0); i < to; ++i)
  {
    tmp_p = getCost(x, y, x + i, (y + k) - i);
    if (tmp_p < p)
    {
      p = (res[x][y] - res[x + i][(y + k) - i]) ? (tmp_p) : (p);
    }

  }

  to = MIN(k, (k - (((abs(y - k) - y) + k) / 2)) + 1);
  for (int i = MAX(((((abs(((n - x) - k) - 1) - n) + x) + k) + 1) / 2, 0); i < to; ++i)
  {
    tmp_p = getCost(x, y, (x + k) - i, y - i);
    if (tmp_p < p)
    {
      p = (res[x][y] - res[(x + k) - i][y - i]) ? (tmp_p) : (p);
    }

  }

  to = MIN(k, (k - (((abs(x - k) - x) + k) / 2)) + 1);
  for (int i = MAX(((abs(y - k) - y) + k) / 2, 0); i < to; ++i)
  {
    tmp_p = getCost(x, y, x - i, (y - k) + i);
    if (tmp_p < p)
    {
      p = (res[x][y] - res[x - i][(y - k) + i]) ? (tmp_p) : (p);
    }

  }

}
