for (int k = 0; k < (n * n); ++k)
  if (res[k / n][k % n] == RESA)
  nr = nr + 1;

