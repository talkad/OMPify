for (int i = 2; i < iterations; ++i)
{
  y1->updateYear(y2);
  y1->deployActivities();
  aux_y = y1;
  y1 = y2;
  y2 = aux_y;
}
