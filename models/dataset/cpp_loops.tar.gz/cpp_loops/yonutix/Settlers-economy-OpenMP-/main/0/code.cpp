for (int i = 0; i < n; ++i)
{
  for (int j = 0; j < n; ++j)
  {
    fscanf(f, "%d", &res[i][j]);
  }

}
