for (int i = 0; i < ((int) check.size()); ++i)
{
  if (!check[i])
  {
    for (int j = 0; j < ((int) colours.size()); ++j)
    {
      if (i == colours[j])
      {
        colours.erase(colours.begin() + j);
      }

    }

  }

}
