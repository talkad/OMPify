for (int i = 0; i < len; ++i)
{
  if (currentWeek[i / size][i % size] == k)
  {
    sum = sum + 1;
  }

}
