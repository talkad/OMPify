for (int i = cornerY; i < lenY; ++i)
{
  if (currentWeek[x - d][i] == c)
  {
    return true;
  }

}
