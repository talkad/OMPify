for (int i = 0; i < p->size; ++i)
{
  for (int j = 0; j < p->size; ++j)
  {
    fprintf(p->outFile, "%d ", p->currentWeek[i][j]);
  }

  fprintf(p->outFile, "\n");
}
