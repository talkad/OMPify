for (int k = 0; k < ((int) colours.size()); ++k)
{
  int dist = getMinDist(colours[k], x, y);
  if (dist > limit)
  {
    limit = dist;
    color_limit = (int) check.size();
  }

  if (dist == limit)
  {
    if (colours[k] < color_limit)
    {
      color_limit = colours[k];
    }

  }

}
