for (int i = 0; i < ((int) check.size()); ++i)
{
  check[i] = false;
}
