for (int i = 0; i < ((int) s.size()); ++i)
{
  fprintf(outFile, "%d ", s[i]);
}
