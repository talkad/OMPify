for (int i = 0; i < steps; ++i)
{
  p->getNextWeek();
}
