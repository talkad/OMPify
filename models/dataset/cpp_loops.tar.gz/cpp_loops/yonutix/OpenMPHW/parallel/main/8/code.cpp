for (int i = cornerX; i < lenX; ++i)
{
  if (currentWeek[i][y + d] == c)
  {
    return true;
  }

}
