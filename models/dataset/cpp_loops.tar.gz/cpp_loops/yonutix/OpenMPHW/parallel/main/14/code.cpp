for (int k = 0; k < ((int) s.size()); ++k)
{
  int sum = 0;
  #pragma omp parallel for reduction(+:sum)
  for (int i = 0; i < len; ++i)
  {
    if (currentWeek[i / size][i % size] == k)
    {
      sum = sum + 1;
    }

  }

  s[k] = sum;
}
