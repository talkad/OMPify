for (int i = 0; i < colourNr; ++i)
{
  colours.push_back(i);
  check.push_back(false);
}
