for (int i = 0; i < ((int) check.size()); ++i)
{
  s.push_back(0);
}
