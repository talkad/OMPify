for (int i = 0; i < d; ++i)
{
  if (colorExistByDist(c, x, y, i + 1))
    return i + 1;

}
