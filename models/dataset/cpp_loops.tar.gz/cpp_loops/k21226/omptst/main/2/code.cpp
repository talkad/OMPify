for (int ii = 0; ii < NN; ii++)
{
  int i = ii / N;
  int j = ii % N;
  avg += M[i][j];
}
