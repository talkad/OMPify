for (int p = 0; p < itt; p++)
  Avg += AvgM();
