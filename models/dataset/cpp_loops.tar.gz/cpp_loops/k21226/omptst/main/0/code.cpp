for (int ii = 0; ii < NN; ii++)
{
  int i = ii / N;
  int j = ii % N;
  M[i][j] = ((1. * rand()) / RAND_MAX) - .5;
}
