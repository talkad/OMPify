for (int i = 0; i < radius._height; i++)
{
  for (int j = 0; j < radius._width; j++)
  {
    if (radius(i, j) < dummy_var)
    {
      imin = i;
      jmin = j;
      dummy_var = radius(i, j);
    }

  }

}
