for (int i = 0; i < size; i++)
{
  TIS[i] = (((4. * M_PI) * s_rough_mirror) / wl[channel - 1]) * cos(theta0[i]);
  TIS[i] *= TIS[i];
}
