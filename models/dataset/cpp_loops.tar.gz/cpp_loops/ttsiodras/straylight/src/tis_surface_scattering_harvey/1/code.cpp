for (int i_angles = 0; i_angles < nb_i_angles; i_angles++)
  TIS[i_angles] *= 2.;
