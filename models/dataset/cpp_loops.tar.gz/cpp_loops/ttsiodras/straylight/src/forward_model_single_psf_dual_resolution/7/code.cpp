for (int i = 0; i < g_extended_image_dim_y; i++)
{
  for (int j = 0; j < g_extended_image_dim_x; j++)
  {
    pix_coordinate[0]->operator()(i, j) = j;
    pix_coordinate[1]->operator()(i, j) = i;
  }

}
