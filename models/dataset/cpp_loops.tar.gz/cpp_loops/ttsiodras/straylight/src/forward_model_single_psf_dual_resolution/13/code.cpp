for (int i = 0; i < g_extended_image_dim_y; i++)
{
  for (int j = 0; j < g_extended_image_dim_x; j++)
  {
    if (radius(i, j) == 0.)
      psf_totale(i, j) = psf_mirror_harvey(i, j) * psf_mirror_dust(i, j);
    else
      psf_totale(i, j) = psf_mirror_harvey(i, j) + psf_mirror_dust(i, j);

  }

}
