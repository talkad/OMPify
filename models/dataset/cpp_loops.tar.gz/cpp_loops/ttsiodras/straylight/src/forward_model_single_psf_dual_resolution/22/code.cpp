for (int i = 0; i < image_dim_y; i++)
{
  for (int j = 0; j < image_dim_x; j++)
  {
    output_image(i, j) = high_res_output_image(i, j) + low_res_extended_output_image_linterp((i + image_dim_y) + (g_cpt_dim_y / 2), (j + image_dim_x) + (g_cpt_dim_x / 2));
  }

}
