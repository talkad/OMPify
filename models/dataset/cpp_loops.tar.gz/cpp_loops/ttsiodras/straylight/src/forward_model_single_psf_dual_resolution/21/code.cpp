for (int i = 0; i < g_lowres_y; i++)
{
  for (int j = 0; j < g_lowres_x; j++)
  {
    unsigned in = ((i + ((g_extended_image_dim_y / 2) / g_low_to_high_spatial_resolution)) + 1) % g_lowres_y;
    unsigned jn = ((j + ((g_extended_image_dim_x / 2) / g_low_to_high_spatial_resolution)) + 1) % g_lowres_x;
    low_res_extended_output_image_shifted(in, jn) = low_res_extended_output_image[(g_lowres_x * i) + j];
  }

}
