for (int j = 0; j < vsize; j++)
{
  fprintf(fp, (scientific) ? (" %9.7e") : (" %12.4f"), v[j]);
  if (5 == (j % 6))
    fprintf(fp, "\n");

}
