for (i = 0; i < 3; i++)
  delta_incidence_angle[i] = i_angles_edge_FOV[i] - i_angles_center_FOV[i];
