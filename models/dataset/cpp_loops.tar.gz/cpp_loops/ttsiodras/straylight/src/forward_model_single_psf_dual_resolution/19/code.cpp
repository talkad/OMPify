for (i = 0; i < inY; i++)
  dumpVector(10, channel, high_res_output_image.getLine(i), high_res_output_image._width);
