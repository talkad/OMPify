for (int i = 0; i < g_extended_image_dim_y; i++)
{
  for (int j = 0; j < g_extended_image_dim_x; j++)
  {
    radius(i, j) = detector_size * sqrt(pow((*pix_coordinate[0])(i, j) - (g_extended_image_dim_x / 2), 2) + pow((*pix_coordinate[1])(i, j) - (g_extended_image_dim_y / 2), 2));
  }

}
