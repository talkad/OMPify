for (i = image_dim_y + (g_cpt_dim_y / 2); i <= (((2 * image_dim_y) - 1) + (g_cpt_dim_y / 2)); i++)
  for (int j = image_dim_x + (g_cpt_dim_x / 2); j <= (((2 * image_dim_x) - 1) + (g_cpt_dim_x / 2)); j++)
  input_extended_image(i, j) = input_image_corrected((i - image_dim_y) - (g_cpt_dim_y / 2), (j - image_dim_x) - (g_cpt_dim_x / 2));

