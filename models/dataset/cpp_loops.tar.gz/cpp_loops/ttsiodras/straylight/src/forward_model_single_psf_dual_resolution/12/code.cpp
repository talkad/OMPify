for (int i = 0; i < g_extended_image_dim_y; i++)
{
  for (int j = 0; j < g_extended_image_dim_x; j++)
  {
    psf_mirror_dust(i, j) = (radius(i, j) == 0.) ? (1.) : (0.);
  }

}
