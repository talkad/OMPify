for (i = 0; i < image_dim_x; i++)
{
  theta0_M1[i] = fabs((((delta_incidence_angle[0] * M_PI) / 180.) * (i - (image_dim_x / 2))) / ((tan((17.3 * M_PI) / 180.) * focal) / detector_size)) + ((i_angles_center_FOV[0] * M_PI) / 180.);
  theta0_M2[i] = fabs((((delta_incidence_angle[1] * M_PI) / 180.) * (i - (image_dim_x / 2))) / ((tan((17.3 * M_PI) / 180.) * focal) / detector_size)) + ((i_angles_center_FOV[1] * M_PI) / 180.);
  theta0_M3[i] = fabs((((delta_incidence_angle[2] * M_PI) / 180.) * (i - (image_dim_x / 2))) / ((tan((17.3 * M_PI) / 180.) * focal) / detector_size)) + ((i_angles_center_FOV[2] * M_PI) / 180.);
}
