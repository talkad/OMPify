for (int i = 0; i < image_dim_y; i++)
  for (int j = 0; j < image_dim_x; j++)
  output_image(i, j) += total;

