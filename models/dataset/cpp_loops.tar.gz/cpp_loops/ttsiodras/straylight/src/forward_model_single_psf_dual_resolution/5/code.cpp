for (i = 0; i < 3; i++)
  fprintf(fp, " %10.8f", TIS_surface_roughness_center_FOV[i]);
