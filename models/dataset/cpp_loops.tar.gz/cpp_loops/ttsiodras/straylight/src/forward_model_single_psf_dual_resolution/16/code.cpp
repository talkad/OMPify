for (i = 0; i < g_psf_extent; i++)
{
  for (j = 0; j < g_psf_extent; j++)
  {
    psf_totale(((g_extended_image_dim_y - g_psf_extent) / 2) + i, ((g_extended_image_dim_x - g_psf_extent) / 2) + j) = 0.;
  }

}
