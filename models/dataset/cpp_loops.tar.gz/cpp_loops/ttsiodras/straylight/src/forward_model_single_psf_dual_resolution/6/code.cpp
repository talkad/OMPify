for (i = 0; i < image_dim_x; i++)
{
  g_correction_direct_peak[i] = ((1. - TIS_surface_roughness_across_track(0, i)) * (1. - TIS_surface_roughness_across_track(1, i))) * (1. - TIS_surface_roughness_across_track(2, i));
  g_correction_direct_peak[i] /= ((1. - TIS_surface_roughness_center_FOV[0]) * (1. - TIS_surface_roughness_center_FOV[1])) * (1. - TIS_surface_roughness_center_FOV[2]);
}
