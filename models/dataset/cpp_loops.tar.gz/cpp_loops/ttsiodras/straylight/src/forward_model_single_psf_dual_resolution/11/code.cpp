for (int i = 0; i < g_extended_image_dim_y; i++)
  dumpVector(7, channel, psf_mirror_harvey.getLine(i), g_extended_image_dim_x, true);
