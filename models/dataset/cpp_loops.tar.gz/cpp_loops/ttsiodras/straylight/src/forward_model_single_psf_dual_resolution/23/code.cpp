for (int i_y = 0; i_y < image_dim_y; i_y++)
  for (int j = 0; j < image_dim_x; j++)
  total += input_image(i_y, j);

