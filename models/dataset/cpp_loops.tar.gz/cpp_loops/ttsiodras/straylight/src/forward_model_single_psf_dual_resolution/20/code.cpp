for (int i = 0; i < (g_lowres_y * g_lowres_x); i++)
{
  low_res_extended_output_image[i] = fabs(low_res_extended_output_image[i]) * (g_lowres_y * g_lowres_x);
}
