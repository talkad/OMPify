for (int ii = 0; ii < y; ii++)
{
  for (int j = 0; j < x; j++)
  {
    fprintf(fp, (scientific) ? (" %9.7e") : (" %12.4f"), pData[(x * ii) + j]);
    if (5 == (j % 6))
      fprintf(fp, "\n");

  }

  fputs("\n", fp);
}
