for (i = 0; i < 3; i++)
{
  for (j = 0; j < image_dim_x; j++)
    TIS_surface_roughness_across_track(i, j) = 0.0;

}
