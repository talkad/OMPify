for (int i = 0; i < g_extended_image_dim_y; i++)
  dumpVector(8, channel, psf_totale.getLine(i), g_extended_image_dim_x, true);
