for (int i_y = 0; i_y < image_dim_y; i_y++)
{
  for (int j = 0; j < image_dim_x; j++)
    input_image_corrected(i_y, j) = input_image(i_y, j) * g_correction_direct_peak[j];

}
