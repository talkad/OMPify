for (int i = 0; i < g_extended_image_dim_y; i++)
  dumpVector(6, channel, pix_coordinate[1]->getLine(i), g_extended_image_dim_x);
