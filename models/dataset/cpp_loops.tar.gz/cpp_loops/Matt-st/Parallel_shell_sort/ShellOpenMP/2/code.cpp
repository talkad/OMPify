for (int i = 0; i < 100000; i++)
{
  rnum = rand() % 1000000;
  arr[i] = rnum;
  temp[i] = arr[i];
}
