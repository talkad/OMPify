for (int f = half + i; f < length; f = f + half)
{
  j = f;
  while ((j > i) && (arr[j - half] > arr[j]))
  {
    temp = arr[j];
    arr[j] = arr[j - half];
    arr[j - half] = temp;
    j = j - half;
  }

}
