for (int l = 0; l < 100; l++)
{
  for (int i = 0; i < 100; i++)
  {
    A = CreateArray(temp);
    start = omp_get_wtime();
    shellSortSequential(A, length);
    end = omp_get_wtime();
    instanceTotal = end - start;
    total += instanceTotal;
  }

  ntotal = total / 100;
  newtotal += ntotal;
  newtotal = newtotal / 100;
}
