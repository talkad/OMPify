for (h = length / 2; h > 0; h = h / 2)
{
  for (int i = 0; i < h; i++)
  {
    for (int f = h + i; f < length; f = f + h)
    {
      j = f;
      while ((j > i) && (array[j - h] > array[j]))
      {
        temp = array[j];
        array[j] = array[j - h];
        array[j - h] = temp;
        j = j - h;
      }

    }

  }

}
