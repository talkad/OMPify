for (i = 0; i < h; i++)
{
  InsertSort(array, i, length, h);
}
