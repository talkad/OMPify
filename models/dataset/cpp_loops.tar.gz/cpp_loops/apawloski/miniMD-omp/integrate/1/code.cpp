for (i = 0; i < n3local; i++)
{
  if ((i % 3) == 0)
  {
    x[i / 3] += dt1 * v[i];
  }
  else
    if ((i % 3) == 1)
  {
    y[i / 3] += dt1 * v[i];
  }
  else
  {
    z[i / 3] += dt1 * v[i];
  }


}
