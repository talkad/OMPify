for (n = 0; n < ntimes; n++)
{
  x = atom.x;
  y = atom.y;
  z = atom.z;
  v = &atom.v[0][0];
  const int n3local = 3 * atom.nlocal;
  const double dt1 = dt;
  for (i = 0; i < n3local; i++)
  {
    if ((i % 3) == 0)
    {
      x[i / 3] += dt1 * v[i];
    }
    else
      if ((i % 3) == 1)
    {
      y[i / 3] += dt1 * v[i];
    }
    else
    {
      z[i / 3] += dt1 * v[i];
    }


  }

  timer.stamp();
  if ((n + 1) % neighbor.every)
  {
    comm.communicate(atom);
    timer.stamp(TIME_COMM);
  }
  else
  {
    comm.exchange(atom);
    comm.borders(atom);
    timer.stamp(TIME_COMM);
    neighbor.build(atom);
    timer.stamp(TIME_NEIGH);
  }

  force.compute(atom, neighbor, comm.me);
  timer.stamp(TIME_FORCE);
  comm.reverse_communicate(atom);
  timer.stamp(TIME_COMM);
  vold = &atom.vold[0][0];
  f = &atom.f[0][0];
  const int n3local2 = 3 * atom.nlocal;
  const double dtforce1 = dtforce;
  for (i = 0; i < n3local2; i++)
  {
    vold[i] = v[i];
    v[i] += dtforce1 * f[i];
  }

  if (thermo.nstat)
    thermo.compute(n + 1, atom, neighbor, force);

}
