for (i = 0; i < n3local2; i++)
{
  vold[i] = v[i];
  v[i] += dtforce1 * f[i];
}
