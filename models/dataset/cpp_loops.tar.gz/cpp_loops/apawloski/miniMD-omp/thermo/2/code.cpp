for (i = 0; i < n3local; i++)
{
  const double vx = 0.5 * (v[i] + vold[i]);
  t += vx * vx;
}
