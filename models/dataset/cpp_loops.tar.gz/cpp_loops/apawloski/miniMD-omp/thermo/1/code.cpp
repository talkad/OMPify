for (i = 0; i < atom.nlocal; i++)
{
  int j;
  int k;
  double delx;
  double dely;
  double delz;
  double rsq;
  double sr2;
  double sr6;
  double phi;
  const int * const neighs = neighbor.firstneigh[i];
  const int numneigh = neighbor.numneigh[i];
  for (k = 0; k < numneigh; k++)
  {
    j = neighs[k];
    delx = atom.x[i] - atom.x[j];
    dely = atom.y[i] - atom.y[j];
    delz = atom.z[i] - atom.z[j];
    rsq = ((delx * delx) + (dely * dely)) + (delz * delz);
    if (rsq < force.cutforcesq)
    {
      sr2 = 1.0 / rsq;
      sr6 = (sr2 * sr2) * sr2;
      phi = sr6 * (sr6 - 1.0);
      eng += phi;
    }

  }

}
