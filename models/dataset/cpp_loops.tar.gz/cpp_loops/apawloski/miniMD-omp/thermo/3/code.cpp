for (i = 0; i < n3all; i++)
{
  if ((i % 3) == 0)
    virial += f[i] * x[i / 3];
  else
    if ((i % 3) == 1)
    virial += f[i] * y[i / 3];
  else
    virial += f[i] * z[i / 3];


}
