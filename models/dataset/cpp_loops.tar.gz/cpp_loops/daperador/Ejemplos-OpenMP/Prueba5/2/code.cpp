for (i = 0; i < m; i++)
  for (j = 0; j < n; j++)
  b[(i * n) + j] = i;

