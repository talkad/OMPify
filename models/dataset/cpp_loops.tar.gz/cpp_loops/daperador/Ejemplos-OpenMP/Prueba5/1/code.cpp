for (j = 0; j < n; j++)
  c[j] = 2.0;
