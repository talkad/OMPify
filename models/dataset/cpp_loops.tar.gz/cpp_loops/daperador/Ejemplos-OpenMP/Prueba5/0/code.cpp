for (i = 0; i < m; i++)
{
  a[i] = 0.0;
  for (j = 0; j < n; j++)
    a[i] += b[(i * n) + j] * c[j];

}
