for (i = 0; i < n; i++)
{
  x = (i + 0.5) / n;
  area += 4.0 / (1.0 + (x * x));
}
