for (int i = 0; i < n; i++)
{
  resurse[i] = (int *) malloc(n * (sizeof(int)));
  preturi[i] = (int *) malloc(n * (sizeof(int)));
  bugete[i] = (int *) malloc(n * (sizeof(int)));
}
