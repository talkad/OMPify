for (int i = 0; i < n; i++)
  for (int j = 0; j < n; j++)
{
  cost = costMat[i][j].cost;
  costRes = costMat[i][j].costRes;
  if (cost > bugete[i][j])
  {
    preturi[i][j] = (preturi[i][j] + cost) - bugete[i][j];
    bugete[i][j] = cost;
  }
  else
    if (cost < bugete[i][j])
  {
    preturi[i][j] = preturi[i][j] + ((cost - bugete[i][j]) / 2);
    bugete[i][j] = cost;
  }
  else
    if (cost == bugete[i][j])
  {
    preturi[i][j] = costRes + 1;
    bugete[i][j] = cost;
  }



  if (preturi[i][j] < Pmin)
    preturi[i][j] = Pmin;

  if (preturi[i][j] > Pmax)
  {
    resurse[i][j] = 1 - resurse[i][j];
    bugete[i][j] = Pmax;
    preturi[i][j] = (Pmin + Pmax) / 2;
  }

}

