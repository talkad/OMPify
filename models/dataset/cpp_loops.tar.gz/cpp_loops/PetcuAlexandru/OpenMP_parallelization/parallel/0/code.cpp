for (int i1 = 0; i1 < n; i1++)
  for (int j1 = 0; j1 < n; j1++)
{
  if (resurse[i][j] == (1 - resurse[i1][j1]))
  {
    cost = preturi[i1][j1] + distanta(i, j, i1, j1);
    if (cost < c.cost)
      c.cost = cost;

  }
  else
  {
    costRes = preturi[i1][j1] + distanta(i, j, i1, j1);
    if (costRes < c.costRes)
      c.costRes = costRes;

  }

}

