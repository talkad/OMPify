for (int l = 0; l < n; l++)
  for (int h = 0; h < n; h++)
{
  c = Cost(l, h, n);
  costMat[l][h].cost = c.cost;
  costMat[l][h].costRes = c.costRes;
}

