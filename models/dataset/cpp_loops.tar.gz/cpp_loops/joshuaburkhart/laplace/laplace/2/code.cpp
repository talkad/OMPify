for (int col_num = 0; col_num < nx; col_num++)
{
  *((*h) + col_num) = HI_TEMP;
  *((*g) + col_num) = HI_TEMP;
}
