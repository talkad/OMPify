for (int row_num = 0; row_num < ny; row_num++)
{
  *(g + row_num) = (double *) malloc(nx * (sizeof(double)));
  *(h + row_num) = (double *) malloc(nx * (sizeof(double)));
}
