for (int i = 0; i < argc; i++)
{
  if (0 == strcmp(argv[i], "-nx"))
  {
    nx = atoi(argv[i + 1]);
  }
  else
    if (0 == strcmp(argv[i], "-ny"))
  {
    ny = atoi(argv[i + 1]);
  }
  else
    if (0 == strcmp(argv[i], "-eps"))
  {
    eps = (double) atof(argv[i + 1]);
  }
  else
    if (0 == strcmp(argv[i], "-fx"))
  {
    fx = atoi(argv[i + 1]);
  }
  else
    if (0 == strcmp(argv[i], "-fy"))
  {
    fy = atoi(argv[i + 1]);
  }
  else
    if (0 == strcmp(argv[i], "-fg"))
  {
    fg = atoi(argv[i + 1]);
  }






}
