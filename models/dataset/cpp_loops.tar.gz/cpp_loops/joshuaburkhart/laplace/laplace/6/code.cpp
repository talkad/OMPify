for (int row_num = 0; row_num < ny; row_num++)
{
  free(*(g + row_num));
  free(*(h + row_num));
}
