for (int row_num = 0; row_num < ny; row_num++)
{
  for (int col_num = 0; col_num < nx; col_num++)
  {
    (((((cout << row_num) << ",") << col_num) << ",") << (*((*(array + row_num)) + col_num))) << endl;
  }

}
