for (int row_num = base_height; row_num < (ny - 1); row_num++)
{
  for (int col_num = (fx_total * fin) + 1; col_num < (((fx_total * fin) + fx) - 1); col_num++)
  {
    int r = row_num;
    int c = col_num;
    double left = *((*(h + r)) + (c - 1));
    double right = *((*(h + r)) + (c + 1));
    double up = *((*(h + (r - 1))) + c);
    double down = *((*(h + (r + 1))) + c);
    double twin = *((*(h + r)) + c);
    *((*(g + r)) + c) = 0.25 * (((left + right) + up) + down);
    double self = *((*(g + r)) + c);
    if (((self * self) - (twin * twin)) > eps)
    {
      #pragma critical
      {
        converged = false;
      }
    }

  }

}
