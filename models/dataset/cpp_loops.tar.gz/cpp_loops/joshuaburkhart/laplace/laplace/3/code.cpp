for (int row_num = 1; row_num < ny; row_num++)
{
  for (int col_num = 0; col_num < nx; col_num++)
  {
    *((*(h + row_num)) + col_num) = LO_TEMP;
    *((*(g + row_num)) + col_num) = LO_TEMP;
  }

}
