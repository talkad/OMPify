for (i = 1; i <= 16; i++)
{
  subKeys[i] = permuta(chaveCD56[i], pc2, 48, 56);
}
