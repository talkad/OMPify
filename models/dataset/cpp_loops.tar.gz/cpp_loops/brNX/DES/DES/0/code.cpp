for (i = 1, j = 16; i < j; i++, j--)
{
  tempcpy = subKeys[i];
  subKeys[i] = subKeys[j];
  subKeys[j] = tempcpy;
}
