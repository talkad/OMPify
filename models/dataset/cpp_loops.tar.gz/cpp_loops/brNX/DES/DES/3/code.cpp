for (i = 0; i <= 16; i++)
{
  if (i == 0)
  {
    chaveCD56[i] = chaveC16[i];
    chaveCD56[i] = chaveCD56[i] << 28;
    chaveCD56[i] = chaveCD56[i] | chaveD16[i];
    continue;
  }

  if ((((i == 1) || (i == 2)) || (i == 9)) || (i == 16))
  {
    chaveC16[i] = rotateleft(chaveC16[i - 1], 28, 1) & 0xFFFFFFF;
    chaveCD56[i] = chaveC16[i];
    chaveCD56[i] = chaveCD56[i] << 28;
    chaveD16[i] = rotateleft(chaveD16[i - 1], 28, 1) & 0xFFFFFFF;
    chaveCD56[i] = chaveCD56[i] | chaveD16[i];
  }
  else
  {
    chaveC16[i] = rotateleft(chaveC16[i - 1], 28, 2) & 0xFFFFFFF;
    chaveCD56[i] = chaveC16[i];
    chaveCD56[i] = chaveCD56[i] << 28;
    chaveD16[i] = rotateleft(chaveD16[i - 1], 28, 2) & 0xFFFFFFF;
    ;
    chaveCD56[i] = chaveCD56[i] | chaveD16[i];
  }

}
