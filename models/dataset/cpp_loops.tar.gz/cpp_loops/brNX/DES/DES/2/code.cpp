for (i = 1; i <= 16; i++)
{
  r48 = 0;
  xOR48 = 0;
  s32 = 0;
  p32 = 0;
  parteE = parteDA;
  r48 = permuta(parteDA, e, 48, 32);
  xOR48 = r48 ^ subKeys[i];
  for (j = 0; j < 8; j++)
  {
    linhas = ((xOR48 >> ((47 - (6 * j)) - 1)) & 2) | ((xOR48 >> ((47 - (6 * j)) - 5)) & 1);
    colunas = (xOR48 >> ((47 - (6 * j)) - 4)) & 0xF;
    s32 |= s[j][linhas][colunas];
    if (j != 7)
      s32 = s32 << 4;

  }

  p32 = permuta(s32, p, 32, 32);
  parteD = parteEA ^ p32;
  parteDA = parteD;
  parteEA = parteE;
}
