for (i = 0; i < vezes; i++)
{
  unsigned long long plain = 0;
  unsigned long long cipher;
  int indice = i * 8;
  int x;
  for (x = 0; x < 8; x++)
    plain = plain | (((unsigned long long) inByteArray[indice + x]) << (64 - (8 * (x + 1))));

  cipher = encryptDESplain(plain, subKeys);
  for (x = 0; x < 8; x++)
    outByteArray[indice + x] = (unsigned char) ((cipher >> (56 - (8 * x))) & 0xFF);

}
