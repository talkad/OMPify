for (i = 0; i < tamanho; i++)
{
  bit = 0;
  bit = (b >> (blockSize - subs[i])) & 1;
  bytes = bytes | bit;
  if (i != (tamanho - 1))
    bytes = bytes << 1;

}
