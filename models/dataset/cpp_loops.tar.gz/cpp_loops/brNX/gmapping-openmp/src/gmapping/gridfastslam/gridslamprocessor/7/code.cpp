for (unsigned int i = 0; i < m_particles.size(); i++)
{
  m_particles[i].previousPose = m_particles[i].pose;
}
