for (const_iterator it = pmap.begin(); it != pmap.end(); it++)
  assert(it->first->shares == ((unsigned int) it->second));
