for (unsigned int i = 0; i < m_particles.size(); i++)
  if (bw < m_particles[i].weightSum)
{
  bw = m_particles[i].weightSum;
  bi = i;
}

