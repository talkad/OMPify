for (unsigned int i = 0; i < m_beams; i++)
{
  plainReading[i] = reading[i];
}
