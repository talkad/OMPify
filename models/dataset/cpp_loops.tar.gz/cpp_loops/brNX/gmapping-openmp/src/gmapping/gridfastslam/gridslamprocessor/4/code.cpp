for (unsigned int i = 0; i < size; i++)
{
  m_particles.push_back(Particle(lmap));
  m_particles.back().pose = initialPose;
  m_particles.back().previousPose = initialPose;
  m_particles.back().setWeight(0);
  m_particles.back().previousIndex = 0;
  m_particles.back().node = node;
}
