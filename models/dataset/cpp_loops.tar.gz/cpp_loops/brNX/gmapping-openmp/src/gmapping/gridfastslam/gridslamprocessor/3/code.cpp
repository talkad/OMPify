for (unsigned int i = 0; i < m_beams; i++)
{
  angles[i] = rangeSensor->beams()[i].pose.theta;
}
