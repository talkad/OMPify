for (unsigned int i = 0; i < v.size(); i++)
{
  m_particles[i].node = v[i];
}
