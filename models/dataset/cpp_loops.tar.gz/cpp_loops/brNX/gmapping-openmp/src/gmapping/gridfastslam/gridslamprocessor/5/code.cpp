for (unsigned int i = 0; i < m_particles.size(); i++)
{
  m_particles[i].pose = m_motionModel.drawFromMotion(m_particles[i].pose, relPose, m_odoPose);
}
