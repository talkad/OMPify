for (const_iterator it = gsp_->getParticles().begin(); it != gsp_->getParticles().end(); ++it)
{
  if ((it->weight / weight_total) > 0.0)
    entropy += (it->weight / weight_total) * log(it->weight / weight_total);

}
