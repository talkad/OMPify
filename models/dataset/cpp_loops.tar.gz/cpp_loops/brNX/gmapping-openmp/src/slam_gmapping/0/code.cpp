for (int i = 0; i < num_ranges; i++)
{
  if (scan.ranges[i] < scan.range_min)
    ranges_double[i] = (double) scan.range_max;
  else
    ranges_double[i] = (double) scan.ranges[(num_ranges - i) - 1];

}
