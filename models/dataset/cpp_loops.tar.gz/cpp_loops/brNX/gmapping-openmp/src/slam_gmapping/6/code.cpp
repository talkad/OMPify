for (int x = 0; x < smap.getMapSizeX(); x++)
{
  for (int y = 0; y < smap.getMapSizeY(); y++)
  {
    IntPoint p(x, y);
    double occ = smap.cell(p);
    assert(occ <= 1.0);
    if (occ < 0)
      map_.map.data[MAP_IDX(map_.map.info.width, x, y)] = -1;
    else
      if (occ > occ_thresh_)
    {
      map_.map.data[MAP_IDX(map_.map.info.width, x, y)] = 100;
    }
    else
      map_.map.data[MAP_IDX(map_.map.info.width, x, y)] = 0;


  }

}
