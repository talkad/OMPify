for (unsigned int i = 0; i < size; i++)
  fwrite(&scan.intensities[i], sizeof(float), 1, laserfile);
