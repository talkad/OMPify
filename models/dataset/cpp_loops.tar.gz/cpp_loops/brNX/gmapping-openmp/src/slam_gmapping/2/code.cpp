for (const_iterator it = gsp_->getParticles().begin(); it != gsp_->getParticles().end(); ++it)
{
  weight_total += it->weight;
}
