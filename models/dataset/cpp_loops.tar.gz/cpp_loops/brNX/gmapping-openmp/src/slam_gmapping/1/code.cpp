for (unsigned int i = 0; i < scan.ranges.size(); i++)
{
  if (scan.ranges[i] < scan.range_min)
    ranges_double[i] = (double) scan.range_max;
  else
    ranges_double[i] = (double) scan.ranges[i];

}
