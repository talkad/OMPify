for (unsigned int i = 0; i < scan.ranges.size(); i++)
  fwrite(&scan.ranges[i], sizeof(float), 1, laserfile);
