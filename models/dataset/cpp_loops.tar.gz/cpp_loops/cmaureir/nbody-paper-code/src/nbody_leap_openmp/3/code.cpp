for (int i = 0; i < n; i++)
{
  bodies[i].vx += (0.5 * dt) * (bodies[i].ax + bodies[i].ax0);
  bodies[i].vy += (0.5 * dt) * (bodies[i].ay + bodies[i].ay0);
  bodies[i].vz += (0.5 * dt) * (bodies[i].az + bodies[i].az0);
  bodies[i].ax0 = bodies[i].ax;
  bodies[i].ay0 = bodies[i].ay;
  bodies[i].az0 = bodies[i].az;
}
