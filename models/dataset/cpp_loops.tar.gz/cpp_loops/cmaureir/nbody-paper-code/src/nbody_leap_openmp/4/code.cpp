for (t = 0.0; t < ite; t += dt)
{
  updatePositions();
  updateAccelerations();
  updateVelocities();
}
