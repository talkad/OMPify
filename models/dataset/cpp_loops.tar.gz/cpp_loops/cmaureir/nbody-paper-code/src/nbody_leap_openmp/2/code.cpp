for (int i = 0; i < n; i++)
{
  bodies[i].ax0 = bodies[i].ax;
  bodies[i].ay0 = bodies[i].ay;
  bodies[i].az0 = bodies[i].az;
  bodies[i].x += (dt * bodies[i].vx) + (((0.5 * dt) * dt) * bodies[i].ax0);
  bodies[i].y += (dt * bodies[i].vy) + (((0.5 * dt) * dt) * bodies[i].ay0);
  bodies[i].z += (dt * bodies[i].vz) + (((0.5 * dt) * dt) * bodies[i].az0);
}
