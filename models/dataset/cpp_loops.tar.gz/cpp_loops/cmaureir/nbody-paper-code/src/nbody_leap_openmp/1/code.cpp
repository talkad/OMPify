for (i = 0; i < n; i++)
{
  for (j = 0; j < n; j++)
  {
    if (j != i)
    {
      calc(i, j);
    }

  }

}
