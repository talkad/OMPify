for (i = 0; i < n; i++)
{
  bodies[i].ax = (bodies[i].ay = (bodies[i].az = 0));
}
