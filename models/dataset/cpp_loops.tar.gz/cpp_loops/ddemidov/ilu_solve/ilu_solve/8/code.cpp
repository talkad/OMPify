for (int64_t r = lev_beg; r < lev_end; ++r)
{
  int64_t i = order[r];
  int64_t row_beg = ptr[r];
  int64_t row_end = ptr[r + 1];
  double X = 0;
  for (int64_t j = row_beg; j < row_end; ++j)
    X += val[j] * x[col[j]];

  if (lower)
    x[i] -= X;
  else
    x[i] = D[i] * (x[i] - X);

}
