for (int64_t r = lev_beg; r < lev_end; ++r)
{
  int64_t i = order[r];
  ptr[r + 1] = _ptr[i + 1] - _ptr[i];
}
