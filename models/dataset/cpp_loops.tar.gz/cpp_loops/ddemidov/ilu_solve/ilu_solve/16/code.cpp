for (int i = 0; i < niters; ++i)
  serial_solve(n, Lptr, Lcol, Lval, Uptr, Ucol, Uval, D, xs);
