for (int64_t lev = 0; lev < nlev; ++lev)
{
  int64_t lev_size = start[lev + 1] - start[lev];
  int64_t chunk_size = ((lev_size + nthreads) - 1) / nthreads;
  int64_t beg = min(tid * chunk_size, lev_size);
  int64_t end = min(beg + chunk_size, lev_size);
  beg += start[lev];
  end += start[lev];
  tasks[tid].push_back(task(beg, end));
  thread_rows[tid] += end - beg;
  for (int64_t i = beg; i < end; ++i)
  {
    int64_t j = order[i];
    thread_cols[tid] += _ptr[j + 1] - _ptr[j];
  }

}
