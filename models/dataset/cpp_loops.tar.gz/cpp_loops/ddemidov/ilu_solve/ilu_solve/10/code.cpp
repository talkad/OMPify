for (size_t i = 0; i < tasks.size(); ++i)
{
  int64_t t_id = tasks[i].thread_id;
  int64_t gbeg = tasks[i].row_beg;
  int64_t gend = tasks[i].row_end;
  int64_t lbeg = tasks[i].loc_beg;
  for (int64_t r = gbeg, k = lbeg; r < gend; ++r, ++k)
  {
    for (int64_t j = ptr[t_id][k]; j < ptr[t_id][k + 1]; ++j)
    {
      int64_t task_j = task_id[col[t_id][j]];
      if (marker[task_j] != i)
      {
        marker[task_j] = i;
        parent[i].insert(task_j);
        child[task_j].insert(i);
      }

    }

  }

}
