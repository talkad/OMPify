for (size_t i = 0; i < tasks.size(); ++i)
  deps[i] = depends[i];
