for (int64_t lev = 0; lev < nlev; ++lev)
{
  int64_t lev_size = start[lev + 1] - start[lev];
  int64_t chunk_size = ((lev_size + nthreads) - 1) / nthreads;
  for (int tid = 0; tid < nthreads; ++tid)
  {
    int64_t beg = min(tid * chunk_size, lev_size);
    int64_t end = min(beg + chunk_size, lev_size);
    beg += start[lev];
    end += start[lev];
    thread_rows[tid] += end - beg;
    int64_t this_task = tasks.size();
    thread_tasks[tid].push_back(this_task);
    tasks.push_back(task(tid, beg, end));
    for (int64_t i = beg; i < end; ++i)
    {
      int64_t j = order[i];
      task_id[j] = this_task;
      thread_cols[tid] += _ptr[j + 1] - _ptr[j];
    }

  }

}
