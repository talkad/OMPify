for (int i = 0; i < niters; ++i)
  S.solve(x3);
