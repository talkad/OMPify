for (int64_t i = 0; i < n; ++i)
  ++start[lev[i] + 1];
