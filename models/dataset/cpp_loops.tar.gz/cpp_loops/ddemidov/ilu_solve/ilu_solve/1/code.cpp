for (int64_t i = n; (i--) > 0;)
{
  double X = 0;
  for (int64_t j = Uptr[i], e = Uptr[i + 1]; j < e; ++j)
    X += Uval[j] * x[Ucol[j]];

  x[i] = D[i] * (x[i] - X);
}
