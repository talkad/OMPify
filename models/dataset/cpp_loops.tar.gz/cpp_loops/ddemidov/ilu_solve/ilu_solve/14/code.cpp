for (int64_t i = 0; i < n; ++i)
  order[start[level[i]]++] = i;
