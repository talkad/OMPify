for (int64_t i = 0; i < n; ++i)
  ++start[level[i] + 1];
