for (int64_t i = 0; i < n; i++)
{
  double X = 0;
  for (int64_t j = Lptr[i], e = Lptr[i + 1]; j < e; ++j)
    X += Lval[j] * x[Lcol[j]];

  x[i] -= X;
}
