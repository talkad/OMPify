for (int64_t r = lev_beg; r < lev_end; ++r)
{
  order[r] = 0;
}
