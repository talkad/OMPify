for (int64_t i = beg; i != end; i += inc)
{
  int64_t l = lev[i];
  for (int64_t j = _ptr[i]; j < _ptr[i + 1]; ++j)
    l = max(l, lev[_col[j]] + 1);

  lev[i] = l;
  nlev = max(nlev, l + 1);
}
