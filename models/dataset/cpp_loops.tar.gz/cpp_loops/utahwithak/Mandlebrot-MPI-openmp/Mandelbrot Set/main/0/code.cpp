for (int y = topLeft[1]; y < (chunkSize + topLeft[1]); y++)
{
  offx = 0;
  for (int x = topLeft[0]; x < (chunkSize + topLeft[0]); x++)
  {
    values[(Size * y) + x] = dataBlock[(chunkSize * offy) + offx];
    if (values[(Size * y) + x] != 0)
    {
      count++;
    }

    offx++;
  }

  offy++;
}
