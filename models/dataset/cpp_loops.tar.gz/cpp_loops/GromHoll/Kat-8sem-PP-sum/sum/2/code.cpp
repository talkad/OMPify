for (i = 0; i < C.x; i++)
{
  for (j = 0; j < C.y; j++)
  {
    C.m[i][j] = A.m[i][j] + B.m[i][j];
  }

}
