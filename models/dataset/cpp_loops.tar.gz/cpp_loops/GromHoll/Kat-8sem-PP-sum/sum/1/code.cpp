for (int j = 0; j < m.y; j++)
{
  for (int i = 0; i < m.x; i++)
  {
    (out << m.m[i][j]) << "\t";
  }

  out << endl;
}
