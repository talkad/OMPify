for (i = 0; i < n; ++i)
{
  for (j = 0; j < n; ++j)
  {
    for (k = 0; k < n; ++k)
    {
      sum += a[(i * n) + k] * b[(k * n) + j];
    }

    c[(i * n) + j] = sum;
  }

}
