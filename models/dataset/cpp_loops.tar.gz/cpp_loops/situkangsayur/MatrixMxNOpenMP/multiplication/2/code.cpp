for (i = 0; i < ordo; ++i)
{
  for (j = 0; j < ordo; ++j)
  {
    for (k = 0; k < ordo; ++k)
    {
      sum += a[(i * ordo) + k] * b[(k * ordo) + j];
    }

    c[(i * ordo) + j] = sum;
  }

}
