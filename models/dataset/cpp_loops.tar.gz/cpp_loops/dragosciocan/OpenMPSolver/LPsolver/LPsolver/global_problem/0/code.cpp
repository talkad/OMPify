for (int i = 0; i < num_partitions; ++i)
{
  primal_changes_.push_back(make_pair(make_pair(-1, 0.0), make_pair(-1, 0.0)));
}
