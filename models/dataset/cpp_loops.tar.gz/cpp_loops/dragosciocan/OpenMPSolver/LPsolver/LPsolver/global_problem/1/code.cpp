for (int i = 0; i < num_partitions_; ++i)
{
  budget_allocation_[i].second = 0;
  if (subproblems_[i].envelope_points_.size() > 1)
  {
    for (int j = 0; j < (subproblems_[i].envelope_points_.size() - 1); ++j)
    {
      slopes.push_back(Slope(subproblems_[i].envelope_points_[j].first, i, j));
    }

  }

}
