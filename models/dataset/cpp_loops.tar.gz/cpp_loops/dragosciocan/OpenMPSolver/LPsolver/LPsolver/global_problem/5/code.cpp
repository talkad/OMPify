for (int i = 0; i < subproblems_[subproblem_index].num_vars_; ++i)
{
  if (subproblems_[subproblem_index].constraints_[i].is_active_)
  {
    long double slack = subproblems_[subproblem_index].constraints_[i].price_ - ((u * subproblems_[subproblem_index].constraints_[i].coefficient_) + v);
    if (slack < 0)
    {
      slack = (-1) * slack;
    }

    if (slack < numerical_accuracy_tolerance_)
    {
      tight_constraint_indices.push_back(i);
    }

  }

}
