for (int i = 0; i < num_partitions_; ++i)
{
  budget_allocation_.push_back(make_pair(0, 0.0));
}
