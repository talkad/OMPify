for (int i = 0; i < num_partitions_; ++i)
{
  subproblems_[i].SolveSubproblemConvexHullOptimized();
}
