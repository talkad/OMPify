for (int k = 0; k < slopes.size(); ++k)
{
  sp_index = slopes[k].subproblem_index_;
  long double allocation_increase = min(remaining_budget, subproblems_[sp_index].budget_cutoffs_[slopes[k].region_index_ + 1] - subproblems_[sp_index].budget_cutoffs_[slopes[k].region_index_]);
  if ((allocation_increase > 0) && (remaining_budget > 0))
  {
    budget_allocation_[sp_index] = make_pair(slopes[k].region_index_, budget_allocation_[sp_index].second + allocation_increase);
  }

  remaining_budget = remaining_budget - allocation_increase;
}
