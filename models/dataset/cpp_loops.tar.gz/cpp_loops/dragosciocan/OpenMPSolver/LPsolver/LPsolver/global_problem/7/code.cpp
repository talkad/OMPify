for (int i = 0; i < num_partitions_; ++i)
{
  (*budget_usage)[i] = 0;
  for (int j = 0; j < (subproblems_[i].envelope_points_.size() - 1); ++j)
  {
    if (subproblems_[i].envelope_points_[j].first >= critical_ratio)
    {
      (*budget_usage)[i] += subproblems_[i].budget_cutoffs_[j + 1] - subproblems_[i].budget_cutoffs_[j];
    }

  }

  total_budget_usage += (*budget_usage)[i];
}
