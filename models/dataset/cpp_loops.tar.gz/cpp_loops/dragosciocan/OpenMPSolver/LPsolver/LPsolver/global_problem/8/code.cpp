for (int i = 0; i < num_partitions_; ++i)
{
  for (int j = 0; j < (subproblems_[i].envelope_points_.size() - 1); ++j)
  {
    if (subproblems_[i].envelope_points_[j].first >= critical_ratio)
    {
      budget_allocation_[i] = make_pair(j, (budget_allocation_[i].second + subproblems_[i].budget_cutoffs_[j + 1]) - subproblems_[i].budget_cutoffs_[j]);
    }

  }

}
