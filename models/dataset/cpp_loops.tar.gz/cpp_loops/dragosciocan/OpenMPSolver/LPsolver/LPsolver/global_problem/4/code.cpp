for (int i = 0; i < num_partitions_; ++i)
{
  if (budget_allocation_[i].second > 0)
  {
    long double u = subproblems_[i].envelope_points_[budget_allocation_[i].first].first;
    long double v = subproblems_[i].envelope_points_[budget_allocation_[i].first].second;
    dual_val += (u * budget_allocation_[i].second) + v;
    ConstructSubproblemPrimal(i, budget_allocation_[i].second, budget_allocation_[i].first);
  }

}
