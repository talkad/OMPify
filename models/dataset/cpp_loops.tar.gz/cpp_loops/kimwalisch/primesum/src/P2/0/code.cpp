for (int i = 0; i < threads; i++)
  p2 += P2_OpenMP_thread(x, y, z, thread_distance, i, low, prime_sums[i], correct[i]);
