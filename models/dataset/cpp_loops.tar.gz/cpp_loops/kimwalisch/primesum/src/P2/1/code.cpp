for (int i = 0; i < threads; i++)
{
  p2 += prime_sum * correct[i];
  prime_sum += prime_sums[i];
}
