for (int i = 0; i < threads; i++)
{
  timings[i] = get_time();
  S2_total += S2_thread(x, y, c, segment_size, segments_per_thread, i, low, limit, pi, primes, lpf, mu, mu_sum[i], phi[i]);
  timings[i] = get_time() - timings[i];
}
