for (int i = 0; i < threads; i++)
{
  for (size_t j = 1; j < phi[i].size(); j++)
  {
    S2_total += mu_sum[i][j] * phi_total[j];
    phi_total[j] += phi[i][j];
  }

}
