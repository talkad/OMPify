for (; m < high; m += prime * next_multiple_factor(&wheel_index))
  sieve.unset(m - low);
