for (; low < limit; low += segment_size)
{
  int64_t high = min(low + segment_size, limit);
  int64_t b = c + 1;
  sieve.pre_sieve(c, low);
  for (; b < min(pi_sqrty, size); b++)
  {
    int64_t prime = primes[b];
    int64_t min_m = max(x / (prime * high), y / prime);
    int64_t max_m = min(x / (prime * low), y);
    int64_t i = 0;
    if (prime >= max_m)
      goto next_segment;

    for (int64_t m = max_m; m > min_m; m--)
    {
      if ((mu[m] != 0) && (prime < lpf[m]))
      {
        int64_t xn = x / (prime * m);
        int64_t stop = xn - low;
        for (; i <= stop; i += 2)
          phi[b] += (low + i) * sieve[i];

        S2_thread -= phi[b] * ((mu[m] * m) * prime);
        mu_sum[b] -= (mu[m] * m) * prime;
      }

    }

    for (; i < (high - low); i += 2)
      phi[b] += (low + i) * sieve[i];

    cross_off(sieve, low, high, prime, wheel[b]);
  }

  for (; b < min(pi_y, size); b++)
  {
    int64_t prime = primes[b];
    int64_t l = pi[min(x / (prime * low), y)];
    int64_t min_m = max(x / (prime * high), y / prime, prime);
    int64_t i = 0;
    if (prime >= primes[l])
      goto next_segment;

    for (; primes[l] > min_m; l--)
    {
      int64_t xn = x / (prime * primes[l]);
      int64_t stop = xn - low;
      for (; i <= stop; i += 2)
        phi[b] += (low + i) * sieve[i];

      S2_thread += phi[b] * (primes[l] * prime);
      mu_sum[b] += primes[l] * prime;
    }

    for (; i < (high - low); i += 2)
      phi[b] += (low + i) * sieve[i];

    cross_off(sieve, low, high, prime, wheel[b]);
  }

  next_segment:
  ;

}
