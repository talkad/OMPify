for (int64_t x = 0; x < 10000; x++)
  check(f1, f2);
