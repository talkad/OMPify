for (int64_t i = c; i < pi_sqrtx; i++)
{
  int64_t x2 = fast_div(x, primes_[i + 1]);
  if (is_pix(x2, i))
    sum += ((pi_[x2] - i) + 1) * (-SIGN);
  else
    sum += (phi < (-SIGN)) > ((x2, i));

}
