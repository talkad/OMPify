for (int64_t i = c; i < pi_sqrtx; i++)
  sum += (cache.phi < (-1)) > ((x / primes[i + 1], i));
