for (; m < high; m += prime * next_multiple_factor(&wheel_index))
{
  if (sieve[m - low])
  {
    sieve.unset(m - low);
    tree.update(m, low);
  }

}
