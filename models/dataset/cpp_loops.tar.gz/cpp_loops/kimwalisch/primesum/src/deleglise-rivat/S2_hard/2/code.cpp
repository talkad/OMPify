for (int i = 0; i < threads; i++)
{
  timings[i] = get_time();
  s2_hard += S2_hard_OpenMP_thread(x, y, z, c, segment_size, segments_per_thread, i, low, limit, alpha, factors, pi, primes, mu_sum[i], phi[i]);
  timings[i] = get_time() - timings[i];
}
