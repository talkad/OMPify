for (; m < high; m += prime * next_multiple_factor(&wheel_index))
{
  sum += m * sieve[m - low];
  sieve.unset(m - low);
}
