for (b++; b < primes.size(); b++)
{
  T next = square_free * primes[b];
  if (next > y)
    break;

  s1 += MU * phi_tiny(x / next, c);
  s1 += (S1_thread < (-MU)) > ((x, y, b, c, next, primes));
}
