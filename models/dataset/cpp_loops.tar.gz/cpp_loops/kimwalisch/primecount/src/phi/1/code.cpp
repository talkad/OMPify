for (; i <= a; i++)
{
  if (primes_[i] > sqrtx)
    break;

  int64_t xp = fast_div(x, primes_[i]);
  sum += ((pi_[xp] - i) + 2) * (-SIGN);
}
