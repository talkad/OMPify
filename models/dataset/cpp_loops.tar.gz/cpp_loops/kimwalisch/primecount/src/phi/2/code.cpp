for (int64_t i = c + 1; i <= a; i++)
  sum += (cache.phi < (-1)) > ((x / primes[i], i - 1));
