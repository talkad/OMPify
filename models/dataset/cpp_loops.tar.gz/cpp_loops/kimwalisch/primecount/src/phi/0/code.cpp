for (i = c + 1; i <= a; i++)
{
  if (primes_[i] > sqrtx)
    break;

  int64_t xp = fast_div(x, primes_[i]);
  if (is_pix(xp, i - 1))
    break;

  sum += (phi < (-SIGN)) > ((xp, i - 1));
}
