for (int64_t i = a + 1; i <= pi_x13; i++)
{
  int64_t xi = x / primes[i];
  int64_t bi = pi[isqrt(xi)];
  for (int64_t j = i; j <= bi; j++)
    sum += pi[xi / primes[j]] - (j - 1);

}
