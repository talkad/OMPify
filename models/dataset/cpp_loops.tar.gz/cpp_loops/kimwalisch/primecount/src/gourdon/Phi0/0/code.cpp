for (b++; b < primes.size(); b++)
{
  T next = square_free * primes[b];
  if (next > z)
    break;

  phi0 += MU * phi_tiny(x / next, k);
  phi0 += (Phi0_thread < (-MU)) > ((x, z, b, k, next, primes));
}
