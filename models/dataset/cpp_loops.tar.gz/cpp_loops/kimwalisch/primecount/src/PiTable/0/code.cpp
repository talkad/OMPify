for (int t = 0; t < threads; t++)
{
  uint64_t low = cache_limit + (thread_dist * t);
  uint64_t high = low + thread_dist;
  high = min(high, limit);
  if (low < high)
    init_bits(low, high, t);

}
