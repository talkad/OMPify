for (; i < stop_idx; i++)
{
  pi_[i].count = count;
  count += popcnt64(pi_[i].bits);
}
