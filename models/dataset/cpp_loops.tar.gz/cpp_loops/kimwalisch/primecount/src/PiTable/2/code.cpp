for (uint64_t i = 0; i < thread_num; i++)
  count += counts_[i];
