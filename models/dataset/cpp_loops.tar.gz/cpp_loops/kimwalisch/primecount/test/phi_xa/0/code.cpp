for (int64_t i = 0; i < iters; i++)
  sum1 += pi_legendre(10000000 + i, 1);
