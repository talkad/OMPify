for (unsigned i = 0; i < nvert; i++)
  sum += pagerank[i];
