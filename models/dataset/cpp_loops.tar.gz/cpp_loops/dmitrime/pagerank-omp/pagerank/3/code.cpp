for (unsigned i = 0; i < nvert; i++)
  if (graph->count_edges(i) == 0)
  zsum += last[i];

