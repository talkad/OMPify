for (unsigned i = 0; i < N; i++)
{
  (off << pagerank[i]) << endl;
  if (pagerank[i] > pmax)
  {
    pmax = pagerank[i];
    imax = i;
  }

  if (pagerank[i] < pmin)
  {
    pmin = pagerank[i];
    imin = i;
  }

}
