for (unsigned i = 0; i < nvert; i++)
  err += fabs(pagerank[i] - last[i]);
