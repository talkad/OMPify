for (unsigned i = 0; i < nvert; i++)
  pagerank[i] *= sum;
