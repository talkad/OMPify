for (unsigned i = 0; i < nvert; i++)
{
  last[i] = pagerank[i];
  pagerank[i] = 0.0;
}
