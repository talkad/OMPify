for (int i = 0; i < 64; i++)
{
  dummymatrix->AddElem(0, 0, 1);
  dummymatrix->AddElem(10, 10, 1);
  dummymatrix->AddElem(1000, 0, 1);
  dummymatrix->AddElem(0, 70, 1);
}
