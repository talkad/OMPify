for (int i = rowlen - 1; i >= 0; i--)
{
  m_testmatrix->AddElem(0, i, 1);
  m_testmatrix->AddElem(10, i, 2);
}
