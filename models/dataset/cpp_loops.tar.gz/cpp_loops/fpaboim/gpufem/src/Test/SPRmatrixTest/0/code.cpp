for (int i = 0; i < dummydim; i++)
{
  dummymatrix->SetElem(0, i, 1);
  dummymatrix->SetElem(i, 0, 1);
  dummymatrix->SetElem(100, i, 1);
  dummymatrix->SetElem(i, 100, 1);
  dummymatrix->SetElem(1000, i, 1);
  dummymatrix->SetElem(i, 1000, 1);
}
