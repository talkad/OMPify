for (int i = 0; i < m_matdim; i++)
{
  testaccumulator1 += m_testmatrix->GetElem(0, i);
  testaccumulator2 += m_testmatrix->GetElem(10, i);
}
