for (int i = 0; i < m_matdim; i++)
{
  m_testmatrix->SetElem(0, i, 1);
  m_testmatrix->SetElem(10, i, 2);
  accumulator += i;
}
