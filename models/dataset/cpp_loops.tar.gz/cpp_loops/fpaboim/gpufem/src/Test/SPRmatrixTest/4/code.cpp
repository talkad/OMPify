for (i = 0; i < dim; i++)
{
  for (j = 0; j < dim; j++)
  {
    testaccumulator += m_testmatrix->GetElem(i, j);
  }

}
