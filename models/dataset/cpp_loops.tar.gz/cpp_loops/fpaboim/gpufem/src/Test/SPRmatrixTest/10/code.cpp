for (int i = 0; i < m_matdim; ++i)
{
  testfloat += yvec[i];
}
