for (int i = 0; i < num; i++)
{
  sum += vals[i];
  product *= vals[i];
  numops++;
}
