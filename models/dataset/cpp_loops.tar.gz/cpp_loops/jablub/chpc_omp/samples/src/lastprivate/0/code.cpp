for (int i = 0; i < 12; i++)
{
  val = i;
}
