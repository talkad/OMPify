for (int i = 0; i < 12; i++)
{
  printf("Hello Looper from thread = %d   (i=%d  at  %p) \n", omp_get_thread_num(), i, &i);
}
