for (int i = 0; i < 4; i++)
{
  if (i > 0)
  {
    a[i] = a[i] + a[i - 1];
  }

}
