for (i = 0; i < 2; i++)
{
  b.doit();
  printf("Iteration %2d is carried out by thread %2d\n", i, omp_get_thread_num());
}
