for (iter = stmt_list.begin(); iter != stmt_list.end(); iter++)
{
  if (iter == stmt_list.begin())
  {
    insertStatementAfterLastDeclaration(*iter, target_block);
  }
  else
  {
    ROSE_ASSERT(prev_stmt != NULL);
    insertStatementAfter(prev_stmt, *iter);
  }

  prev_stmt = *iter;
}
