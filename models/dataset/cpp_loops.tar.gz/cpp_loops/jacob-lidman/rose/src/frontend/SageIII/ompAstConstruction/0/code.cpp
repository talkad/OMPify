for (end_iter = omp_end_pragma_list.rbegin(); end_iter != omp_end_pragma_list.rend(); end_iter++)
  removeStatement(*end_iter);
