for (i = iters->begin(); i != iters->end(); ++i)
  if (!strcmp(*i, (char *) pf->iterator->symbol->data))
  break;

