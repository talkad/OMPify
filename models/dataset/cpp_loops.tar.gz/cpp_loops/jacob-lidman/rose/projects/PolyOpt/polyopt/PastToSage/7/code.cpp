for (i = usedSymbols.begin(); i != usedSymbols.end(); ++i)
  _usedSymbols.push_back(string((*i)->get_name().str()));
