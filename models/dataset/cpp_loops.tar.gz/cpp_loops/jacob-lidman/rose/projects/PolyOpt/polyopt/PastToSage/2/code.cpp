for (i = _scoplibIterators.begin(); i != _scoplibIterators.end(); ++i)
  if (ptr == ((void *) (*i)))
  return true;

