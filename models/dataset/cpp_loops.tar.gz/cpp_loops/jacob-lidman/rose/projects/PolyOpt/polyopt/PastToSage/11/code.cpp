for (i = iters->begin(); i != iters->end(); ++i)
  if (!strcmp(*i, (char *) pv->symbol->data))
  break;

