for (i = 0, tmp = symtable->symbols; tmp; tmp = tmp->next, ++i)
  ;
