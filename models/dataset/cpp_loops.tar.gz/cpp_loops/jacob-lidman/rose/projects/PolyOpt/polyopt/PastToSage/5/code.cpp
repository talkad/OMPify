for (i = 0, tmp = symtable->symbols; tmp; tmp = tmp->next)
  if (((tmp->is_char_data && (!isIterator(tmp->data))) && tmp->data) && (((char *) tmp->data)[0] == 'T'))
  allsyms[i++] = tmp;

