for (it = _sageTileSizeParameters.begin(); it != _sageTileSizeParameters.end(); ++it)
  unionDecls.insert(*it);
