for (i = its->begin(); i != its->end(); ++i)
  if ((f->iterator && f->iterator->symbol->is_char_data) && (!strcmp((char *) (*i), (char *) f->iterator->symbol->data)))
  break;

