for (i = annotationNodes.begin(); i != annotationNodes.end(); ++i)
  if ((*i)->next == cnode)
  break;

