for (j = _usedSymbols.begin(); j != _usedSymbols.end(); ++j)
  if (!strcmp(j->c_str(), buffer))
{
  isUsedSymbol = true;
  break;
}

