for (int i = 0; i < pv->size(); ++i)
  iters->push_back((char *) isSgVariableSymbol((*pv)[i])->get_name().getString().c_str());
