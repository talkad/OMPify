for (i = _scoplibIterators.begin(); i != _scoplibIterators.end(); ++i)
  if (ptr == (*i))
  return true;

