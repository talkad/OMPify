for (int i = 2; i < minmax->n; ++i)
{
  exprB = buildExpression(minmax->elts[i]);
  if (minmax->type == clast_red_max)
    compExpr = (buildBinaryExpression < SgGreaterThanOp) > ((retExpr, exprB));
  else
    compExpr = (buildBinaryExpression < SgLessThanOp) > ((retExpr, exprB));

  retExpr = buildConditionalExp(compExpr, copyExpression(retExpr), copyExpression(exprB));
}
