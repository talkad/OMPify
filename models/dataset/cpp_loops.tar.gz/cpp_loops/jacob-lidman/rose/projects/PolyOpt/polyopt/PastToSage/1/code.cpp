for (i = iters->begin(); i != iters->end(); ++i)
  if (!strcmp((char *) (*i), (char *) pv->symbol->data))
  break;

