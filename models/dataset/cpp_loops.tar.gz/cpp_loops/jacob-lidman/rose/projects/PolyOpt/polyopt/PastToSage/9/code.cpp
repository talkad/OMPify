for (i = _fakeSymbolMap.begin(); i != _fakeSymbolMap.end(); ++i)
  if (i->second == varref->symbol->data)
  break;

