for (i = _sageTileSizeParameters.begin(); i != _sageTileSizeParameters.end(); ++i)
  if (ptr == ((void *) i->first))
  return true;

