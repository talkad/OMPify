for (i = 0; i < SIZE; i++)
{
  v1[i] = (double) i;
  v2[i] = (double) (i / 2.0);
}
