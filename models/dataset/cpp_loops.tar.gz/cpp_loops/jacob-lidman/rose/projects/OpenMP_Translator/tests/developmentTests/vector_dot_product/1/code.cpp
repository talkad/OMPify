for (i = 0; i < SIZE; i++)
  result = result + sqrt((v1[i] * v1[i]) + (v2[i] * v2[i]));
