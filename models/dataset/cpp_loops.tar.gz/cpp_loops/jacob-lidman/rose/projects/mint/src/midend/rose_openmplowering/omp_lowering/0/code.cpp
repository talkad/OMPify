for (size_t i = 0; i < p_clause.size(); i++)
{
  result2 = isSgOmpVariablesClause(p_clause[i])->get_variables();
  copy(result2.begin(), result2.end(), back_inserter(result));
}
