for (uint64_t i = 0; i < b; ++i)
{
  c = c * a;
}
