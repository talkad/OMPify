for (uint64_t d = 0; d < str_len; ++d)
{
  uint64_t r = n % b;
  str[d] = characters[r];
  n = n / b;
}
