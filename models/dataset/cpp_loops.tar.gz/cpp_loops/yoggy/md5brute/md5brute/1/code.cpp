for (unsigned int i = 0; i < md_length; ++i)
{
  (ss << hex) << ((unsigned int) md[i]);
}
