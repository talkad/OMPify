for (unsigned int tmp_end = 0; tmp_end < line.size(); tmp_end++)
{
  tmp_max_sum += line[tmp_end];
  if (tmp_max_sum > max.sum)
  {
    max.sum = tmp_max_sum;
    max.startX = tmp_start;
    max.endX = tmp_end;
  }

  if (tmp_max_sum < 0)
  {
    tmp_max_sum = 0;
    tmp_start = tmp_end + 1;
  }

}
