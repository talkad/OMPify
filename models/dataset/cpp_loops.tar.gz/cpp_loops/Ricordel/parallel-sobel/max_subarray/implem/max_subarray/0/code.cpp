for (unsigned int k = 0; k < max.size(); k++)
{
  if (max[k].sum > global_max.sum)
  {
    global_max = max[k];
  }

}
