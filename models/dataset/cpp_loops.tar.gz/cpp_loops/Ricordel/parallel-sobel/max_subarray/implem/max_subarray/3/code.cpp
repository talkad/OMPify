for (int col = 0; col < matSize; col++)
{
  for (int line = 1; line < matSize; line++)
  {
    cumulMat.setDataAt(line, col, cumulMat.getDataAt(line - 1, col) + mat.getDataAt(line, col));
  }

}
