for (unsigned int i = 0; i < line.size(); i++)
{
  line[i] -= cumulMatrix[startLine - 1][i];
}
