for (int i = 0; i < l; ++i)
{
  for (int j = 0; j < n; ++j)
    printf("%d ", R[i][j]);

  printf("\n");
}
