for (int i = 0; i < l; ++i)
  for (int j = 0; j < m; ++j)
  scanf("%d", &P[i][j]);

