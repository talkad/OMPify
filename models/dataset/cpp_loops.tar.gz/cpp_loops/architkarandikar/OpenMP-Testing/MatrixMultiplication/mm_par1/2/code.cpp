for (int i = 0; i < l; ++i)
  for (int j = 0; j < n; ++j)
  for (int k = 0; k < m; ++k)
  R[i][j] += P[i][k] * Q[k][j];


