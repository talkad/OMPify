for (int cn = 0; cn <= n; ++cn)
  C[cn][0] = 1;
