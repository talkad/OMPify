for (int ck = 1; ck <= k; ++ck)
{
  C[cn][ck] = C[cn - 1][ck - 1] + C[cn - 1][ck];
  C[cn][ck] %= modref;
}
