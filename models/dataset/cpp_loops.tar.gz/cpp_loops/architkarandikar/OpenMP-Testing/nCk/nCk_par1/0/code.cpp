for (int ck = 1; ck <= k; ++ck)
  C[0][ck] = 0;
