for (int ck = 0; ck <= k; ++ck)
  pC[ck] = cC[ck];
