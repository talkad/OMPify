for (int ck = 1; ck <= k; ++ck)
{
  cC[ck] = pC[ck - 1] + pC[ck];
  cC[ck] %= modref;
}
