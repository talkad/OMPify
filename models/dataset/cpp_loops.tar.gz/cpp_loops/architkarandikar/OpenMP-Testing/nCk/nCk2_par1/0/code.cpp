for (int ck = 1; ck <= k; ++ck)
  pC[ck] = 0;
