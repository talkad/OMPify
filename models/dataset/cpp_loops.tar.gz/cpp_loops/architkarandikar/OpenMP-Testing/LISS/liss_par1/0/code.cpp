for (int i = 0; i < n; ++i)
  scanf("%d", &A[i]);
