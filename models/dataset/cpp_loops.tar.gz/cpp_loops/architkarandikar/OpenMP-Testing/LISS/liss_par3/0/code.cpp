for (int j = 0; j < i; ++j)
{
  #pragma omp ordered
  {
    if (A[j] < A[i])
      liss[i] = max(liss[i], liss[j] + 1);

  }
}
