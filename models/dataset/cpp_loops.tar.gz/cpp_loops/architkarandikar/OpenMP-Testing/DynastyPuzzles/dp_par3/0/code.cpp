for (int i = 0; i < n; ++i)
{
  {
    scanf("%s", tc);
    for (tsz = 0; tc[tsz] != '\0'; ++tsz)
      ;

    sz[i] = tsz;
    fl[i] = (int) (tc[0] - 'a');
    ll[i] = (int) (tc[tsz - 1] - 'a');
  }
}
