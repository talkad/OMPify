for (int l = 0; l < 26; ++l)
{
  for (int j = 0; j < 26; ++j)
    C[j] = minv;

  C[l] = 0;
  for (int i = 0; i < n; ++i)
  {
    C[ll[i]] = max(C[ll[i]], C[fl[i]] + sz[i]);
    if (C[ll[i]] < 0)
      C[ll[i]] = minv;

  }

  res = max(res, C[l]);
}
