for (int i = 0; i < 10; i++)
{
  printf("thread %d - vett[%d] = %d \n", omp_get_thread_num(), i, vett[i]);
  if (vett[i] < min)
  {
    min2 = min;
    min = vett[i];
  }
  else
    if (vett[i] < min2)
  {
    min2 = vett[i];
  }


}
