for (unsigned int i = 0; i < nel; i++)
{
  send_file(img_names[i].c_str(), 1);
}
