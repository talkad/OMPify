for (unsigned int i = 0; i < nel; i++)
{
  receive_file(dest_path(myrank, i), 0, 1);
}
