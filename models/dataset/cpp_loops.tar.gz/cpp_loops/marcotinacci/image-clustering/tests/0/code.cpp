for (unsigned int i = 0; i < nel; i++)
{
  printf("map[%d] = %d \n", i, vett[i]);
}
