for (int i = 1; i < np; i++)
{
  if (max_vett[i].val > max_vett[i_max].val)
  {
    i_max = i;
  }

}
