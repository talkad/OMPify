for (unsigned int i = 0; i < nel; i++)
{
  for (unsigned int j = 0; j < nel; j++)
  {
    if (i < j)
    {
      (cout << map[k]) << ' ';
      k++;
    }
    else
    {
      cout << "_ ";
    }

  }

  cout << endl;
}
