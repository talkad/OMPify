for (unsigned int i = 0; i < dim; i++)
{
  if (info[2] == 0)
  {
    buf[i] = get(matrix_parts[0], dim, i, info[1]);
  }
  else
    if (info[3] == 0)
  {
    buf[i] = matrix_parts[info[2]][(info[1] * col) + i];
  }
  else
    if (info[3] == 1)
  {
    buf[i] = matrix_parts[info[2]][(col * i) + info[1]];
  }
  else
  {
    ((cerr << "Errore: codice info[3] = ") << info[3]) << endl;
  }



}
