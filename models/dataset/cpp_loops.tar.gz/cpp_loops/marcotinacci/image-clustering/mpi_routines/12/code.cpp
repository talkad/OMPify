for (unsigned int j = 0; j < ((unsigned int) (np / 2)); j++)
{
  if (j != 0)
  {
    int info1[] = {(np / 2) + j, -1};
    MPI_Send((void *) info1, 2, MPI_INT, j, TAG_TRANSFER_INFO, MPI_COMM_WORLD);
  }

  int info2[] = {-1, j};
  MPI_Send((void *) info2, 2, MPI_INT, (np / 2) + j, TAG_TRANSFER_INFO, MPI_COMM_WORLD);
}
