for (int row = 0; row < nel; row++)
{
  for (int col = 0; col < nel; col++)
  {
    if (row >= col)
    {
      continue;
    }

    int map_row;
    int map_col;
    int rank;
    matrix_to_map_index(row, col, nel, &map_row, &map_col, np);
    rank = get_map(map, np, map_row, map_col);
    if (rank == myrank)
    {
      int index_part;
      if (map_row == map_col)
      {
        index_part = 0;
      }
      else
        if ((map_row == rank) && (map_col > rank))
      {
        index_part = map_col - rank;
      }
      else
        if ((map_col == rank) && (map_row < rank))
      {
        index_part = (np - map_col) + map_row;
      }
      else
      {
        index_part = -1;
        ((cerr << "Errore slave_print_global_matrix: ") << "indici mappa errati") << endl;
      }



      int local_row;
      int local_col;
      sim_metric val;
      if (r == 0)
      {
        local_col = col - (q * map_col);
        local_row = row - (q * map_row);
        if (index_part == 0)
        {
          val = get((*matrix_parts)[index_part], q, local_row, local_col);
        }
        else
        {
          val = (*matrix_parts)[index_part][(local_row * q) + local_col];
        }

      }
      else
      {
        local_col = col - (((q + 1) * map_col) - MIN(map_col, np - r));
        local_row = row - (((q + 1) * map_row) - MIN(map_row, np - r));
        if (index_part == 0)
        {
          val = get((*matrix_parts)[index_part], (map_col < (np - r)) ? (q) : (q + 1), local_row, local_col);
        }
        else
        {
          val = (*matrix_parts)[index_part][(local_row * ((map_col < (np - r)) ? (q) : (q + 1))) + local_col];
        }

      }

      MPI_Send(&val, sizeof(sim_metric), MPI_BYTE, 0, TAG_PRINT, MPI_COMM_WORLD);
    }

  }

}
