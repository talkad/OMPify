for (unsigned int i = 1; i < (nel_parts + 1); i++)
{
  int rank2 = (myrank + i) % np;
  unsigned int tmp_c1;
  unsigned int tmp_c2;
  sim_metric tmp_max;
  if (myrank < rank2)
  {
    findlink_quad(parts[i], get_mask_row_quad(mask, myrank, i, np), local_nel, get_mask_col_quad(mask, myrank, i, np), get_nel_by_rank(rank2, q, r, np), &tmp_c1, &tmp_c2, &tmp_max);
  }
  else
  {
    findlink_quad(parts[i], get_mask_row_quad(mask, myrank, i, np), get_nel_by_rank(rank2, q, r, np), get_mask_col_quad(mask, myrank, i, np), local_nel, &tmp_c1, &tmp_c2, &tmp_max);
  }

  if (tmp_max > max)
  {
    max = tmp_max;
    index_part = i;
    c1 = tmp_c1;
    c2 = tmp_c2;
  }

}
