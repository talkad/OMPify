for (int i = 0; i < np; i++)
{
  const int local_nel = (r == 0) ? (q) : ((i < (np - r)) ? (q) : (q + 1));
  for (int j = 0; j < local_nel; j++)
  {
    printf("%d", (mask[i] >> j) & 0x01);
  }

  printf(" ");
}
