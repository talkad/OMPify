for (unsigned int i = 0; i < (*local_nel); i++)
{
  const char *local_filename = dest_path(myrank, i);
  receive_file(local_filename, 0, myrank);
  img2pgm(local_filename);
  pgm2key(ext_pgm(local_filename));
  (*desc_array)[i] = get_sifts((string(local_filename) + suffix).c_str());
}
