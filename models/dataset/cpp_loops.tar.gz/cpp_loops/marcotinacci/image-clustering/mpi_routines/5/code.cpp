for (unsigned int i = 0; i < dim; i++)
{
  if (local_info[2] == 0)
  {
    buf[i] = get(matrix_parts[0], dim, i, local_info[1]);
  }
  else
    if (local_info[3] == 0)
  {
    buf[i] = matrix_parts[local_info[2]][(local_info[1] * col) + i];
  }
  else
    if (local_info[3] == 1)
  {
    buf[i] = matrix_parts[local_info[2]][(col * i) + local_info[1]];
  }
  else
  {
    ((cerr << "Errore: codice info[3] = ") << local_info[3]) << endl;
  }



}
