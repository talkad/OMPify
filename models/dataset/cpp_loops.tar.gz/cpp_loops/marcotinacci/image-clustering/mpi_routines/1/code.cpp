for (unsigned int i = 1; i < np; i++)
{
  info_mit[0] = np;
  MPI_Send(info_mit, 5, MPI_UNSIGNED, i, TAG_CLUSTER_1, MPI_COMM_WORLD);
  MPI_Send(info_mit, 5, MPI_UNSIGNED, i, TAG_CLUSTER_1, MPI_COMM_WORLD);
}
