for (unsigned int i = 0; i < (*nel_map); i++)
{
  set_map(*map, np, i % np, ((i + (i / np)) + 1) % np, i % np);
}
