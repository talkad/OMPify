for (unsigned int i = 0; i < num_cycle; i++)
{
  for (int j = 1; j < np; j++)
  {
    int info[] = {((j + i) + 1) % np, (((j - i) - 1) + np) % np};
    MPI_Send((void *) info, 2, MPI_INT, j, TAG_TRANSFER_INFO, MPI_COMM_WORLD);
  }

  mat[i + 1] = mpi_compute_matrix(desc_array, local_nel, nel, np, myrank, (i + 1) % np, ((np - i) - 1) % np);
}
