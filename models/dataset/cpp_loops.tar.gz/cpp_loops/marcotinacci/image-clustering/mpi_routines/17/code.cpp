for (unsigned int i = 1; i < (nel_parts + 1); i++)
{
  int rank2 = (myrank + i) % np;
  if (myrank < rank2)
  {
    print_submatrix(parts[i], local_nel, get_nel_by_rank(rank2, q, r, np));
  }
  else
  {
    print_submatrix(parts[i], get_nel_by_rank(rank2, q, r, np), local_nel);
  }

}
