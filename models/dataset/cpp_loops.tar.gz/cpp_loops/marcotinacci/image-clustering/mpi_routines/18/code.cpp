for (unsigned int i = 0; i < row; i++)
{
  for (unsigned int j = 0; j < col; j++)
  {
    (cout << dist[(i * col) + j]) << ' ';
  }

  cout << endl;
}
