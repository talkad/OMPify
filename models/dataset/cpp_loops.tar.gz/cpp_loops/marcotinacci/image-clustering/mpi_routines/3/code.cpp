for (unsigned int i = 0; i < dim; i++)
{
  if (part[index_cluster + (col * i)] > buf[i])
  {
    part[index_cluster + (col * i)] = buf[i];
  }

}
