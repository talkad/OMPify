for (unsigned int i = 0; i < np; i++)
{
  info_mit[0] = get_map(map, np, i_row, i);
  info_dest[0] = get_map(map, np, i, i_col);
  info_mit[1] = maxinfo.row;
  info_dest[1] = maxinfo.col;
  info_mit[2] = get_index_part(info_mit[0], np, i_row, i);
  info_dest[2] = get_index_part(info_dest[0], np, i_col, i);
  info_mit[3] = (i_row < i) ? (0) : (1);
  info_dest[3] = (i_col < i) ? (0) : (1);
  info_mit[4] = 0;
  info_dest[4] = 1;
  if ((info_mit[0] == 0) && (info_dest[0] == 0))
  {
    sim_metric *buf = get_local_stripe(0, np, nel, info_mit, *matrix_parts);
    unsigned int row;
    unsigned int col;
    unsigned int direction;
    get_part_dim(0, np, nel, info_dest[2], row, col);
    direction = (info_dest[2] == 0) ? (2) : (info_dest[3]);
    update_local_cluster((*matrix_parts)[info_dest[2]], buf, info_dest[1], row, col, direction);
  }
  else
    if (info_mit[0] == 0)
  {
    MPI_Send(info_mit, 5, MPI_UNSIGNED, info_dest[0], TAG_CLUSTER_1, MPI_COMM_WORLD);
    MPI_Send(info_dest, 5, MPI_UNSIGNED, info_dest[0], TAG_CLUSTER_1, MPI_COMM_WORLD);
    send_stripe(0, info_dest[0], np, nel, info_mit, *matrix_parts);
  }
  else
    if (info_dest[0] == 0)
  {
    MPI_Send(info_dest, 5, MPI_UNSIGNED, info_mit[0], TAG_CLUSTER_1, MPI_COMM_WORLD);
    MPI_Send(info_mit, 5, MPI_UNSIGNED, info_mit[0], TAG_CLUSTER_1, MPI_COMM_WORLD);
    sim_metric *buf = recv_stripe(0, np, nel, info_mit, matrix_parts);
    unsigned int row;
    unsigned int col;
    unsigned int direction;
    get_part_dim(0, np, nel, info_mit[2], row, col);
    direction = (info_mit[2] == 0) ? (2) : (info_mit[3]);
    update_local_cluster((*matrix_parts)[info_mit[2]], buf, info_mit[1], row, col, direction);
  }
  else
  {
    MPI_Send(info_mit, 5, MPI_UNSIGNED, info_dest[0], TAG_CLUSTER_1, MPI_COMM_WORLD);
    MPI_Send(info_dest, 5, MPI_UNSIGNED, info_dest[0], TAG_CLUSTER_1, MPI_COMM_WORLD);
    MPI_Send(info_mit, 5, MPI_UNSIGNED, info_mit[0], TAG_CLUSTER_1, MPI_COMM_WORLD);
    MPI_Send(info_dest, 5, MPI_UNSIGNED, info_mit[0], TAG_CLUSTER_1, MPI_COMM_WORLD);
  }



}
