for (unsigned int i = 0; i < num_cycle; i++)
{
  MPI_Recv(info, 2, MPI_INT, 0, TAG_TRANSFER_INFO, MPI_COMM_WORLD, &state);
  mat[i + 1] = mpi_compute_matrix(desc_array, local_nel, nel, np, myrank, info[0], info[1]);
}
