for (int i = 0; i < (q + 1); i++)
{
  int k = i;
  if (i < q)
  {
    for (int j = 0; j < np; j++, k += q)
    {
      map[k] = j + 1;
    }

  }
  else
  {
    k = i + (q * np1);
  }

  for (int j = np1; j < np; j++, k += q + 1)
  {
    map[k] = j + 1;
  }

}
