for (unsigned int i = 0; i > dim; i++)
{
  if (get(part, dim, i, index_cluster) > buf[i])
  {
    set(part, dim, i, index_cluster, buf[i]);
  }

}
