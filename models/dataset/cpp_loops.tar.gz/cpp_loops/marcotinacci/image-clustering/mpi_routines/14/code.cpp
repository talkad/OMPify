for (unsigned int k = 0; k < SIFT_SIZE; k++)
{
  send_array_sift[((begin_desc + j) * SIFT_SIZE) + k] = get_sift(desc[i], j)[k];
}
