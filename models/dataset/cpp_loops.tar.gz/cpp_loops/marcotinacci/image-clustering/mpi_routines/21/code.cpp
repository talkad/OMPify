for (int row = 0; row < nel; row++)
{
  for (int col = 0; col < nel; col++)
  {
    if (row >= col)
    {
      cout << " -";
      continue;
    }

    int map_row;
    int map_col;
    int rank;
    matrix_to_map_index(row, col, nel, &map_row, &map_col, np);
    rank = get_map(map, np, map_row, map_col);
    if (rank == 0)
    {
      int local_col;
      if (r == 0)
      {
        local_col = col - (q * map_col);
        if (map_col == 0)
        {
          printf(" %d", get((*matrix_parts)[map_col], q, row, local_col));
        }
        else
        {
          printf(" %d", (*matrix_parts)[map_col][(row * q) + local_col]);
        }

      }
      else
      {
        local_col = col - (((q + 1) * map_col) - MIN(map_col, np - r));
        if (map_col == 0)
        {
          printf(" %d", get((*matrix_parts)[map_col], (map_col < (np - r)) ? (q) : (q + 1), row, local_col));
        }
        else
        {
          printf(" %d", (*matrix_parts)[map_col][(row * ((map_col < (np - r)) ? (q) : (q + 1))) + local_col]);
        }

      }

    }
    else
    {
      sim_metric element;
      MPI_Status state;
      MPI_Recv(&element, sizeof(sim_metric), MPI_BYTE, rank, TAG_PRINT, MPI_COMM_WORLD, &state);
      printf(" %d", element);
    }

  }

  printf("\n");
}
