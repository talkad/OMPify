for (unsigned int i = 0; i < (q + 1); i++)
{
  unsigned int k = i;
  if (i < q)
  {
    for (unsigned int j = 0; j < np1; j++, k += q)
    {
      if (j == 0)
      {
        copy_local_file(img_names[k].c_str(), dest_path(0, i));
        const char *local_filename = dest_path(0, i);
        img2pgm(local_filename);
        pgm2key(ext_pgm(local_filename));
        (*desc_array)[i] = get_sifts((string(local_filename) + string(".key")).c_str());
      }
      else
      {
        send_file(img_names[k].c_str(), j);
      }

    }

  }
  else
  {
    k = i + (q * np1);
  }

  for (unsigned int j = np1; j < np; j++, k += q + 1)
  {
    send_file(img_names[k].c_str(), j);
  }

}
