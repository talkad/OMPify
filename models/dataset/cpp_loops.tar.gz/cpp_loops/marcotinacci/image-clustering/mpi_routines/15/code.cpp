for (unsigned int i = 0; i < nel; i++)
{
  unsigned int row = i % nel2;
  unsigned int col = i / nel2;
  dist[i] = sim_degree(desc1[col], desc2[row]);
}
