for (int i = 0; i < ((int) N); i++)
{
  if ((check_mask_element(mask, column_index(i, nel)) && check_mask_element(mask, row_index(i, nel))) && (dist[i] > max))
  {
    max = dist[i];
    max_i = i;
  }

}
