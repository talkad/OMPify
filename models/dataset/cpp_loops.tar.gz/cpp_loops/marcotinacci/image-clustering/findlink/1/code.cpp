for (int i = 0; i < ((int) N); i++)
{
  if ((check_mask_element(mask1, i / cols) && check_mask_element(mask2, i % cols)) && (dist[i] > max))
  {
    max = dist[i];
    max_i = i;
  }

}
