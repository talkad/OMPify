for (int i = 0; i < ((int) nel); i++)
{
  if ((!check_mask_element(*mask, i)) || (((int) c2) == i))
    continue;

  sim_metric a;
  sim_metric b;
  a = get(dist, nel, i, c1);
  b = get(dist, nel, i, c2);
  if (a > b)
  {
    set(dist, nel, i, c1, b);
  }

}
