for (int i = 0; i < ((int) nel); i++)
{
  desc_array[i] = get_sifts((img_names[i] + suffix).c_str());
}
