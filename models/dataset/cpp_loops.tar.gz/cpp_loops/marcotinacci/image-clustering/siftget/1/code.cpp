for (int sift_count = 0; !inFile.eof(); sift_count++)
{
  for (int j = 0; j < SIFT_SIZE; j++)
  {
    inFile >> x;
    desc->sift_array[(sift_count * SIFT_SIZE) + j] = x;
  }

  inFile >> temp;
  inFile >> temp;
  inFile >> temp;
  inFile >> temp;
}
