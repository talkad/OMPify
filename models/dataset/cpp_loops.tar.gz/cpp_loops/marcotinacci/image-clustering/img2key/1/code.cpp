for (unsigned int i = 0; i < (*nel); i++)
{
  getline(inFile, (*names)[i]);
}
