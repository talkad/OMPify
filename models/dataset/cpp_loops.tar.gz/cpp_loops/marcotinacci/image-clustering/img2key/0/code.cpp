for (int i = 0; i < ((int) nel); i++)
{
  img2pgm((*img_names)[i].c_str());
  pgm2key(ext_pgm((*img_names)[i].c_str()));
}
