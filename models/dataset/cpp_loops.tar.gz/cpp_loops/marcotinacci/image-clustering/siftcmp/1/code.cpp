for (int i = 0; i < N1; i++)
{
  float min1;
  float min2;
  min1 = (min2 = max());
  for (int j = 0; j < N2; j++)
  {
    float dist = sift_dist(get_sift(d1, i), get_sift(d2, j));
    if (dist < min1)
    {
      min2 = min1;
      min1 = dist;
    }
    else
      if (dist < min2)
    {
      min2 = dist;
    }


  }

  if ((min1 / min2) < ALPHA)
  {
    counter++;
  }

}
