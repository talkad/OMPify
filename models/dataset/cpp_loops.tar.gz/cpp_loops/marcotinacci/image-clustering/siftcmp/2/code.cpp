for (int i = 0; i < SIFT_SIZE; i++)
{
  if (s1[i] < s2[i])
    dist += pow(s2[i] - s1[i], 2);
  else
    dist += pow(s1[i] - s2[i], 2);

}
