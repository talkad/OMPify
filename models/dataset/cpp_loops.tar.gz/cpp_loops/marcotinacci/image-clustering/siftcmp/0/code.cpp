for (int i = 0; i < N; i++)
{
  dist[i] = sim_degree(desc_array[row_index(i, nel)], desc_array[column_index(i, nel)]);
}
