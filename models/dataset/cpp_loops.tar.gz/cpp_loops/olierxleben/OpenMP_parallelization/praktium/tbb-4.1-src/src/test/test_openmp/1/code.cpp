for (int j = range.begin(); j != range.end(); ++j)
  sum += my_a[j] * my_b[i - j];
