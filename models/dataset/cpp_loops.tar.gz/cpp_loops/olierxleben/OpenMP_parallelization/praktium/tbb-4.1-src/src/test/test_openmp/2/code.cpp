for (int j = start; j < finish; ++j)
  sum += my_a[j] * my_b[i - j];
