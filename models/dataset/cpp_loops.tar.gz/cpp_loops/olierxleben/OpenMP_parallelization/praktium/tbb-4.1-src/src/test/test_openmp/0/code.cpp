for (int i = 0; i < ((m + n) - 1); ++i)
{
  int start = (i < n) ? (0) : ((i - n) + 1);
  int finish = (i < m) ? (i + 1) : (m);
  T sum = 0;
  for (int j = start; j < finish; ++j)
    sum += a[j] * b[i - j];

  c[i] = sum;
}
