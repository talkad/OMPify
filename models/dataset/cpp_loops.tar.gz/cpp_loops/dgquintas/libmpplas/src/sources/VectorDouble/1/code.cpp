for (int i = 0; i < length; i++)
{
  sum += thisVec[i].sum();
}
