for (int i = 0; i < NUM_THREADS; i++)
{
  qassertTrue(integersSEQ[i] == integersPAR[i]);
}
