for (int i = 0; i < (length % 4); i++)
{
  sum += thisVec[i].sum();
}
