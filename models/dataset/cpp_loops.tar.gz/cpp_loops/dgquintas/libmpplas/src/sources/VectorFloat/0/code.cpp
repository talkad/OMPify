for (int i = 0; i < (length - 1); i++)
{
  sum += thisVec[i].sum();
}
