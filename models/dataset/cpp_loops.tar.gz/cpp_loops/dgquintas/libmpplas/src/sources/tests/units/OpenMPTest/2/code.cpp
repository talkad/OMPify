for (int i = 0; i < NUM_THREADS; i++)
{
  integersPAR[i] = integers[i] * factor;
}
