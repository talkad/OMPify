for (int i = 0; i < NUM_THREADS; i++)
{
  integersSEQ[i] = integers[i] * factor;
}
