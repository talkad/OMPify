for (int i = 0; i < NUM_THREADS; i++)
{
  integers[i] = rnd->getInteger(512);
}
