for (int i = 0; i < length; i++)
{
  thisVec[i] *= rhsVec[i];
}
