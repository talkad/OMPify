for (x = 0; x < N_ROW; x++)
{
  yval[x] = 0;
  for (y = arowpt[x]; y < arowpt[x + 1]; y++)
  {
    yval[x] += aval[y] * vval[acolind[y]];
  }

}
