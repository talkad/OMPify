for (int i = 0; i < NNZ; i++)
{
  (cout << val[i]) << "\t";
}
