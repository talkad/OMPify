for (int i = 0; i < N_ROW; i++)
{
  sqnorm += Yval[i] * Yval[i];
}
