for (int i = 0; i < (N_ROW + 1); i++)
{
  (cout << rowPt[i]) << "\t";
}
