for (int i = 0; i < N_ROW; i++)
{
  Yval[i] = 0;
}
