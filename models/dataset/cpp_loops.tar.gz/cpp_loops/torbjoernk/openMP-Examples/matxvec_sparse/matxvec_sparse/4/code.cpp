for (int i = 0; i < NNZ; i++)
{
  (cout << colInd[i]) << "\t";
}
