for (i = 0; i < N; i++)
{
  sum = sum + (a[i] * b[i]);
}
