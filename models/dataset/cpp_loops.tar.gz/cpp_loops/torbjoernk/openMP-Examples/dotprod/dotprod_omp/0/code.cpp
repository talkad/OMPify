for (i = 0; i < N; i++)
{
  a[i] = i * 0.5;
  b[i] = i * 2.0;
}
