for (int i = 0; i < N; i++)
{
  arr3[i] = (arr1[i] * 2) + (arr2[i] * 3);
}
