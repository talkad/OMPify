for (int i = 0; i < N; i++)
{
  arr1[i] = i;
  arr2[i] = i;
}
