for (int i = 0; i < num_hidden; i++)
{
  double sum = 0.0;
  for (int j = 0; j < num_outputs; j++)
  {
    sum += output_weight_deltas[j] * output_weights[j][i];
  }

  hidden_weight_deltas[i] = (sum * hv[i]) * (1.0 - hv[i]);
}
