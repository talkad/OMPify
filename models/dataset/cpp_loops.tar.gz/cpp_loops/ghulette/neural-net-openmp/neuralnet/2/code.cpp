for (int i = 0; i < num_hidden; i++)
{
  double sum = 0.0;
  for (int j = 0; j < num_inputs; j++)
  {
    sum += iv[j] * hidden_weights[i][j];
  }

  hv[i] = sigmoid(sum);
}
