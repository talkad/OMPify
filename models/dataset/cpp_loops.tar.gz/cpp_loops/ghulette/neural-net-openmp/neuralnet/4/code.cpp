for (int i = 0; i < num_outputs; i++)
{
  output_weight_deltas[i] = ((dv[i] - ov[i]) * ov[i]) * (1.0 - ov[i]);
}
