for (int i = 0; i < num_outputs; i++)
{
  double sum = 0.0;
  for (int j = 0; j < num_hidden; j++)
  {
    sum += hv[j] * output_weights[i][j];
  }

  ov[i] = sigmoid(sum);
}
