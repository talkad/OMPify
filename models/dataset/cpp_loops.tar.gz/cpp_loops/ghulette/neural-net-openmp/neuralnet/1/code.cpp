for (int i = 0; i < num_outputs; i++)
{
  output_weights[i] = output_weights_buffer + (i * num_hidden);
  for (int j = 0; j < num_hidden; j++)
  {
    output_weights[i][j] = rand_weight();
  }

}
