for (int i = 0; i < num_outputs; i++)
{
  double diff = desired_values[i] - output_values[i];
  sum += diff * diff;
}
