for (int i = 0; i < num_hidden; i++)
{
  for (int j = 0; j < num_inputs; j++)
  {
    hidden_weights[i][j] += (eta * hidden_weight_deltas[i]) * iv[j];
  }

}
