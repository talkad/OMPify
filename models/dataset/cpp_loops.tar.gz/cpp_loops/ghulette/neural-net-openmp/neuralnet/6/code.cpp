for (int i = 0; i < num_outputs; i++)
{
  for (int j = 0; j < num_hidden; j++)
  {
    output_weights[i][j] += (eta * output_weight_deltas[i]) * hv[j];
  }

}
