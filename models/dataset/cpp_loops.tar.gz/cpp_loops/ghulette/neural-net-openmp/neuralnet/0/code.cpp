for (int i = 0; i < num_hidden; i++)
{
  hidden_weights[i] = hidden_weights_buffer + (i * num_inputs);
  for (int j = 0; j < num_inputs; j++)
  {
    hidden_weights[i][j] = rand_weight();
  }

}
