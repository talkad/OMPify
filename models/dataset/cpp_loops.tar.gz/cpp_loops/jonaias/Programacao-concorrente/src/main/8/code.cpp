for (i = 0; i < 256; i++)
{
  transformMatrix[0][i] = i;
  transformMatrix[2][i] = i;
}
