for (int i = 0; i < imagem_ini.width(); i++)
  for (int j = 0; j < imagem_ini.height(); j++)
{
  histogram_matrix[0][qRed(imagem_ini.pixel(i, j))]++;
  histogram_matrix[1][qGreen(imagem_ini.pixel(i, j))]++;
  histogram_matrix[2][qBlue(imagem_ini.pixel(i, j))]++;
  histogram_matrix[3][((qRed(imagem_ini.pixel(i, j)) + qGreen(imagem_ini.pixel(i, j))) + qBlue(imagem_ini.pixel(i, j))) / 3]++;
}

