for (int i = 16; i <= 256; i *= 2)
{
  omp_set_num_threads(i);
  x_core_histogram_time = CalculateAdjust();
  (((((((out2 << i) << "\t") << i) << "\t") << (one_core_histogram_time / x_core_histogram_time)) << "\t") << x_core_histogram_time) << endl;
  out2.flush();
}
