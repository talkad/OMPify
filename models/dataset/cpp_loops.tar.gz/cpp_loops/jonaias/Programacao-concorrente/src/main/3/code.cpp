for (int i = 1; i <= 8; i++)
{
  omp_set_num_threads(i);
  if (i == 1)
  {
    (((((out1 << "1") << "\t1") << "\t1") << "\t") << (one_core_histogram_time = CalculateHistogram())) << endl;
  }
  else
  {
    x_core_histogram_time = CalculateHistogram();
    (((((((out1 << i) << "\t") << i) << "\t") << (one_core_histogram_time / x_core_histogram_time)) << "\t") << x_core_histogram_time) << endl;
  }

  out1.flush();
}
