for (i = 0; i < 256; i++)
{
  transformMatrix[1][i] = i;
  transformMatrix[0][i] = i;
}
