for (int i = 0; i < imagem_ini.width(); i++)
  for (int j = 0; j < imagem_ini.height(); j++)
  imagem_ini.setPixel(i, j, qRgb(transformMatrix[0][qRed(imagem_ini.pixel(i, j))], transformMatrix[1][qGreen(imagem_ini.pixel(i, j))], transformMatrix[2][qBlue(imagem_ini.pixel(i, j))]));

