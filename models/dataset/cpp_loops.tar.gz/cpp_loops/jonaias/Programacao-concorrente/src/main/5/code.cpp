for (int i = 1; i <= 8; i++)
{
  omp_set_num_threads(i);
  if (i == 1)
  {
    (((((out2 << "1") << "\t1") << "\t1") << "\t") << (one_core_histogram_time = CalculateAdjust())) << endl;
  }
  else
  {
    x_core_histogram_time = CalculateAdjust();
    (((((((out2 << i) << "\t") << i) << "\t") << (one_core_histogram_time / x_core_histogram_time)) << "\t") << x_core_histogram_time) << endl;
  }

  out2.flush();
}
