for (int i = 0; i < 256; i++)
{
  (((out1 << i) << " ") << histograma[0][i]) << endl;
  (((out2 << i) << " ") << histograma[1][i]) << endl;
  (((out3 << i) << " ") << histograma[2][i]) << endl;
  (((out4 << i) << " ") << histograma[3][i]) << endl;
}
