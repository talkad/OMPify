for (int x = 0; x < 100000; x++)
{
  for (int y = 0; y < 100000; y++)
  {
    sumParallel = (sumParallel + x) + y;
  }

}
