for (i = 1; i < n; i++)
{
  integral += f(a + (i * h));
}
