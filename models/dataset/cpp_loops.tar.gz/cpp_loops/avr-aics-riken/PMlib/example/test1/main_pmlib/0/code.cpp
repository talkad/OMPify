for (i = 0; i < 3; i++)
{
  PM.start("Kernel-Slow");
  slowkernel();
  PM.stop("Kernel-Slow", flop_count, 1);
  spacer();
  PM.start("Kernel-Fast");
  somekernel();
  PM.stop("Kernel-Fast", flop_count, 1);
  spacer();
}
