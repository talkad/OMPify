for (j = 0; j < N; j++)
  a[j] = b[j] + (scalar * c[j]);
