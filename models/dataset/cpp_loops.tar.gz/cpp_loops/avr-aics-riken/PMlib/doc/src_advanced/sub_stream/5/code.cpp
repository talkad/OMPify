for (k = 1; k < NTIMES; k++)
{
  for (j = 0; j < 4; j++)
  {
    avgtime[j] = avgtime[j] + times[j][k];
    mintime[j] = MIN(mintime[j], times[j][k]);
    maxtime[j] = MAX(maxtime[j], times[j][k]);
  }

}
