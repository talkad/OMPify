for (int i = 0; i < 2; i++)
{
  PM.start("Section-B");
  x = somekernel();
  PM.stop("Section-B");
}
