for (j = 0; j < 4; j++)
{
  avgtime[j] = avgtime[j] / ((double) (NTIMES - 1));
  printf("%s%11.4f  %11.4f  %11.4f  %11.4f\n", label[j], (1.0E-06 * bytes[j]) / mintime[j], avgtime[j], mintime[j], maxtime[j]);
}
