for (j = 0; j < N; j++)
  b[j] = scalar * c[j];
