for (int i = 0; i < 3; i++)
{
  PM.start("Section-B");
  x += somekernel();
  PM.stop("Section-B");
}
