for (t = tokens.begin(); t != tokens.end(); ++t)
{
  char symbol = (*t).at((*t).size() - 1);
  int num = 1;
  if ((*t).length() > 1)
  {
    num = (int) strtol((*t).substr(0, (*t).size() - 1).c_str(), NULL, 10);
  }

  switch (symbol)
  {
    case 'b':
      for (int i = 0; i < num; i++)
      world[x + i][y] = false;

      x += num;
      break;

    case 'o':
      for (int i = 0; i < num; i++)
      world[x + i][y] = true;

      x += num;
      break;

    case '$':
      y += num;
      x = 0;
      break;

  }

}
