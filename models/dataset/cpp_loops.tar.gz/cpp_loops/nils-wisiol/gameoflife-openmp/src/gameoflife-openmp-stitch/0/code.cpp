for (unsigned int i = 0; i < input.length(); i++)
{
  if (((input[i] == 'o') || (input[i] == 'b')) || (input[i] == '$'))
  {
    token = input.substr(beginToken, (i - beginToken) + 1);
    tokens.push_back(token);
    beginToken = i + 1;
  }
  else
    if (input[i] == '\n')
  {
    beginToken = i + 1;
  }


}
