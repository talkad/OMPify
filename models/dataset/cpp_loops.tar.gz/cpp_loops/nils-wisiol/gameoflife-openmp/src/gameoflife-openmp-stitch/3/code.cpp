for (int i = 0; i < HEIGHT; i++)
{
  for (int j = 0; j < WIDTH; j++)
  {
    int n = countNeighbourhood(world, i, j);
    buffer[i][j] = (world[i][j]) ? ((n == 2) || (n == 3)) : (n == 3);
  }

}
