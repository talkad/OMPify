for (int i = 0; i < HEIGHT; i++)
{
  for (int j = 0; j < WIDTH; j++)
  {
    cout << ((world[j][i]) ? ('#') : ('.'));
  }

  cout << endl;
}
