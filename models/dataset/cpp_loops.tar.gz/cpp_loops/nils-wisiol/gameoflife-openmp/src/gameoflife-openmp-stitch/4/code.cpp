for (int i = 0; i < WIDTH; i++)
{
  for (int j = 0; j < HEIGHT; j++)
  {
    bool expr = gworld[j][(WIDTH - 1) - i];
    texture[i][j][0] = (expr) ? (255) : (0);
    texture[i][j][1] = (expr) ? (255) : (0);
    texture[i][j][2] = (expr) ? (255) : (0);
    (expr) ? (white++) : (black++);
  }

}
