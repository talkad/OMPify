for (int i = 0; i < cloudSize; ++i)
{
  ccsum += clouds[i].dusts.size();
}
