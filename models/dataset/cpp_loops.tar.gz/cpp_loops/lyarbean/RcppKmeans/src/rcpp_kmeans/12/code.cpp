for (int i = 0; i < cloudSize; ++i)
{
  #pragma omp flush(centers,clouds)
  centers[i] = clouds[i].center_index;
  #pragma omp flush(centers,clouds)
}
