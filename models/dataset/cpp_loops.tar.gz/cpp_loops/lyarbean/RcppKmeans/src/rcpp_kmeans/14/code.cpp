for (int i = 0; i < pointsSize; ++i)
{
  if (cluster[i] == (-1))
    divergent.push_back(i);

}
