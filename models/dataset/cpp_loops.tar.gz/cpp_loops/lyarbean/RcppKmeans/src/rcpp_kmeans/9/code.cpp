for (int i = 1; i < cloudSize; ++i)
{
  do
  {
    skip = false;
    clusterIt++;
    if (clusterIt == cluster.end())
    {
      (((cout << "Error on reach end when initialize center[") << i) << "]") << endl;
      (((cout << "epsilon (") << eps) << ") is too large") << endl;
      return R_NilValue;
    }

    for (int j = 0; j < i; ++j)
    {
      double d = distance(&freqTable, *clusterIt, tmp[j]);
      if (d < eps)
      {
        skip = true;
        break;
      }

    }

  }
  while (skip);
  tmp[i] = *clusterIt;
}
