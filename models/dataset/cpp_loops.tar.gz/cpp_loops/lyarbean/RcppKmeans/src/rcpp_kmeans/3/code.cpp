for (; xv_it != xv_in->end(); ++xv_it)
{
  for (yv_it = zv_it; yv_it != yv_in->end(); ++yv_it)
  {
    if (yv_it->first == xv_it->first)
    {
      sum += yv_it->second * xv_it->second;
      zv_it = yv_it;
      break;
    }

  }

}
