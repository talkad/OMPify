for (xv_it = xv_in->begin(); xv_it != xv_in->end(); ++xv_it)
{
  yv_it = yv_in->find(xv_it->first);
  if (yv_it != yv_in->end())
  {
    sum += (xv_it->second - yv_it->second) * (xv_it->second - yv_it->second);
  }
  else
  {
    sum += xv_it->second * xv_it->second;
  }

}
