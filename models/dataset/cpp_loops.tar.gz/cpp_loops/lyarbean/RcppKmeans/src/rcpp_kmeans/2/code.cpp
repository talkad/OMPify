for (xv_it = xv_in->begin(); xv_it != xv_in->end(); ++xv_it)
{
  n += xv_it->second * xv_it->second;
}
