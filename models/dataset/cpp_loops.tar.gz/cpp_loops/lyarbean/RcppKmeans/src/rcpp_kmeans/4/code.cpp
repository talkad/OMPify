for (int i = 0; i < centersCount_in; ++i)
{
  dist_t = distance(freqTable_in, index_in, clouds[i].center_index);
  if (dist_t < dist)
  {
    dist = dist_t;
    which = i;
  }

}
