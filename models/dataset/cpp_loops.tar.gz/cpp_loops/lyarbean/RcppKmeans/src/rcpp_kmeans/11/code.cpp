for (int i = 0; i < pointsSize; ++i)
{
  if ((cluster[i] != clusterTmp[i]) || ((clusterTmp[i] != cloudSize) && (distance(&freqTable, centers[cluster[i]], centers[clusterTmp[i]]) > eps)))
  {
    if (removeFromCenters(clouds, cluster[i], i))
    {
      cluster[i] = clusterTmp[i];
      addToCenters(clouds, clusterTmp[i], i);
      changed = true;
    }

  }

}
