for (int i = 0; i < pointsSize; ++i)
{
  #pragma omp flush(clusterTmp,cluster)
  clusterTmp[i] = whichClosest(&freqTable, i, cluster[i], clouds, cloudSize);
  #pragma omp flush(clusterTmp)
}
