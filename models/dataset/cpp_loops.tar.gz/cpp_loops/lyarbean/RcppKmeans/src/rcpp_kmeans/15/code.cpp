for (int i = 0; i < cloudSize; ++i)
{
  x.push_back(IntegerVector(clouds[i].dusts.begin(), clouds[i].dusts.end()));
}
