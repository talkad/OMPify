for (int i = 0; i < cloudSize; ++i)
{
  clouds[i].center_index = centroidX(clouds[i].dusts, freqTable_in);
}
