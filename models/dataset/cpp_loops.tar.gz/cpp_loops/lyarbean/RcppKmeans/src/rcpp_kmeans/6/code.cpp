for (int i = 0; i < s; ++i)
{
  if (es[i] > large)
  {
    large = es[i];
    x = vec[i];
  }

}
