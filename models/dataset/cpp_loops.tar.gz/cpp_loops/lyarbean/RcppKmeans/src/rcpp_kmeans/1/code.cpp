for (yv_it = yv_in->begin(); yv_it != yv_in->end(); ++yv_it)
{
  if (xv_in->find(yv_it->first) == xv_in->end())
  {
    sum += yv_it->second * yv_it->second;
  }

}
