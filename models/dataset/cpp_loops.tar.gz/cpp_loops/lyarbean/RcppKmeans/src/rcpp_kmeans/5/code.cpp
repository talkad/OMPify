for (int i = 0; i < s; ++i)
{
  #pragma omp flush(es)
  es[i] = projection(&(*freqTable_in)[vec[i]], &p);
  #pragma omp flush(es)
}
