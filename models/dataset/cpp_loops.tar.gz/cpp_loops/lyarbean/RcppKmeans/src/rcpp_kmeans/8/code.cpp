for (int i = 0; i < pointsSize; ++i)
{
  cluster[i] = i;
}
